/*
 * Unresolved class.
 *
 * "happy" version.
 */

public class UnresClass {
    int foo;
}
