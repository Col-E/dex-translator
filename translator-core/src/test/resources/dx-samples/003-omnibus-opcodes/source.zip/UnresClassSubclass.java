public class UnresClassSubclass extends UnresClass {
  public UnresClassSubclass() {
  }
}
