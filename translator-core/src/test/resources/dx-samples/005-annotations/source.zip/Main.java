import android.test.anno.TestAnnotations;

public class Main {
    static public void main(String[] args) {
        TestAnnotations.main(args);
    }
}
