package android.test;

import java.lang.annotation.*;

@Target(ElementType.PACKAGE)
@Retention(RetentionPolicy.RUNTIME)

public @interface AnnoSimplePackage1 {}
