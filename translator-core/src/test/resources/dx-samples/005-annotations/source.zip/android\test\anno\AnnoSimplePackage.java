package android.test.anno;

import java.lang.annotation.*;

@Target(ElementType.PACKAGE)
@Retention(RetentionPolicy.RUNTIME)

public @interface AnnoSimplePackage {}
