package android.test.anno;

import java.lang.annotation.*;

@Target(ElementType.TYPE)
@Retention(RetentionPolicy.CLASS)

public @interface AnnoSimpleTypeInvis {}
