package android.test.anno;

@AnnoSimpleType2
public interface INoted {
    @AnnoSimpleMethod
    public int bar();
}
