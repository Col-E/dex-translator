package android.test.anno;

public class SomeClass {
}
