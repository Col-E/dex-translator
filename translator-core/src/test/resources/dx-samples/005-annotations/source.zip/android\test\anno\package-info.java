@AnnoSimplePackage
package android.test.anno;
