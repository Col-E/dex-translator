class X {
    public X() {
    }

    int foo() {
        return 0;
    }
}
