class Y extends X {
    public Y() {
    }

    int bar() {
        return 1;
    }
}
