interface Interface001 {
    int func001();
}
