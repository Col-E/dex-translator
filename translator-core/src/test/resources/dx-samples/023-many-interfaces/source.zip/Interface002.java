interface Interface002 {
}
