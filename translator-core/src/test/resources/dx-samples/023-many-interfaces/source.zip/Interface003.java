interface Interface003 {
    int func003();
}
