interface Interface005 {
    int func005();
}
