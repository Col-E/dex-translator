interface Interface006 {
}
