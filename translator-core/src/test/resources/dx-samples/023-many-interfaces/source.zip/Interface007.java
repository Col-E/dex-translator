interface Interface007 {
    int func007();
}
