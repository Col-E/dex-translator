interface Interface009 {
    int func009();
}
