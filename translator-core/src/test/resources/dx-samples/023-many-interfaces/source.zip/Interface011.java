interface Interface011 {
    int func011();
}
