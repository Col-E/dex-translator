interface Interface013 {
    int func013();
}
