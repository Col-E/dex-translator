interface Interface015 {
    int func015();
}
