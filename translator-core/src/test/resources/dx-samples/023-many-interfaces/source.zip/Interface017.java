interface Interface017 {
    int func017();
}
