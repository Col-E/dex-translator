interface Interface019 {
    int func019();
}
