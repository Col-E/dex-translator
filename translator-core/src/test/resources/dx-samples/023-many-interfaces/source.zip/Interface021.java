interface Interface021 {
    int func021();
}
