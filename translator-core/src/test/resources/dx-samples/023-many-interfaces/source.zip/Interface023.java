interface Interface023 {
    int func023();
}
