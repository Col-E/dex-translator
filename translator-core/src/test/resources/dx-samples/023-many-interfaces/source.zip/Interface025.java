interface Interface025 {
    int func025();
}
