interface Interface026 {
}
