interface Interface027 {
    int func027();
}
