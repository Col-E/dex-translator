interface Interface031 {
    int func031();
}
