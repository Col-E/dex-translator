interface Interface033 {
    int func033();
}
