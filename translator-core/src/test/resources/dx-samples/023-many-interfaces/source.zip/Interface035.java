interface Interface035 {
    int func035();
}
