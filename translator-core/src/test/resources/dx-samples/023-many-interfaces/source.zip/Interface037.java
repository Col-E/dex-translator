interface Interface037 {
    int func037();
}
