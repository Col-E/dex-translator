interface Interface039 {
    int func039();
}
