interface Interface040 {
}
