interface Interface041 {
    int func041();
}
