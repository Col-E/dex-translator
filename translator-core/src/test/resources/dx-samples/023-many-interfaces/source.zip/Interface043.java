interface Interface043 {
    int func043();
}
