interface Interface045 {
    int func045();
}
