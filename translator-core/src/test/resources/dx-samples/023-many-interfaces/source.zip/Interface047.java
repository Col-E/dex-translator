interface Interface047 {
    int func047();
}
