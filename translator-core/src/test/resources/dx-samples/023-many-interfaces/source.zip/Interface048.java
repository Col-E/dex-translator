interface Interface048 {
}
