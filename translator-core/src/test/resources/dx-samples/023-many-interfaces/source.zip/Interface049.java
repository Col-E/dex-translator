interface Interface049 {
    int func049();
}
