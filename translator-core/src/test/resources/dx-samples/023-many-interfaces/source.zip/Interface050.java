interface Interface050 {
}
