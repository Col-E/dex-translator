interface Interface051 {
    int func051();
}
