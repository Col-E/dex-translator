interface Interface052 {
}
