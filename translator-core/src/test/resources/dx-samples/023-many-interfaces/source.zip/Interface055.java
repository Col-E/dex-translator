interface Interface055 {
    int func055();
}
