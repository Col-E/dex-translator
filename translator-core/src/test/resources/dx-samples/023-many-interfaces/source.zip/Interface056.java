interface Interface056 {
}
