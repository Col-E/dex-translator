interface Interface057 {
    int func057();
}
