interface Interface058 {
}
