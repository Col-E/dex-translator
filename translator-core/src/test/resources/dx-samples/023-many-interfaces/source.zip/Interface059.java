interface Interface059 {
    int func059();
}
