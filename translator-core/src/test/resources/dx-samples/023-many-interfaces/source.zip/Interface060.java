interface Interface060 {
}
