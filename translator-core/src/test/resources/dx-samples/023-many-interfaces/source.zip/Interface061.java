interface Interface061 {
    int func061();
}
