interface Interface063 {
    int func063();
}
