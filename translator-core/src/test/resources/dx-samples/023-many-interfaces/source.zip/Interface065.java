interface Interface065 {
    int func065();
}
