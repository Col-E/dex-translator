interface Interface066 {
}
