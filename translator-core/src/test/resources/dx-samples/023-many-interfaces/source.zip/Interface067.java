interface Interface067 {
    int func067();
}
