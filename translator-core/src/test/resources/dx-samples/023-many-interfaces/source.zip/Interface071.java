interface Interface071 {
    int func071();
}
