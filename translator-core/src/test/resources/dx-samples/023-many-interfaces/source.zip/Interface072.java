interface Interface072 {
}
