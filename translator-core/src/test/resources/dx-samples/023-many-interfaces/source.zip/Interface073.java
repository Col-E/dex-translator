interface Interface073 {
    int func073();
}
