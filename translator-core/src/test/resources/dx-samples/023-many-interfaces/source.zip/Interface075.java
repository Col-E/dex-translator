interface Interface075 {
    int func075();
}
