interface Interface077 {
    int func077();
}
