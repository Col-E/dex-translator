interface Interface079 {
    int func079();
}
