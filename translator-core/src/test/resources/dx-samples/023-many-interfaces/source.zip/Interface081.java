interface Interface081 {
    int func081();
}
