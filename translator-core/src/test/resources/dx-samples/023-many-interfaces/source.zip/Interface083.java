interface Interface083 {
    int func083();
}
