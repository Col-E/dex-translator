interface Interface085 {
    int func085();
}
