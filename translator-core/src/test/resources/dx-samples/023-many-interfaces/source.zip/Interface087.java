interface Interface087 {
    int func087();
}
