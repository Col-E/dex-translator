interface Interface088 {
}
