interface Interface089 {
    int func089();
}
