interface Interface091 {
    int func091();
}
