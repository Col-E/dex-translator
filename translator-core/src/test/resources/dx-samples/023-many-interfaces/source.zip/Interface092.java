interface Interface092 {
}
