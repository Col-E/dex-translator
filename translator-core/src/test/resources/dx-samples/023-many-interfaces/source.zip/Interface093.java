interface Interface093 {
    int func093();
}
