interface Interface095 {
    int func095();
}
