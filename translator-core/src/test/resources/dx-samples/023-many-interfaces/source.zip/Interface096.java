interface Interface096 {
}
