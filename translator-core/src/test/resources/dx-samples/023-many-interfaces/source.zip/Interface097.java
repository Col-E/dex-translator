interface Interface097 {
    int func097();
}
