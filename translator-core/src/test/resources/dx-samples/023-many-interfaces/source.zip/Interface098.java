interface Interface098 {
}
