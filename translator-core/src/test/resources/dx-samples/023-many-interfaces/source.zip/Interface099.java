interface Interface099 {
    int func099();
}
