package otherpackage;

public class PublicAccess {
    static public void main() {
        System.out.println("Blort.");
    }
}
