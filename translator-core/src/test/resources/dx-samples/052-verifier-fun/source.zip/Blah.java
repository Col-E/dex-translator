public abstract class Blah {
    public void unrelatedStuff() {
    }
}
