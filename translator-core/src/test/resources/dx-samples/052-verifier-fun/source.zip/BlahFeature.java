public interface BlahFeature {
    public void doStuff();
}
