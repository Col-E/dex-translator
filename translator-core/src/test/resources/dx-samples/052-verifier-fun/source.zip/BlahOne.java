public class BlahOne extends Blah implements BlahFeature {
    public void doStuff() {
        System.out.println("BlahOne");
    }
}
