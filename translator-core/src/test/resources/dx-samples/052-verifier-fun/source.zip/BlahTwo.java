public class BlahTwo extends Blah implements BlahFeature {
    public void doStuff() {
        System.out.println("BlahTwo");
    }
}
