package otherpackage;

public enum OtherPackagePublicEnum {
    ZERO, ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE,
        TEN, ELEVEN, TWELVE, THIRTEEN, FOURTEEN, FIFTEEN, SIXTEEN,
        SEVENTEEN, EIGHTEEN, NINETEEN;
}
