
public class Useless implements ICommon {
    public DoubledImplement getDoubledInstance() { return null; }
}
