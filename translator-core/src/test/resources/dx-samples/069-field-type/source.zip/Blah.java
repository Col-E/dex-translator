
/**
 * Trivial class; must implement an interesting interface.
 */
public class Blah implements Runnable {
    public void run() {
        System.out.println("run");
    }
}
