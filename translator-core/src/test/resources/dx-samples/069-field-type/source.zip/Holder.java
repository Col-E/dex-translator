
/**
 * Simple class with one field.
 */
public class Holder {
    public Runnable mValue;
}
