/*
 * Copyright (C) 2014 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

public class Main {
    public static int num_errors = 0;

    public static void reportError(String message) {
        if (num_errors == 10) {
            System.out.println("Omitting other error messages...");
        } else if (num_errors < 10) {
            System.out.println(message);
        }
        num_errors += 1;
    }

    public static void intCheckDiv(String desc, int result, int dividend, int divisor) {
        int correct_result = dividend / divisor;
        if (result != correct_result) {
            reportError(desc + "(" + dividend + ") == " + result +
                        " should be " + correct_result);
        }
    }
    public static void intCheckRem(String desc, int result, int dividend, int divisor) {
        int correct_result = dividend % divisor;
        if (result != correct_result) {
            reportError(desc + "(" + dividend + ") == " + result +
                        " should be " + correct_result);
        }
    }
    public static void longCheckDiv(String desc, long result, long dividend, long divisor) {
        long correct_result = dividend / divisor;
        if (result != correct_result) {
            reportError(desc + "(" + dividend + ") == " + result +
                        " should be " + correct_result);
        }
    }
    public static void longCheckRem(String desc, long result, long dividend, long divisor) {
        long correct_result = dividend % divisor;
        if (result != correct_result) {
            reportError(desc + "(" + dividend + ") == " + result +
                        " should be " + correct_result);
        }
    }

    public static int idiv_by_pow2_0(int x) {return x / 1;}
    public static int idiv_by_pow2_1(int x) {return x / 2;}
    public static int idiv_by_pow2_2(int x) {return x / 4;}
    public static int idiv_by_pow2_3(int x) {return x / 8;}
    public static int idiv_by_pow2_4(int x) {return x / 16;}
    public static int idiv_by_pow2_5(int x) {return x / 32;}
    public static int idiv_by_pow2_6(int x) {return x / 64;}
    public static int idiv_by_pow2_7(int x) {return x / 128;}
    public static int idiv_by_pow2_8(int x) {return x / 256;}
    public static int idiv_by_pow2_9(int x) {return x / 512;}
    public static int idiv_by_pow2_10(int x) {return x / 1024;}
    public static int idiv_by_pow2_11(int x) {return x / 2048;}
    public static int idiv_by_pow2_12(int x) {return x / 4096;}
    public static int idiv_by_pow2_13(int x) {return x / 8192;}
    public static int idiv_by_pow2_14(int x) {return x / 16384;}
    public static int idiv_by_pow2_15(int x) {return x / 32768;}
    public static int idiv_by_pow2_16(int x) {return x / 65536;}
    public static int idiv_by_pow2_17(int x) {return x / 131072;}
    public static int idiv_by_pow2_18(int x) {return x / 262144;}
    public static int idiv_by_pow2_19(int x) {return x / 524288;}
    public static int idiv_by_pow2_20(int x) {return x / 1048576;}
    public static int idiv_by_pow2_21(int x) {return x / 2097152;}
    public static int idiv_by_pow2_22(int x) {return x / 4194304;}
    public static int idiv_by_pow2_23(int x) {return x / 8388608;}
    public static int idiv_by_pow2_24(int x) {return x / 16777216;}
    public static int idiv_by_pow2_25(int x) {return x / 33554432;}
    public static int idiv_by_pow2_26(int x) {return x / 67108864;}
    public static int idiv_by_pow2_27(int x) {return x / 134217728;}
    public static int idiv_by_pow2_28(int x) {return x / 268435456;}
    public static int idiv_by_pow2_29(int x) {return x / 536870912;}
    public static int idiv_by_pow2_30(int x) {return x / 1073741824;}
    public static int idiv_by_pow2_neg_0(int x) {return x / -1;}
    public static int idiv_by_pow2_neg_1(int x) {return x / -2;}
    public static int idiv_by_pow2_neg_2(int x) {return x / -4;}
    public static int idiv_by_pow2_neg_3(int x) {return x / -8;}
    public static int idiv_by_pow2_neg_4(int x) {return x / -16;}
    public static int idiv_by_pow2_neg_5(int x) {return x / -32;}
    public static int idiv_by_pow2_neg_6(int x) {return x / -64;}
    public static int idiv_by_pow2_neg_7(int x) {return x / -128;}
    public static int idiv_by_pow2_neg_8(int x) {return x / -256;}
    public static int idiv_by_pow2_neg_9(int x) {return x / -512;}
    public static int idiv_by_pow2_neg_10(int x) {return x / -1024;}
    public static int idiv_by_pow2_neg_11(int x) {return x / -2048;}
    public static int idiv_by_pow2_neg_12(int x) {return x / -4096;}
    public static int idiv_by_pow2_neg_13(int x) {return x / -8192;}
    public static int idiv_by_pow2_neg_14(int x) {return x / -16384;}
    public static int idiv_by_pow2_neg_15(int x) {return x / -32768;}
    public static int idiv_by_pow2_neg_16(int x) {return x / -65536;}
    public static int idiv_by_pow2_neg_17(int x) {return x / -131072;}
    public static int idiv_by_pow2_neg_18(int x) {return x / -262144;}
    public static int idiv_by_pow2_neg_19(int x) {return x / -524288;}
    public static int idiv_by_pow2_neg_20(int x) {return x / -1048576;}
    public static int idiv_by_pow2_neg_21(int x) {return x / -2097152;}
    public static int idiv_by_pow2_neg_22(int x) {return x / -4194304;}
    public static int idiv_by_pow2_neg_23(int x) {return x / -8388608;}
    public static int idiv_by_pow2_neg_24(int x) {return x / -16777216;}
    public static int idiv_by_pow2_neg_25(int x) {return x / -33554432;}
    public static int idiv_by_pow2_neg_26(int x) {return x / -67108864;}
    public static int idiv_by_pow2_neg_27(int x) {return x / -134217728;}
    public static int idiv_by_pow2_neg_28(int x) {return x / -268435456;}
    public static int idiv_by_pow2_neg_29(int x) {return x / -536870912;}
    public static int idiv_by_pow2_neg_30(int x) {return x / -1073741824;}
    public static int idiv_by_pow2_neg_31(int x) {return x / -2147483648;}
    public static int idiv_by_constant_0(int x) {return x / 1;}
    public static int idiv_by_constant_1(int x) {return x / 2;}
    public static int idiv_by_constant_2(int x) {return x / 3;}
    public static int idiv_by_constant_3(int x) {return x / 4;}
    public static int idiv_by_constant_4(int x) {return x / 5;}
    public static int idiv_by_constant_5(int x) {return x / 6;}
    public static int idiv_by_constant_6(int x) {return x / 7;}
    public static int idiv_by_constant_7(int x) {return x / 8;}
    public static int idiv_by_constant_8(int x) {return x / 9;}
    public static int idiv_by_constant_9(int x) {return x / 10;}
    public static int idiv_by_constant_10(int x) {return x / 11;}
    public static int idiv_by_constant_11(int x) {return x / 12;}
    public static int idiv_by_constant_12(int x) {return x / 13;}
    public static int idiv_by_constant_13(int x) {return x / 14;}
    public static int idiv_by_constant_14(int x) {return x / 15;}
    public static int idiv_by_constant_15(int x) {return x / 16;}
    public static int idiv_by_constant_16(int x) {return x / 17;}
    public static int idiv_by_constant_17(int x) {return x / 18;}
    public static int idiv_by_constant_18(int x) {return x / 19;}
    public static int idiv_by_constant_19(int x) {return x / 20;}
    public static int idiv_by_constant_20(int x) {return x / 21;}
    public static int idiv_by_constant_21(int x) {return x / 22;}
    public static int idiv_by_constant_22(int x) {return x / 23;}
    public static int idiv_by_constant_23(int x) {return x / 24;}
    public static int idiv_by_constant_24(int x) {return x / 25;}
    public static int idiv_by_constant_25(int x) {return x / 26;}
    public static int idiv_by_constant_26(int x) {return x / 27;}
    public static int idiv_by_constant_27(int x) {return x / 28;}
    public static int idiv_by_constant_28(int x) {return x / 29;}
    public static int idiv_by_constant_29(int x) {return x / 30;}
    public static int idiv_by_constant_30(int x) {return x / 31;}
    public static int idiv_by_constant_31(int x) {return x / 32;}
    public static int idiv_by_constant_32(int x) {return x / 33;}
    public static int idiv_by_constant_33(int x) {return x / 34;}
    public static int idiv_by_constant_34(int x) {return x / 35;}
    public static int idiv_by_constant_35(int x) {return x / 36;}
    public static int idiv_by_constant_36(int x) {return x / 37;}
    public static int idiv_by_constant_37(int x) {return x / 38;}
    public static int idiv_by_constant_38(int x) {return x / 39;}
    public static int idiv_by_constant_39(int x) {return x / 40;}
    public static int idiv_by_constant_40(int x) {return x / 41;}
    public static int idiv_by_constant_41(int x) {return x / 42;}
    public static int idiv_by_constant_42(int x) {return x / 43;}
    public static int idiv_by_constant_43(int x) {return x / 44;}
    public static int idiv_by_constant_44(int x) {return x / 45;}
    public static int idiv_by_constant_45(int x) {return x / 46;}
    public static int idiv_by_constant_46(int x) {return x / 47;}
    public static int idiv_by_constant_47(int x) {return x / 48;}
    public static int idiv_by_constant_48(int x) {return x / 49;}
    public static int idiv_by_constant_49(int x) {return x / 50;}
    public static int idiv_by_constant_50(int x) {return x / 51;}
    public static int idiv_by_constant_51(int x) {return x / 52;}
    public static int idiv_by_constant_52(int x) {return x / 53;}
    public static int idiv_by_constant_53(int x) {return x / 54;}
    public static int idiv_by_constant_54(int x) {return x / 55;}
    public static int idiv_by_constant_55(int x) {return x / 56;}
    public static int idiv_by_constant_56(int x) {return x / 57;}
    public static int idiv_by_constant_57(int x) {return x / 58;}
    public static int idiv_by_constant_58(int x) {return x / 59;}
    public static int idiv_by_constant_59(int x) {return x / 60;}
    public static int idiv_by_constant_60(int x) {return x / 61;}
    public static int idiv_by_constant_61(int x) {return x / 62;}
    public static int idiv_by_constant_62(int x) {return x / 63;}
    public static int idiv_by_constant_63(int x) {return x / 64;}
    public static int idiv_by_constant_64(int x) {return x / 65;}
    public static int idiv_by_constant_65(int x) {return x / 66;}
    public static int idiv_by_constant_66(int x) {return x / 67;}
    public static int idiv_by_constant_67(int x) {return x / 68;}
    public static int idiv_by_constant_68(int x) {return x / 69;}
    public static int idiv_by_constant_69(int x) {return x / 70;}
    public static int idiv_by_constant_70(int x) {return x / 71;}
    public static int idiv_by_constant_71(int x) {return x / 72;}
    public static int idiv_by_constant_72(int x) {return x / 73;}
    public static int idiv_by_constant_73(int x) {return x / 74;}
    public static int idiv_by_constant_74(int x) {return x / 75;}
    public static int idiv_by_constant_75(int x) {return x / 76;}
    public static int idiv_by_constant_76(int x) {return x / 77;}
    public static int idiv_by_constant_77(int x) {return x / 78;}
    public static int idiv_by_constant_78(int x) {return x / 79;}
    public static int idiv_by_constant_79(int x) {return x / 80;}
    public static int idiv_by_constant_80(int x) {return x / 81;}
    public static int idiv_by_constant_81(int x) {return x / 82;}
    public static int idiv_by_constant_82(int x) {return x / 83;}
    public static int idiv_by_constant_83(int x) {return x / 84;}
    public static int idiv_by_constant_84(int x) {return x / 85;}
    public static int idiv_by_constant_85(int x) {return x / 86;}
    public static int idiv_by_constant_86(int x) {return x / 87;}
    public static int idiv_by_constant_87(int x) {return x / 88;}
    public static int idiv_by_constant_88(int x) {return x / 89;}
    public static int idiv_by_constant_89(int x) {return x / 90;}
    public static int idiv_by_constant_90(int x) {return x / 91;}
    public static int idiv_by_constant_91(int x) {return x / 92;}
    public static int idiv_by_constant_92(int x) {return x / 93;}
    public static int idiv_by_constant_93(int x) {return x / 94;}
    public static int idiv_by_constant_94(int x) {return x / 95;}
    public static int idiv_by_constant_95(int x) {return x / 96;}
    public static int idiv_by_constant_96(int x) {return x / 97;}
    public static int idiv_by_constant_97(int x) {return x / 98;}
    public static int idiv_by_constant_98(int x) {return x / 99;}
    public static int idiv_by_constant_neg_0(int x) {return x / -1;}
    public static int idiv_by_constant_neg_1(int x) {return x / -2;}
    public static int idiv_by_constant_neg_2(int x) {return x / -3;}
    public static int idiv_by_constant_neg_3(int x) {return x / -4;}
    public static int idiv_by_constant_neg_4(int x) {return x / -5;}
    public static int idiv_by_constant_neg_5(int x) {return x / -6;}
    public static int idiv_by_constant_neg_6(int x) {return x / -7;}
    public static int idiv_by_constant_neg_7(int x) {return x / -8;}
    public static int idiv_by_constant_neg_8(int x) {return x / -9;}
    public static int idiv_by_constant_neg_9(int x) {return x / -10;}
    public static int idiv_by_constant_neg_10(int x) {return x / -11;}
    public static int idiv_by_constant_neg_11(int x) {return x / -12;}
    public static int idiv_by_constant_neg_12(int x) {return x / -13;}
    public static int idiv_by_constant_neg_13(int x) {return x / -14;}
    public static int idiv_by_constant_neg_14(int x) {return x / -15;}
    public static int idiv_by_constant_neg_15(int x) {return x / -16;}
    public static int idiv_by_constant_neg_16(int x) {return x / -17;}
    public static int idiv_by_constant_neg_17(int x) {return x / -18;}
    public static int idiv_by_constant_neg_18(int x) {return x / -19;}
    public static int idiv_by_constant_neg_19(int x) {return x / -20;}
    public static int idiv_by_constant_neg_20(int x) {return x / -21;}
    public static int idiv_by_constant_neg_21(int x) {return x / -22;}
    public static int idiv_by_constant_neg_22(int x) {return x / -23;}
    public static int idiv_by_constant_neg_23(int x) {return x / -24;}
    public static int idiv_by_constant_neg_24(int x) {return x / -25;}
    public static int idiv_by_constant_neg_25(int x) {return x / -26;}
    public static int idiv_by_constant_neg_26(int x) {return x / -27;}
    public static int idiv_by_constant_neg_27(int x) {return x / -28;}
    public static int idiv_by_constant_neg_28(int x) {return x / -29;}
    public static int idiv_by_constant_neg_29(int x) {return x / -30;}
    public static int idiv_by_constant_neg_30(int x) {return x / -31;}
    public static int idiv_by_constant_neg_31(int x) {return x / -32;}
    public static int idiv_by_constant_neg_32(int x) {return x / -33;}
    public static int idiv_by_constant_neg_33(int x) {return x / -34;}
    public static int idiv_by_constant_neg_34(int x) {return x / -35;}
    public static int idiv_by_constant_neg_35(int x) {return x / -36;}
    public static int idiv_by_constant_neg_36(int x) {return x / -37;}
    public static int idiv_by_constant_neg_37(int x) {return x / -38;}
    public static int idiv_by_constant_neg_38(int x) {return x / -39;}
    public static int idiv_by_constant_neg_39(int x) {return x / -40;}
    public static int idiv_by_constant_neg_40(int x) {return x / -41;}
    public static int idiv_by_constant_neg_41(int x) {return x / -42;}
    public static int idiv_by_constant_neg_42(int x) {return x / -43;}
    public static int idiv_by_constant_neg_43(int x) {return x / -44;}
    public static int idiv_by_constant_neg_44(int x) {return x / -45;}
    public static int idiv_by_constant_neg_45(int x) {return x / -46;}
    public static int idiv_by_constant_neg_46(int x) {return x / -47;}
    public static int idiv_by_constant_neg_47(int x) {return x / -48;}
    public static int idiv_by_constant_neg_48(int x) {return x / -49;}
    public static int idiv_by_constant_neg_49(int x) {return x / -50;}
    public static int idiv_by_constant_neg_50(int x) {return x / -51;}
    public static int idiv_by_constant_neg_51(int x) {return x / -52;}
    public static int idiv_by_constant_neg_52(int x) {return x / -53;}
    public static int idiv_by_constant_neg_53(int x) {return x / -54;}
    public static int idiv_by_constant_neg_54(int x) {return x / -55;}
    public static int idiv_by_constant_neg_55(int x) {return x / -56;}
    public static int idiv_by_constant_neg_56(int x) {return x / -57;}
    public static int idiv_by_constant_neg_57(int x) {return x / -58;}
    public static int idiv_by_constant_neg_58(int x) {return x / -59;}
    public static int idiv_by_constant_neg_59(int x) {return x / -60;}
    public static int idiv_by_constant_neg_60(int x) {return x / -61;}
    public static int idiv_by_constant_neg_61(int x) {return x / -62;}
    public static int idiv_by_constant_neg_62(int x) {return x / -63;}
    public static int idiv_by_constant_neg_63(int x) {return x / -64;}
    public static int idiv_by_constant_neg_64(int x) {return x / -65;}
    public static int idiv_by_constant_neg_65(int x) {return x / -66;}
    public static int idiv_by_constant_neg_66(int x) {return x / -67;}
    public static int idiv_by_constant_neg_67(int x) {return x / -68;}
    public static int idiv_by_constant_neg_68(int x) {return x / -69;}
    public static int idiv_by_constant_neg_69(int x) {return x / -70;}
    public static int idiv_by_constant_neg_70(int x) {return x / -71;}
    public static int idiv_by_constant_neg_71(int x) {return x / -72;}
    public static int idiv_by_constant_neg_72(int x) {return x / -73;}
    public static int idiv_by_constant_neg_73(int x) {return x / -74;}
    public static int idiv_by_constant_neg_74(int x) {return x / -75;}
    public static int idiv_by_constant_neg_75(int x) {return x / -76;}
    public static int idiv_by_constant_neg_76(int x) {return x / -77;}
    public static int idiv_by_constant_neg_77(int x) {return x / -78;}
    public static int idiv_by_constant_neg_78(int x) {return x / -79;}
    public static int idiv_by_constant_neg_79(int x) {return x / -80;}
    public static int idiv_by_constant_neg_80(int x) {return x / -81;}
    public static int idiv_by_constant_neg_81(int x) {return x / -82;}
    public static int idiv_by_constant_neg_82(int x) {return x / -83;}
    public static int idiv_by_constant_neg_83(int x) {return x / -84;}
    public static int idiv_by_constant_neg_84(int x) {return x / -85;}
    public static int idiv_by_constant_neg_85(int x) {return x / -86;}
    public static int idiv_by_constant_neg_86(int x) {return x / -87;}
    public static int idiv_by_constant_neg_87(int x) {return x / -88;}
    public static int idiv_by_constant_neg_88(int x) {return x / -89;}
    public static int idiv_by_constant_neg_89(int x) {return x / -90;}
    public static int idiv_by_constant_neg_90(int x) {return x / -91;}
    public static int idiv_by_constant_neg_91(int x) {return x / -92;}
    public static int idiv_by_constant_neg_92(int x) {return x / -93;}
    public static int idiv_by_constant_neg_93(int x) {return x / -94;}
    public static int idiv_by_constant_neg_94(int x) {return x / -95;}
    public static int idiv_by_constant_neg_95(int x) {return x / -96;}
    public static int idiv_by_constant_neg_96(int x) {return x / -97;}
    public static int idiv_by_constant_neg_97(int x) {return x / -98;}
    public static int idiv_by_constant_neg_98(int x) {return x / -99;}
    public static int irem_by_pow2_0(int x) {return x % 1;}
    public static int irem_by_pow2_1(int x) {return x % 2;}
    public static int irem_by_pow2_2(int x) {return x % 4;}
    public static int irem_by_pow2_3(int x) {return x % 8;}
    public static int irem_by_pow2_4(int x) {return x % 16;}
    public static int irem_by_pow2_5(int x) {return x % 32;}
    public static int irem_by_pow2_6(int x) {return x % 64;}
    public static int irem_by_pow2_7(int x) {return x % 128;}
    public static int irem_by_pow2_8(int x) {return x % 256;}
    public static int irem_by_pow2_9(int x) {return x % 512;}
    public static int irem_by_pow2_10(int x) {return x % 1024;}
    public static int irem_by_pow2_11(int x) {return x % 2048;}
    public static int irem_by_pow2_12(int x) {return x % 4096;}
    public static int irem_by_pow2_13(int x) {return x % 8192;}
    public static int irem_by_pow2_14(int x) {return x % 16384;}
    public static int irem_by_pow2_15(int x) {return x % 32768;}
    public static int irem_by_pow2_16(int x) {return x % 65536;}
    public static int irem_by_pow2_17(int x) {return x % 131072;}
    public static int irem_by_pow2_18(int x) {return x % 262144;}
    public static int irem_by_pow2_19(int x) {return x % 524288;}
    public static int irem_by_pow2_20(int x) {return x % 1048576;}
    public static int irem_by_pow2_21(int x) {return x % 2097152;}
    public static int irem_by_pow2_22(int x) {return x % 4194304;}
    public static int irem_by_pow2_23(int x) {return x % 8388608;}
    public static int irem_by_pow2_24(int x) {return x % 16777216;}
    public static int irem_by_pow2_25(int x) {return x % 33554432;}
    public static int irem_by_pow2_26(int x) {return x % 67108864;}
    public static int irem_by_pow2_27(int x) {return x % 134217728;}
    public static int irem_by_pow2_28(int x) {return x % 268435456;}
    public static int irem_by_pow2_29(int x) {return x % 536870912;}
    public static int irem_by_pow2_30(int x) {return x % 1073741824;}
    public static int irem_by_pow2_neg_0(int x) {return x % -1;}
    public static int irem_by_pow2_neg_1(int x) {return x % -2;}
    public static int irem_by_pow2_neg_2(int x) {return x % -4;}
    public static int irem_by_pow2_neg_3(int x) {return x % -8;}
    public static int irem_by_pow2_neg_4(int x) {return x % -16;}
    public static int irem_by_pow2_neg_5(int x) {return x % -32;}
    public static int irem_by_pow2_neg_6(int x) {return x % -64;}
    public static int irem_by_pow2_neg_7(int x) {return x % -128;}
    public static int irem_by_pow2_neg_8(int x) {return x % -256;}
    public static int irem_by_pow2_neg_9(int x) {return x % -512;}
    public static int irem_by_pow2_neg_10(int x) {return x % -1024;}
    public static int irem_by_pow2_neg_11(int x) {return x % -2048;}
    public static int irem_by_pow2_neg_12(int x) {return x % -4096;}
    public static int irem_by_pow2_neg_13(int x) {return x % -8192;}
    public static int irem_by_pow2_neg_14(int x) {return x % -16384;}
    public static int irem_by_pow2_neg_15(int x) {return x % -32768;}
    public static int irem_by_pow2_neg_16(int x) {return x % -65536;}
    public static int irem_by_pow2_neg_17(int x) {return x % -131072;}
    public static int irem_by_pow2_neg_18(int x) {return x % -262144;}
    public static int irem_by_pow2_neg_19(int x) {return x % -524288;}
    public static int irem_by_pow2_neg_20(int x) {return x % -1048576;}
    public static int irem_by_pow2_neg_21(int x) {return x % -2097152;}
    public static int irem_by_pow2_neg_22(int x) {return x % -4194304;}
    public static int irem_by_pow2_neg_23(int x) {return x % -8388608;}
    public static int irem_by_pow2_neg_24(int x) {return x % -16777216;}
    public static int irem_by_pow2_neg_25(int x) {return x % -33554432;}
    public static int irem_by_pow2_neg_26(int x) {return x % -67108864;}
    public static int irem_by_pow2_neg_27(int x) {return x % -134217728;}
    public static int irem_by_pow2_neg_28(int x) {return x % -268435456;}
    public static int irem_by_pow2_neg_29(int x) {return x % -536870912;}
    public static int irem_by_pow2_neg_30(int x) {return x % -1073741824;}
    public static int irem_by_pow2_neg_31(int x) {return x % -2147483648;}
    public static int irem_by_constant_0(int x) {return x % 1;}
    public static int irem_by_constant_1(int x) {return x % 2;}
    public static int irem_by_constant_2(int x) {return x % 3;}
    public static int irem_by_constant_3(int x) {return x % 4;}
    public static int irem_by_constant_4(int x) {return x % 5;}
    public static int irem_by_constant_5(int x) {return x % 6;}
    public static int irem_by_constant_6(int x) {return x % 7;}
    public static int irem_by_constant_7(int x) {return x % 8;}
    public static int irem_by_constant_8(int x) {return x % 9;}
    public static int irem_by_constant_9(int x) {return x % 10;}
    public static int irem_by_constant_10(int x) {return x % 11;}
    public static int irem_by_constant_11(int x) {return x % 12;}
    public static int irem_by_constant_12(int x) {return x % 13;}
    public static int irem_by_constant_13(int x) {return x % 14;}
    public static int irem_by_constant_14(int x) {return x % 15;}
    public static int irem_by_constant_15(int x) {return x % 16;}
    public static int irem_by_constant_16(int x) {return x % 17;}
    public static int irem_by_constant_17(int x) {return x % 18;}
    public static int irem_by_constant_18(int x) {return x % 19;}
    public static int irem_by_constant_19(int x) {return x % 20;}
    public static int irem_by_constant_20(int x) {return x % 21;}
    public static int irem_by_constant_21(int x) {return x % 22;}
    public static int irem_by_constant_22(int x) {return x % 23;}
    public static int irem_by_constant_23(int x) {return x % 24;}
    public static int irem_by_constant_24(int x) {return x % 25;}
    public static int irem_by_constant_25(int x) {return x % 26;}
    public static int irem_by_constant_26(int x) {return x % 27;}
    public static int irem_by_constant_27(int x) {return x % 28;}
    public static int irem_by_constant_28(int x) {return x % 29;}
    public static int irem_by_constant_29(int x) {return x % 30;}
    public static int irem_by_constant_30(int x) {return x % 31;}
    public static int irem_by_constant_31(int x) {return x % 32;}
    public static int irem_by_constant_32(int x) {return x % 33;}
    public static int irem_by_constant_33(int x) {return x % 34;}
    public static int irem_by_constant_34(int x) {return x % 35;}
    public static int irem_by_constant_35(int x) {return x % 36;}
    public static int irem_by_constant_36(int x) {return x % 37;}
    public static int irem_by_constant_37(int x) {return x % 38;}
    public static int irem_by_constant_38(int x) {return x % 39;}
    public static int irem_by_constant_39(int x) {return x % 40;}
    public static int irem_by_constant_40(int x) {return x % 41;}
    public static int irem_by_constant_41(int x) {return x % 42;}
    public static int irem_by_constant_42(int x) {return x % 43;}
    public static int irem_by_constant_43(int x) {return x % 44;}
    public static int irem_by_constant_44(int x) {return x % 45;}
    public static int irem_by_constant_45(int x) {return x % 46;}
    public static int irem_by_constant_46(int x) {return x % 47;}
    public static int irem_by_constant_47(int x) {return x % 48;}
    public static int irem_by_constant_48(int x) {return x % 49;}
    public static int irem_by_constant_49(int x) {return x % 50;}
    public static int irem_by_constant_50(int x) {return x % 51;}
    public static int irem_by_constant_51(int x) {return x % 52;}
    public static int irem_by_constant_52(int x) {return x % 53;}
    public static int irem_by_constant_53(int x) {return x % 54;}
    public static int irem_by_constant_54(int x) {return x % 55;}
    public static int irem_by_constant_55(int x) {return x % 56;}
    public static int irem_by_constant_56(int x) {return x % 57;}
    public static int irem_by_constant_57(int x) {return x % 58;}
    public static int irem_by_constant_58(int x) {return x % 59;}
    public static int irem_by_constant_59(int x) {return x % 60;}
    public static int irem_by_constant_60(int x) {return x % 61;}
    public static int irem_by_constant_61(int x) {return x % 62;}
    public static int irem_by_constant_62(int x) {return x % 63;}
    public static int irem_by_constant_63(int x) {return x % 64;}
    public static int irem_by_constant_64(int x) {return x % 65;}
    public static int irem_by_constant_65(int x) {return x % 66;}
    public static int irem_by_constant_66(int x) {return x % 67;}
    public static int irem_by_constant_67(int x) {return x % 68;}
    public static int irem_by_constant_68(int x) {return x % 69;}
    public static int irem_by_constant_69(int x) {return x % 70;}
    public static int irem_by_constant_70(int x) {return x % 71;}
    public static int irem_by_constant_71(int x) {return x % 72;}
    public static int irem_by_constant_72(int x) {return x % 73;}
    public static int irem_by_constant_73(int x) {return x % 74;}
    public static int irem_by_constant_74(int x) {return x % 75;}
    public static int irem_by_constant_75(int x) {return x % 76;}
    public static int irem_by_constant_76(int x) {return x % 77;}
    public static int irem_by_constant_77(int x) {return x % 78;}
    public static int irem_by_constant_78(int x) {return x % 79;}
    public static int irem_by_constant_79(int x) {return x % 80;}
    public static int irem_by_constant_80(int x) {return x % 81;}
    public static int irem_by_constant_81(int x) {return x % 82;}
    public static int irem_by_constant_82(int x) {return x % 83;}
    public static int irem_by_constant_83(int x) {return x % 84;}
    public static int irem_by_constant_84(int x) {return x % 85;}
    public static int irem_by_constant_85(int x) {return x % 86;}
    public static int irem_by_constant_86(int x) {return x % 87;}
    public static int irem_by_constant_87(int x) {return x % 88;}
    public static int irem_by_constant_88(int x) {return x % 89;}
    public static int irem_by_constant_89(int x) {return x % 90;}
    public static int irem_by_constant_90(int x) {return x % 91;}
    public static int irem_by_constant_91(int x) {return x % 92;}
    public static int irem_by_constant_92(int x) {return x % 93;}
    public static int irem_by_constant_93(int x) {return x % 94;}
    public static int irem_by_constant_94(int x) {return x % 95;}
    public static int irem_by_constant_95(int x) {return x % 96;}
    public static int irem_by_constant_96(int x) {return x % 97;}
    public static int irem_by_constant_97(int x) {return x % 98;}
    public static int irem_by_constant_98(int x) {return x % 99;}
    public static int irem_by_constant_neg_0(int x) {return x % -1;}
    public static int irem_by_constant_neg_1(int x) {return x % -2;}
    public static int irem_by_constant_neg_2(int x) {return x % -3;}
    public static int irem_by_constant_neg_3(int x) {return x % -4;}
    public static int irem_by_constant_neg_4(int x) {return x % -5;}
    public static int irem_by_constant_neg_5(int x) {return x % -6;}
    public static int irem_by_constant_neg_6(int x) {return x % -7;}
    public static int irem_by_constant_neg_7(int x) {return x % -8;}
    public static int irem_by_constant_neg_8(int x) {return x % -9;}
    public static int irem_by_constant_neg_9(int x) {return x % -10;}
    public static int irem_by_constant_neg_10(int x) {return x % -11;}
    public static int irem_by_constant_neg_11(int x) {return x % -12;}
    public static int irem_by_constant_neg_12(int x) {return x % -13;}
    public static int irem_by_constant_neg_13(int x) {return x % -14;}
    public static int irem_by_constant_neg_14(int x) {return x % -15;}
    public static int irem_by_constant_neg_15(int x) {return x % -16;}
    public static int irem_by_constant_neg_16(int x) {return x % -17;}
    public static int irem_by_constant_neg_17(int x) {return x % -18;}
    public static int irem_by_constant_neg_18(int x) {return x % -19;}
    public static int irem_by_constant_neg_19(int x) {return x % -20;}
    public static int irem_by_constant_neg_20(int x) {return x % -21;}
    public static int irem_by_constant_neg_21(int x) {return x % -22;}
    public static int irem_by_constant_neg_22(int x) {return x % -23;}
    public static int irem_by_constant_neg_23(int x) {return x % -24;}
    public static int irem_by_constant_neg_24(int x) {return x % -25;}
    public static int irem_by_constant_neg_25(int x) {return x % -26;}
    public static int irem_by_constant_neg_26(int x) {return x % -27;}
    public static int irem_by_constant_neg_27(int x) {return x % -28;}
    public static int irem_by_constant_neg_28(int x) {return x % -29;}
    public static int irem_by_constant_neg_29(int x) {return x % -30;}
    public static int irem_by_constant_neg_30(int x) {return x % -31;}
    public static int irem_by_constant_neg_31(int x) {return x % -32;}
    public static int irem_by_constant_neg_32(int x) {return x % -33;}
    public static int irem_by_constant_neg_33(int x) {return x % -34;}
    public static int irem_by_constant_neg_34(int x) {return x % -35;}
    public static int irem_by_constant_neg_35(int x) {return x % -36;}
    public static int irem_by_constant_neg_36(int x) {return x % -37;}
    public static int irem_by_constant_neg_37(int x) {return x % -38;}
    public static int irem_by_constant_neg_38(int x) {return x % -39;}
    public static int irem_by_constant_neg_39(int x) {return x % -40;}
    public static int irem_by_constant_neg_40(int x) {return x % -41;}
    public static int irem_by_constant_neg_41(int x) {return x % -42;}
    public static int irem_by_constant_neg_42(int x) {return x % -43;}
    public static int irem_by_constant_neg_43(int x) {return x % -44;}
    public static int irem_by_constant_neg_44(int x) {return x % -45;}
    public static int irem_by_constant_neg_45(int x) {return x % -46;}
    public static int irem_by_constant_neg_46(int x) {return x % -47;}
    public static int irem_by_constant_neg_47(int x) {return x % -48;}
    public static int irem_by_constant_neg_48(int x) {return x % -49;}
    public static int irem_by_constant_neg_49(int x) {return x % -50;}
    public static int irem_by_constant_neg_50(int x) {return x % -51;}
    public static int irem_by_constant_neg_51(int x) {return x % -52;}
    public static int irem_by_constant_neg_52(int x) {return x % -53;}
    public static int irem_by_constant_neg_53(int x) {return x % -54;}
    public static int irem_by_constant_neg_54(int x) {return x % -55;}
    public static int irem_by_constant_neg_55(int x) {return x % -56;}
    public static int irem_by_constant_neg_56(int x) {return x % -57;}
    public static int irem_by_constant_neg_57(int x) {return x % -58;}
    public static int irem_by_constant_neg_58(int x) {return x % -59;}
    public static int irem_by_constant_neg_59(int x) {return x % -60;}
    public static int irem_by_constant_neg_60(int x) {return x % -61;}
    public static int irem_by_constant_neg_61(int x) {return x % -62;}
    public static int irem_by_constant_neg_62(int x) {return x % -63;}
    public static int irem_by_constant_neg_63(int x) {return x % -64;}
    public static int irem_by_constant_neg_64(int x) {return x % -65;}
    public static int irem_by_constant_neg_65(int x) {return x % -66;}
    public static int irem_by_constant_neg_66(int x) {return x % -67;}
    public static int irem_by_constant_neg_67(int x) {return x % -68;}
    public static int irem_by_constant_neg_68(int x) {return x % -69;}
    public static int irem_by_constant_neg_69(int x) {return x % -70;}
    public static int irem_by_constant_neg_70(int x) {return x % -71;}
    public static int irem_by_constant_neg_71(int x) {return x % -72;}
    public static int irem_by_constant_neg_72(int x) {return x % -73;}
    public static int irem_by_constant_neg_73(int x) {return x % -74;}
    public static int irem_by_constant_neg_74(int x) {return x % -75;}
    public static int irem_by_constant_neg_75(int x) {return x % -76;}
    public static int irem_by_constant_neg_76(int x) {return x % -77;}
    public static int irem_by_constant_neg_77(int x) {return x % -78;}
    public static int irem_by_constant_neg_78(int x) {return x % -79;}
    public static int irem_by_constant_neg_79(int x) {return x % -80;}
    public static int irem_by_constant_neg_80(int x) {return x % -81;}
    public static int irem_by_constant_neg_81(int x) {return x % -82;}
    public static int irem_by_constant_neg_82(int x) {return x % -83;}
    public static int irem_by_constant_neg_83(int x) {return x % -84;}
    public static int irem_by_constant_neg_84(int x) {return x % -85;}
    public static int irem_by_constant_neg_85(int x) {return x % -86;}
    public static int irem_by_constant_neg_86(int x) {return x % -87;}
    public static int irem_by_constant_neg_87(int x) {return x % -88;}
    public static int irem_by_constant_neg_88(int x) {return x % -89;}
    public static int irem_by_constant_neg_89(int x) {return x % -90;}
    public static int irem_by_constant_neg_90(int x) {return x % -91;}
    public static int irem_by_constant_neg_91(int x) {return x % -92;}
    public static int irem_by_constant_neg_92(int x) {return x % -93;}
    public static int irem_by_constant_neg_93(int x) {return x % -94;}
    public static int irem_by_constant_neg_94(int x) {return x % -95;}
    public static int irem_by_constant_neg_95(int x) {return x % -96;}
    public static int irem_by_constant_neg_96(int x) {return x % -97;}
    public static int irem_by_constant_neg_97(int x) {return x % -98;}
    public static int irem_by_constant_neg_98(int x) {return x % -99;}
    public static long ldiv_by_pow2_0(long x) {return x / 1l;}
    public static long ldiv_by_pow2_1(long x) {return x / 2l;}
    public static long ldiv_by_pow2_2(long x) {return x / 4l;}
    public static long ldiv_by_pow2_3(long x) {return x / 8l;}
    public static long ldiv_by_pow2_4(long x) {return x / 16l;}
    public static long ldiv_by_pow2_5(long x) {return x / 32l;}
    public static long ldiv_by_pow2_6(long x) {return x / 64l;}
    public static long ldiv_by_pow2_7(long x) {return x / 128l;}
    public static long ldiv_by_pow2_8(long x) {return x / 256l;}
    public static long ldiv_by_pow2_9(long x) {return x / 512l;}
    public static long ldiv_by_pow2_10(long x) {return x / 1024l;}
    public static long ldiv_by_pow2_11(long x) {return x / 2048l;}
    public static long ldiv_by_pow2_12(long x) {return x / 4096l;}
    public static long ldiv_by_pow2_13(long x) {return x / 8192l;}
    public static long ldiv_by_pow2_14(long x) {return x / 16384l;}
    public static long ldiv_by_pow2_15(long x) {return x / 32768l;}
    public static long ldiv_by_pow2_16(long x) {return x / 65536l;}
    public static long ldiv_by_pow2_17(long x) {return x / 131072l;}
    public static long ldiv_by_pow2_18(long x) {return x / 262144l;}
    public static long ldiv_by_pow2_19(long x) {return x / 524288l;}
    public static long ldiv_by_pow2_20(long x) {return x / 1048576l;}
    public static long ldiv_by_pow2_21(long x) {return x / 2097152l;}
    public static long ldiv_by_pow2_22(long x) {return x / 4194304l;}
    public static long ldiv_by_pow2_23(long x) {return x / 8388608l;}
    public static long ldiv_by_pow2_24(long x) {return x / 16777216l;}
    public static long ldiv_by_pow2_25(long x) {return x / 33554432l;}
    public static long ldiv_by_pow2_26(long x) {return x / 67108864l;}
    public static long ldiv_by_pow2_27(long x) {return x / 134217728l;}
    public static long ldiv_by_pow2_28(long x) {return x / 268435456l;}
    public static long ldiv_by_pow2_29(long x) {return x / 536870912l;}
    public static long ldiv_by_pow2_30(long x) {return x / 1073741824l;}
    public static long ldiv_by_pow2_31(long x) {return x / 2147483648l;}
    public static long ldiv_by_pow2_32(long x) {return x / 4294967296l;}
    public static long ldiv_by_pow2_33(long x) {return x / 8589934592l;}
    public static long ldiv_by_pow2_34(long x) {return x / 17179869184l;}
    public static long ldiv_by_pow2_35(long x) {return x / 34359738368l;}
    public static long ldiv_by_pow2_36(long x) {return x / 68719476736l;}
    public static long ldiv_by_pow2_37(long x) {return x / 137438953472l;}
    public static long ldiv_by_pow2_38(long x) {return x / 274877906944l;}
    public static long ldiv_by_pow2_39(long x) {return x / 549755813888l;}
    public static long ldiv_by_pow2_40(long x) {return x / 1099511627776l;}
    public static long ldiv_by_pow2_41(long x) {return x / 2199023255552l;}
    public static long ldiv_by_pow2_42(long x) {return x / 4398046511104l;}
    public static long ldiv_by_pow2_43(long x) {return x / 8796093022208l;}
    public static long ldiv_by_pow2_44(long x) {return x / 17592186044416l;}
    public static long ldiv_by_pow2_45(long x) {return x / 35184372088832l;}
    public static long ldiv_by_pow2_46(long x) {return x / 70368744177664l;}
    public static long ldiv_by_pow2_47(long x) {return x / 140737488355328l;}
    public static long ldiv_by_pow2_48(long x) {return x / 281474976710656l;}
    public static long ldiv_by_pow2_49(long x) {return x / 562949953421312l;}
    public static long ldiv_by_pow2_50(long x) {return x / 1125899906842624l;}
    public static long ldiv_by_pow2_51(long x) {return x / 2251799813685248l;}
    public static long ldiv_by_pow2_52(long x) {return x / 4503599627370496l;}
    public static long ldiv_by_pow2_53(long x) {return x / 9007199254740992l;}
    public static long ldiv_by_pow2_54(long x) {return x / 18014398509481984l;}
    public static long ldiv_by_pow2_55(long x) {return x / 36028797018963968l;}
    public static long ldiv_by_pow2_56(long x) {return x / 72057594037927936l;}
    public static long ldiv_by_pow2_57(long x) {return x / 144115188075855872l;}
    public static long ldiv_by_pow2_58(long x) {return x / 288230376151711744l;}
    public static long ldiv_by_pow2_59(long x) {return x / 576460752303423488l;}
    public static long ldiv_by_pow2_60(long x) {return x / 1152921504606846976l;}
    public static long ldiv_by_pow2_61(long x) {return x / 2305843009213693952l;}
    public static long ldiv_by_pow2_62(long x) {return x / 4611686018427387904l;}
    public static long ldiv_by_pow2_neg_0(long x) {return x / -1l;}
    public static long ldiv_by_pow2_neg_1(long x) {return x / -2l;}
    public static long ldiv_by_pow2_neg_2(long x) {return x / -4l;}
    public static long ldiv_by_pow2_neg_3(long x) {return x / -8l;}
    public static long ldiv_by_pow2_neg_4(long x) {return x / -16l;}
    public static long ldiv_by_pow2_neg_5(long x) {return x / -32l;}
    public static long ldiv_by_pow2_neg_6(long x) {return x / -64l;}
    public static long ldiv_by_pow2_neg_7(long x) {return x / -128l;}
    public static long ldiv_by_pow2_neg_8(long x) {return x / -256l;}
    public static long ldiv_by_pow2_neg_9(long x) {return x / -512l;}
    public static long ldiv_by_pow2_neg_10(long x) {return x / -1024l;}
    public static long ldiv_by_pow2_neg_11(long x) {return x / -2048l;}
    public static long ldiv_by_pow2_neg_12(long x) {return x / -4096l;}
    public static long ldiv_by_pow2_neg_13(long x) {return x / -8192l;}
    public static long ldiv_by_pow2_neg_14(long x) {return x / -16384l;}
    public static long ldiv_by_pow2_neg_15(long x) {return x / -32768l;}
    public static long ldiv_by_pow2_neg_16(long x) {return x / -65536l;}
    public static long ldiv_by_pow2_neg_17(long x) {return x / -131072l;}
    public static long ldiv_by_pow2_neg_18(long x) {return x / -262144l;}
    public static long ldiv_by_pow2_neg_19(long x) {return x / -524288l;}
    public static long ldiv_by_pow2_neg_20(long x) {return x / -1048576l;}
    public static long ldiv_by_pow2_neg_21(long x) {return x / -2097152l;}
    public static long ldiv_by_pow2_neg_22(long x) {return x / -4194304l;}
    public static long ldiv_by_pow2_neg_23(long x) {return x / -8388608l;}
    public static long ldiv_by_pow2_neg_24(long x) {return x / -16777216l;}
    public static long ldiv_by_pow2_neg_25(long x) {return x / -33554432l;}
    public static long ldiv_by_pow2_neg_26(long x) {return x / -67108864l;}
    public static long ldiv_by_pow2_neg_27(long x) {return x / -134217728l;}
    public static long ldiv_by_pow2_neg_28(long x) {return x / -268435456l;}
    public static long ldiv_by_pow2_neg_29(long x) {return x / -536870912l;}
    public static long ldiv_by_pow2_neg_30(long x) {return x / -1073741824l;}
    public static long ldiv_by_pow2_neg_31(long x) {return x / -2147483648l;}
    public static long ldiv_by_pow2_neg_32(long x) {return x / -4294967296l;}
    public static long ldiv_by_pow2_neg_33(long x) {return x / -8589934592l;}
    public static long ldiv_by_pow2_neg_34(long x) {return x / -17179869184l;}
    public static long ldiv_by_pow2_neg_35(long x) {return x / -34359738368l;}
    public static long ldiv_by_pow2_neg_36(long x) {return x / -68719476736l;}
    public static long ldiv_by_pow2_neg_37(long x) {return x / -137438953472l;}
    public static long ldiv_by_pow2_neg_38(long x) {return x / -274877906944l;}
    public static long ldiv_by_pow2_neg_39(long x) {return x / -549755813888l;}
    public static long ldiv_by_pow2_neg_40(long x) {return x / -1099511627776l;}
    public static long ldiv_by_pow2_neg_41(long x) {return x / -2199023255552l;}
    public static long ldiv_by_pow2_neg_42(long x) {return x / -4398046511104l;}
    public static long ldiv_by_pow2_neg_43(long x) {return x / -8796093022208l;}
    public static long ldiv_by_pow2_neg_44(long x) {return x / -17592186044416l;}
    public static long ldiv_by_pow2_neg_45(long x) {return x / -35184372088832l;}
    public static long ldiv_by_pow2_neg_46(long x) {return x / -70368744177664l;}
    public static long ldiv_by_pow2_neg_47(long x) {return x / -140737488355328l;}
    public static long ldiv_by_pow2_neg_48(long x) {return x / -281474976710656l;}
    public static long ldiv_by_pow2_neg_49(long x) {return x / -562949953421312l;}
    public static long ldiv_by_pow2_neg_50(long x) {return x / -1125899906842624l;}
    public static long ldiv_by_pow2_neg_51(long x) {return x / -2251799813685248l;}
    public static long ldiv_by_pow2_neg_52(long x) {return x / -4503599627370496l;}
    public static long ldiv_by_pow2_neg_53(long x) {return x / -9007199254740992l;}
    public static long ldiv_by_pow2_neg_54(long x) {return x / -18014398509481984l;}
    public static long ldiv_by_pow2_neg_55(long x) {return x / -36028797018963968l;}
    public static long ldiv_by_pow2_neg_56(long x) {return x / -72057594037927936l;}
    public static long ldiv_by_pow2_neg_57(long x) {return x / -144115188075855872l;}
    public static long ldiv_by_pow2_neg_58(long x) {return x / -288230376151711744l;}
    public static long ldiv_by_pow2_neg_59(long x) {return x / -576460752303423488l;}
    public static long ldiv_by_pow2_neg_60(long x) {return x / -1152921504606846976l;}
    public static long ldiv_by_pow2_neg_61(long x) {return x / -2305843009213693952l;}
    public static long ldiv_by_pow2_neg_62(long x) {return x / -4611686018427387904l;}
    public static long ldiv_by_pow2_neg_63(long x) {return x / -9223372036854775808l;}
    public static long ldiv_by_constant_0(long x) {return x / 1l;}
    public static long ldiv_by_constant_1(long x) {return x / 2l;}
    public static long ldiv_by_constant_2(long x) {return x / 3l;}
    public static long ldiv_by_constant_3(long x) {return x / 4l;}
    public static long ldiv_by_constant_4(long x) {return x / 5l;}
    public static long ldiv_by_constant_5(long x) {return x / 6l;}
    public static long ldiv_by_constant_6(long x) {return x / 7l;}
    public static long ldiv_by_constant_7(long x) {return x / 8l;}
    public static long ldiv_by_constant_8(long x) {return x / 9l;}
    public static long ldiv_by_constant_9(long x) {return x / 10l;}
    public static long ldiv_by_constant_10(long x) {return x / 11l;}
    public static long ldiv_by_constant_11(long x) {return x / 12l;}
    public static long ldiv_by_constant_12(long x) {return x / 13l;}
    public static long ldiv_by_constant_13(long x) {return x / 14l;}
    public static long ldiv_by_constant_14(long x) {return x / 15l;}
    public static long ldiv_by_constant_15(long x) {return x / 16l;}
    public static long ldiv_by_constant_16(long x) {return x / 17l;}
    public static long ldiv_by_constant_17(long x) {return x / 18l;}
    public static long ldiv_by_constant_18(long x) {return x / 19l;}
    public static long ldiv_by_constant_19(long x) {return x / 20l;}
    public static long ldiv_by_constant_20(long x) {return x / 21l;}
    public static long ldiv_by_constant_21(long x) {return x / 22l;}
    public static long ldiv_by_constant_22(long x) {return x / 23l;}
    public static long ldiv_by_constant_23(long x) {return x / 24l;}
    public static long ldiv_by_constant_24(long x) {return x / 25l;}
    public static long ldiv_by_constant_25(long x) {return x / 26l;}
    public static long ldiv_by_constant_26(long x) {return x / 27l;}
    public static long ldiv_by_constant_27(long x) {return x / 28l;}
    public static long ldiv_by_constant_28(long x) {return x / 29l;}
    public static long ldiv_by_constant_29(long x) {return x / 30l;}
    public static long ldiv_by_constant_30(long x) {return x / 31l;}
    public static long ldiv_by_constant_31(long x) {return x / 32l;}
    public static long ldiv_by_constant_32(long x) {return x / 33l;}
    public static long ldiv_by_constant_33(long x) {return x / 34l;}
    public static long ldiv_by_constant_34(long x) {return x / 35l;}
    public static long ldiv_by_constant_35(long x) {return x / 36l;}
    public static long ldiv_by_constant_36(long x) {return x / 37l;}
    public static long ldiv_by_constant_37(long x) {return x / 38l;}
    public static long ldiv_by_constant_38(long x) {return x / 39l;}
    public static long ldiv_by_constant_39(long x) {return x / 40l;}
    public static long ldiv_by_constant_40(long x) {return x / 41l;}
    public static long ldiv_by_constant_41(long x) {return x / 42l;}
    public static long ldiv_by_constant_42(long x) {return x / 43l;}
    public static long ldiv_by_constant_43(long x) {return x / 44l;}
    public static long ldiv_by_constant_44(long x) {return x / 45l;}
    public static long ldiv_by_constant_45(long x) {return x / 46l;}
    public static long ldiv_by_constant_46(long x) {return x / 47l;}
    public static long ldiv_by_constant_47(long x) {return x / 48l;}
    public static long ldiv_by_constant_48(long x) {return x / 49l;}
    public static long ldiv_by_constant_49(long x) {return x / 50l;}
    public static long ldiv_by_constant_50(long x) {return x / 51l;}
    public static long ldiv_by_constant_51(long x) {return x / 52l;}
    public static long ldiv_by_constant_52(long x) {return x / 53l;}
    public static long ldiv_by_constant_53(long x) {return x / 54l;}
    public static long ldiv_by_constant_54(long x) {return x / 55l;}
    public static long ldiv_by_constant_55(long x) {return x / 56l;}
    public static long ldiv_by_constant_56(long x) {return x / 57l;}
    public static long ldiv_by_constant_57(long x) {return x / 58l;}
    public static long ldiv_by_constant_58(long x) {return x / 59l;}
    public static long ldiv_by_constant_59(long x) {return x / 60l;}
    public static long ldiv_by_constant_60(long x) {return x / 61l;}
    public static long ldiv_by_constant_61(long x) {return x / 62l;}
    public static long ldiv_by_constant_62(long x) {return x / 63l;}
    public static long ldiv_by_constant_63(long x) {return x / 64l;}
    public static long ldiv_by_constant_64(long x) {return x / 65l;}
    public static long ldiv_by_constant_65(long x) {return x / 66l;}
    public static long ldiv_by_constant_66(long x) {return x / 67l;}
    public static long ldiv_by_constant_67(long x) {return x / 68l;}
    public static long ldiv_by_constant_68(long x) {return x / 69l;}
    public static long ldiv_by_constant_69(long x) {return x / 70l;}
    public static long ldiv_by_constant_70(long x) {return x / 71l;}
    public static long ldiv_by_constant_71(long x) {return x / 72l;}
    public static long ldiv_by_constant_72(long x) {return x / 73l;}
    public static long ldiv_by_constant_73(long x) {return x / 74l;}
    public static long ldiv_by_constant_74(long x) {return x / 75l;}
    public static long ldiv_by_constant_75(long x) {return x / 76l;}
    public static long ldiv_by_constant_76(long x) {return x / 77l;}
    public static long ldiv_by_constant_77(long x) {return x / 78l;}
    public static long ldiv_by_constant_78(long x) {return x / 79l;}
    public static long ldiv_by_constant_79(long x) {return x / 80l;}
    public static long ldiv_by_constant_80(long x) {return x / 81l;}
    public static long ldiv_by_constant_81(long x) {return x / 82l;}
    public static long ldiv_by_constant_82(long x) {return x / 83l;}
    public static long ldiv_by_constant_83(long x) {return x / 84l;}
    public static long ldiv_by_constant_84(long x) {return x / 85l;}
    public static long ldiv_by_constant_85(long x) {return x / 86l;}
    public static long ldiv_by_constant_86(long x) {return x / 87l;}
    public static long ldiv_by_constant_87(long x) {return x / 88l;}
    public static long ldiv_by_constant_88(long x) {return x / 89l;}
    public static long ldiv_by_constant_89(long x) {return x / 90l;}
    public static long ldiv_by_constant_90(long x) {return x / 91l;}
    public static long ldiv_by_constant_91(long x) {return x / 92l;}
    public static long ldiv_by_constant_92(long x) {return x / 93l;}
    public static long ldiv_by_constant_93(long x) {return x / 94l;}
    public static long ldiv_by_constant_94(long x) {return x / 95l;}
    public static long ldiv_by_constant_95(long x) {return x / 96l;}
    public static long ldiv_by_constant_96(long x) {return x / 97l;}
    public static long ldiv_by_constant_97(long x) {return x / 98l;}
    public static long ldiv_by_constant_98(long x) {return x / 99l;}
    public static long ldiv_by_constant_neg_0(long x) {return x / -1l;}
    public static long ldiv_by_constant_neg_1(long x) {return x / -2l;}
    public static long ldiv_by_constant_neg_2(long x) {return x / -3l;}
    public static long ldiv_by_constant_neg_3(long x) {return x / -4l;}
    public static long ldiv_by_constant_neg_4(long x) {return x / -5l;}
    public static long ldiv_by_constant_neg_5(long x) {return x / -6l;}
    public static long ldiv_by_constant_neg_6(long x) {return x / -7l;}
    public static long ldiv_by_constant_neg_7(long x) {return x / -8l;}
    public static long ldiv_by_constant_neg_8(long x) {return x / -9l;}
    public static long ldiv_by_constant_neg_9(long x) {return x / -10l;}
    public static long ldiv_by_constant_neg_10(long x) {return x / -11l;}
    public static long ldiv_by_constant_neg_11(long x) {return x / -12l;}
    public static long ldiv_by_constant_neg_12(long x) {return x / -13l;}
    public static long ldiv_by_constant_neg_13(long x) {return x / -14l;}
    public static long ldiv_by_constant_neg_14(long x) {return x / -15l;}
    public static long ldiv_by_constant_neg_15(long x) {return x / -16l;}
    public static long ldiv_by_constant_neg_16(long x) {return x / -17l;}
    public static long ldiv_by_constant_neg_17(long x) {return x / -18l;}
    public static long ldiv_by_constant_neg_18(long x) {return x / -19l;}
    public static long ldiv_by_constant_neg_19(long x) {return x / -20l;}
    public static long ldiv_by_constant_neg_20(long x) {return x / -21l;}
    public static long ldiv_by_constant_neg_21(long x) {return x / -22l;}
    public static long ldiv_by_constant_neg_22(long x) {return x / -23l;}
    public static long ldiv_by_constant_neg_23(long x) {return x / -24l;}
    public static long ldiv_by_constant_neg_24(long x) {return x / -25l;}
    public static long ldiv_by_constant_neg_25(long x) {return x / -26l;}
    public static long ldiv_by_constant_neg_26(long x) {return x / -27l;}
    public static long ldiv_by_constant_neg_27(long x) {return x / -28l;}
    public static long ldiv_by_constant_neg_28(long x) {return x / -29l;}
    public static long ldiv_by_constant_neg_29(long x) {return x / -30l;}
    public static long ldiv_by_constant_neg_30(long x) {return x / -31l;}
    public static long ldiv_by_constant_neg_31(long x) {return x / -32l;}
    public static long ldiv_by_constant_neg_32(long x) {return x / -33l;}
    public static long ldiv_by_constant_neg_33(long x) {return x / -34l;}
    public static long ldiv_by_constant_neg_34(long x) {return x / -35l;}
    public static long ldiv_by_constant_neg_35(long x) {return x / -36l;}
    public static long ldiv_by_constant_neg_36(long x) {return x / -37l;}
    public static long ldiv_by_constant_neg_37(long x) {return x / -38l;}
    public static long ldiv_by_constant_neg_38(long x) {return x / -39l;}
    public static long ldiv_by_constant_neg_39(long x) {return x / -40l;}
    public static long ldiv_by_constant_neg_40(long x) {return x / -41l;}
    public static long ldiv_by_constant_neg_41(long x) {return x / -42l;}
    public static long ldiv_by_constant_neg_42(long x) {return x / -43l;}
    public static long ldiv_by_constant_neg_43(long x) {return x / -44l;}
    public static long ldiv_by_constant_neg_44(long x) {return x / -45l;}
    public static long ldiv_by_constant_neg_45(long x) {return x / -46l;}
    public static long ldiv_by_constant_neg_46(long x) {return x / -47l;}
    public static long ldiv_by_constant_neg_47(long x) {return x / -48l;}
    public static long ldiv_by_constant_neg_48(long x) {return x / -49l;}
    public static long ldiv_by_constant_neg_49(long x) {return x / -50l;}
    public static long ldiv_by_constant_neg_50(long x) {return x / -51l;}
    public static long ldiv_by_constant_neg_51(long x) {return x / -52l;}
    public static long ldiv_by_constant_neg_52(long x) {return x / -53l;}
    public static long ldiv_by_constant_neg_53(long x) {return x / -54l;}
    public static long ldiv_by_constant_neg_54(long x) {return x / -55l;}
    public static long ldiv_by_constant_neg_55(long x) {return x / -56l;}
    public static long ldiv_by_constant_neg_56(long x) {return x / -57l;}
    public static long ldiv_by_constant_neg_57(long x) {return x / -58l;}
    public static long ldiv_by_constant_neg_58(long x) {return x / -59l;}
    public static long ldiv_by_constant_neg_59(long x) {return x / -60l;}
    public static long ldiv_by_constant_neg_60(long x) {return x / -61l;}
    public static long ldiv_by_constant_neg_61(long x) {return x / -62l;}
    public static long ldiv_by_constant_neg_62(long x) {return x / -63l;}
    public static long ldiv_by_constant_neg_63(long x) {return x / -64l;}
    public static long ldiv_by_constant_neg_64(long x) {return x / -65l;}
    public static long ldiv_by_constant_neg_65(long x) {return x / -66l;}
    public static long ldiv_by_constant_neg_66(long x) {return x / -67l;}
    public static long ldiv_by_constant_neg_67(long x) {return x / -68l;}
    public static long ldiv_by_constant_neg_68(long x) {return x / -69l;}
    public static long ldiv_by_constant_neg_69(long x) {return x / -70l;}
    public static long ldiv_by_constant_neg_70(long x) {return x / -71l;}
    public static long ldiv_by_constant_neg_71(long x) {return x / -72l;}
    public static long ldiv_by_constant_neg_72(long x) {return x / -73l;}
    public static long ldiv_by_constant_neg_73(long x) {return x / -74l;}
    public static long ldiv_by_constant_neg_74(long x) {return x / -75l;}
    public static long ldiv_by_constant_neg_75(long x) {return x / -76l;}
    public static long ldiv_by_constant_neg_76(long x) {return x / -77l;}
    public static long ldiv_by_constant_neg_77(long x) {return x / -78l;}
    public static long ldiv_by_constant_neg_78(long x) {return x / -79l;}
    public static long ldiv_by_constant_neg_79(long x) {return x / -80l;}
    public static long ldiv_by_constant_neg_80(long x) {return x / -81l;}
    public static long ldiv_by_constant_neg_81(long x) {return x / -82l;}
    public static long ldiv_by_constant_neg_82(long x) {return x / -83l;}
    public static long ldiv_by_constant_neg_83(long x) {return x / -84l;}
    public static long ldiv_by_constant_neg_84(long x) {return x / -85l;}
    public static long ldiv_by_constant_neg_85(long x) {return x / -86l;}
    public static long ldiv_by_constant_neg_86(long x) {return x / -87l;}
    public static long ldiv_by_constant_neg_87(long x) {return x / -88l;}
    public static long ldiv_by_constant_neg_88(long x) {return x / -89l;}
    public static long ldiv_by_constant_neg_89(long x) {return x / -90l;}
    public static long ldiv_by_constant_neg_90(long x) {return x / -91l;}
    public static long ldiv_by_constant_neg_91(long x) {return x / -92l;}
    public static long ldiv_by_constant_neg_92(long x) {return x / -93l;}
    public static long ldiv_by_constant_neg_93(long x) {return x / -94l;}
    public static long ldiv_by_constant_neg_94(long x) {return x / -95l;}
    public static long ldiv_by_constant_neg_95(long x) {return x / -96l;}
    public static long ldiv_by_constant_neg_96(long x) {return x / -97l;}
    public static long ldiv_by_constant_neg_97(long x) {return x / -98l;}
    public static long ldiv_by_constant_neg_98(long x) {return x / -99l;}
    public static long lrem_by_pow2_0(long x) {return x % 1l;}
    public static long lrem_by_pow2_1(long x) {return x % 2l;}
    public static long lrem_by_pow2_2(long x) {return x % 4l;}
    public static long lrem_by_pow2_3(long x) {return x % 8l;}
    public static long lrem_by_pow2_4(long x) {return x % 16l;}
    public static long lrem_by_pow2_5(long x) {return x % 32l;}
    public static long lrem_by_pow2_6(long x) {return x % 64l;}
    public static long lrem_by_pow2_7(long x) {return x % 128l;}
    public static long lrem_by_pow2_8(long x) {return x % 256l;}
    public static long lrem_by_pow2_9(long x) {return x % 512l;}
    public static long lrem_by_pow2_10(long x) {return x % 1024l;}
    public static long lrem_by_pow2_11(long x) {return x % 2048l;}
    public static long lrem_by_pow2_12(long x) {return x % 4096l;}
    public static long lrem_by_pow2_13(long x) {return x % 8192l;}
    public static long lrem_by_pow2_14(long x) {return x % 16384l;}
    public static long lrem_by_pow2_15(long x) {return x % 32768l;}
    public static long lrem_by_pow2_16(long x) {return x % 65536l;}
    public static long lrem_by_pow2_17(long x) {return x % 131072l;}
    public static long lrem_by_pow2_18(long x) {return x % 262144l;}
    public static long lrem_by_pow2_19(long x) {return x % 524288l;}
    public static long lrem_by_pow2_20(long x) {return x % 1048576l;}
    public static long lrem_by_pow2_21(long x) {return x % 2097152l;}
    public static long lrem_by_pow2_22(long x) {return x % 4194304l;}
    public static long lrem_by_pow2_23(long x) {return x % 8388608l;}
    public static long lrem_by_pow2_24(long x) {return x % 16777216l;}
    public static long lrem_by_pow2_25(long x) {return x % 33554432l;}
    public static long lrem_by_pow2_26(long x) {return x % 67108864l;}
    public static long lrem_by_pow2_27(long x) {return x % 134217728l;}
    public static long lrem_by_pow2_28(long x) {return x % 268435456l;}
    public static long lrem_by_pow2_29(long x) {return x % 536870912l;}
    public static long lrem_by_pow2_30(long x) {return x % 1073741824l;}
    public static long lrem_by_pow2_31(long x) {return x % 2147483648l;}
    public static long lrem_by_pow2_32(long x) {return x % 4294967296l;}
    public static long lrem_by_pow2_33(long x) {return x % 8589934592l;}
    public static long lrem_by_pow2_34(long x) {return x % 17179869184l;}
    public static long lrem_by_pow2_35(long x) {return x % 34359738368l;}
    public static long lrem_by_pow2_36(long x) {return x % 68719476736l;}
    public static long lrem_by_pow2_37(long x) {return x % 137438953472l;}
    public static long lrem_by_pow2_38(long x) {return x % 274877906944l;}
    public static long lrem_by_pow2_39(long x) {return x % 549755813888l;}
    public static long lrem_by_pow2_40(long x) {return x % 1099511627776l;}
    public static long lrem_by_pow2_41(long x) {return x % 2199023255552l;}
    public static long lrem_by_pow2_42(long x) {return x % 4398046511104l;}
    public static long lrem_by_pow2_43(long x) {return x % 8796093022208l;}
    public static long lrem_by_pow2_44(long x) {return x % 17592186044416l;}
    public static long lrem_by_pow2_45(long x) {return x % 35184372088832l;}
    public static long lrem_by_pow2_46(long x) {return x % 70368744177664l;}
    public static long lrem_by_pow2_47(long x) {return x % 140737488355328l;}
    public static long lrem_by_pow2_48(long x) {return x % 281474976710656l;}
    public static long lrem_by_pow2_49(long x) {return x % 562949953421312l;}
    public static long lrem_by_pow2_50(long x) {return x % 1125899906842624l;}
    public static long lrem_by_pow2_51(long x) {return x % 2251799813685248l;}
    public static long lrem_by_pow2_52(long x) {return x % 4503599627370496l;}
    public static long lrem_by_pow2_53(long x) {return x % 9007199254740992l;}
    public static long lrem_by_pow2_54(long x) {return x % 18014398509481984l;}
    public static long lrem_by_pow2_55(long x) {return x % 36028797018963968l;}
    public static long lrem_by_pow2_56(long x) {return x % 72057594037927936l;}
    public static long lrem_by_pow2_57(long x) {return x % 144115188075855872l;}
    public static long lrem_by_pow2_58(long x) {return x % 288230376151711744l;}
    public static long lrem_by_pow2_59(long x) {return x % 576460752303423488l;}
    public static long lrem_by_pow2_60(long x) {return x % 1152921504606846976l;}
    public static long lrem_by_pow2_61(long x) {return x % 2305843009213693952l;}
    public static long lrem_by_pow2_62(long x) {return x % 4611686018427387904l;}
    public static long lrem_by_pow2_neg_0(long x) {return x % -1l;}
    public static long lrem_by_pow2_neg_1(long x) {return x % -2l;}
    public static long lrem_by_pow2_neg_2(long x) {return x % -4l;}
    public static long lrem_by_pow2_neg_3(long x) {return x % -8l;}
    public static long lrem_by_pow2_neg_4(long x) {return x % -16l;}
    public static long lrem_by_pow2_neg_5(long x) {return x % -32l;}
    public static long lrem_by_pow2_neg_6(long x) {return x % -64l;}
    public static long lrem_by_pow2_neg_7(long x) {return x % -128l;}
    public static long lrem_by_pow2_neg_8(long x) {return x % -256l;}
    public static long lrem_by_pow2_neg_9(long x) {return x % -512l;}
    public static long lrem_by_pow2_neg_10(long x) {return x % -1024l;}
    public static long lrem_by_pow2_neg_11(long x) {return x % -2048l;}
    public static long lrem_by_pow2_neg_12(long x) {return x % -4096l;}
    public static long lrem_by_pow2_neg_13(long x) {return x % -8192l;}
    public static long lrem_by_pow2_neg_14(long x) {return x % -16384l;}
    public static long lrem_by_pow2_neg_15(long x) {return x % -32768l;}
    public static long lrem_by_pow2_neg_16(long x) {return x % -65536l;}
    public static long lrem_by_pow2_neg_17(long x) {return x % -131072l;}
    public static long lrem_by_pow2_neg_18(long x) {return x % -262144l;}
    public static long lrem_by_pow2_neg_19(long x) {return x % -524288l;}
    public static long lrem_by_pow2_neg_20(long x) {return x % -1048576l;}
    public static long lrem_by_pow2_neg_21(long x) {return x % -2097152l;}
    public static long lrem_by_pow2_neg_22(long x) {return x % -4194304l;}
    public static long lrem_by_pow2_neg_23(long x) {return x % -8388608l;}
    public static long lrem_by_pow2_neg_24(long x) {return x % -16777216l;}
    public static long lrem_by_pow2_neg_25(long x) {return x % -33554432l;}
    public static long lrem_by_pow2_neg_26(long x) {return x % -67108864l;}
    public static long lrem_by_pow2_neg_27(long x) {return x % -134217728l;}
    public static long lrem_by_pow2_neg_28(long x) {return x % -268435456l;}
    public static long lrem_by_pow2_neg_29(long x) {return x % -536870912l;}
    public static long lrem_by_pow2_neg_30(long x) {return x % -1073741824l;}
    public static long lrem_by_pow2_neg_31(long x) {return x % -2147483648l;}
    public static long lrem_by_pow2_neg_32(long x) {return x % -4294967296l;}
    public static long lrem_by_pow2_neg_33(long x) {return x % -8589934592l;}
    public static long lrem_by_pow2_neg_34(long x) {return x % -17179869184l;}
    public static long lrem_by_pow2_neg_35(long x) {return x % -34359738368l;}
    public static long lrem_by_pow2_neg_36(long x) {return x % -68719476736l;}
    public static long lrem_by_pow2_neg_37(long x) {return x % -137438953472l;}
    public static long lrem_by_pow2_neg_38(long x) {return x % -274877906944l;}
    public static long lrem_by_pow2_neg_39(long x) {return x % -549755813888l;}
    public static long lrem_by_pow2_neg_40(long x) {return x % -1099511627776l;}
    public static long lrem_by_pow2_neg_41(long x) {return x % -2199023255552l;}
    public static long lrem_by_pow2_neg_42(long x) {return x % -4398046511104l;}
    public static long lrem_by_pow2_neg_43(long x) {return x % -8796093022208l;}
    public static long lrem_by_pow2_neg_44(long x) {return x % -17592186044416l;}
    public static long lrem_by_pow2_neg_45(long x) {return x % -35184372088832l;}
    public static long lrem_by_pow2_neg_46(long x) {return x % -70368744177664l;}
    public static long lrem_by_pow2_neg_47(long x) {return x % -140737488355328l;}
    public static long lrem_by_pow2_neg_48(long x) {return x % -281474976710656l;}
    public static long lrem_by_pow2_neg_49(long x) {return x % -562949953421312l;}
    public static long lrem_by_pow2_neg_50(long x) {return x % -1125899906842624l;}
    public static long lrem_by_pow2_neg_51(long x) {return x % -2251799813685248l;}
    public static long lrem_by_pow2_neg_52(long x) {return x % -4503599627370496l;}
    public static long lrem_by_pow2_neg_53(long x) {return x % -9007199254740992l;}
    public static long lrem_by_pow2_neg_54(long x) {return x % -18014398509481984l;}
    public static long lrem_by_pow2_neg_55(long x) {return x % -36028797018963968l;}
    public static long lrem_by_pow2_neg_56(long x) {return x % -72057594037927936l;}
    public static long lrem_by_pow2_neg_57(long x) {return x % -144115188075855872l;}
    public static long lrem_by_pow2_neg_58(long x) {return x % -288230376151711744l;}
    public static long lrem_by_pow2_neg_59(long x) {return x % -576460752303423488l;}
    public static long lrem_by_pow2_neg_60(long x) {return x % -1152921504606846976l;}
    public static long lrem_by_pow2_neg_61(long x) {return x % -2305843009213693952l;}
    public static long lrem_by_pow2_neg_62(long x) {return x % -4611686018427387904l;}
    public static long lrem_by_pow2_neg_63(long x) {return x % -9223372036854775808l;}
    public static long lrem_by_constant_0(long x) {return x % 1l;}
    public static long lrem_by_constant_1(long x) {return x % 2l;}
    public static long lrem_by_constant_2(long x) {return x % 3l;}
    public static long lrem_by_constant_3(long x) {return x % 4l;}
    public static long lrem_by_constant_4(long x) {return x % 5l;}
    public static long lrem_by_constant_5(long x) {return x % 6l;}
    public static long lrem_by_constant_6(long x) {return x % 7l;}
    public static long lrem_by_constant_7(long x) {return x % 8l;}
    public static long lrem_by_constant_8(long x) {return x % 9l;}
    public static long lrem_by_constant_9(long x) {return x % 10l;}
    public static long lrem_by_constant_10(long x) {return x % 11l;}
    public static long lrem_by_constant_11(long x) {return x % 12l;}
    public static long lrem_by_constant_12(long x) {return x % 13l;}
    public static long lrem_by_constant_13(long x) {return x % 14l;}
    public static long lrem_by_constant_14(long x) {return x % 15l;}
    public static long lrem_by_constant_15(long x) {return x % 16l;}
    public static long lrem_by_constant_16(long x) {return x % 17l;}
    public static long lrem_by_constant_17(long x) {return x % 18l;}
    public static long lrem_by_constant_18(long x) {return x % 19l;}
    public static long lrem_by_constant_19(long x) {return x % 20l;}
    public static long lrem_by_constant_20(long x) {return x % 21l;}
    public static long lrem_by_constant_21(long x) {return x % 22l;}
    public static long lrem_by_constant_22(long x) {return x % 23l;}
    public static long lrem_by_constant_23(long x) {return x % 24l;}
    public static long lrem_by_constant_24(long x) {return x % 25l;}
    public static long lrem_by_constant_25(long x) {return x % 26l;}
    public static long lrem_by_constant_26(long x) {return x % 27l;}
    public static long lrem_by_constant_27(long x) {return x % 28l;}
    public static long lrem_by_constant_28(long x) {return x % 29l;}
    public static long lrem_by_constant_29(long x) {return x % 30l;}
    public static long lrem_by_constant_30(long x) {return x % 31l;}
    public static long lrem_by_constant_31(long x) {return x % 32l;}
    public static long lrem_by_constant_32(long x) {return x % 33l;}
    public static long lrem_by_constant_33(long x) {return x % 34l;}
    public static long lrem_by_constant_34(long x) {return x % 35l;}
    public static long lrem_by_constant_35(long x) {return x % 36l;}
    public static long lrem_by_constant_36(long x) {return x % 37l;}
    public static long lrem_by_constant_37(long x) {return x % 38l;}
    public static long lrem_by_constant_38(long x) {return x % 39l;}
    public static long lrem_by_constant_39(long x) {return x % 40l;}
    public static long lrem_by_constant_40(long x) {return x % 41l;}
    public static long lrem_by_constant_41(long x) {return x % 42l;}
    public static long lrem_by_constant_42(long x) {return x % 43l;}
    public static long lrem_by_constant_43(long x) {return x % 44l;}
    public static long lrem_by_constant_44(long x) {return x % 45l;}
    public static long lrem_by_constant_45(long x) {return x % 46l;}
    public static long lrem_by_constant_46(long x) {return x % 47l;}
    public static long lrem_by_constant_47(long x) {return x % 48l;}
    public static long lrem_by_constant_48(long x) {return x % 49l;}
    public static long lrem_by_constant_49(long x) {return x % 50l;}
    public static long lrem_by_constant_50(long x) {return x % 51l;}
    public static long lrem_by_constant_51(long x) {return x % 52l;}
    public static long lrem_by_constant_52(long x) {return x % 53l;}
    public static long lrem_by_constant_53(long x) {return x % 54l;}
    public static long lrem_by_constant_54(long x) {return x % 55l;}
    public static long lrem_by_constant_55(long x) {return x % 56l;}
    public static long lrem_by_constant_56(long x) {return x % 57l;}
    public static long lrem_by_constant_57(long x) {return x % 58l;}
    public static long lrem_by_constant_58(long x) {return x % 59l;}
    public static long lrem_by_constant_59(long x) {return x % 60l;}
    public static long lrem_by_constant_60(long x) {return x % 61l;}
    public static long lrem_by_constant_61(long x) {return x % 62l;}
    public static long lrem_by_constant_62(long x) {return x % 63l;}
    public static long lrem_by_constant_63(long x) {return x % 64l;}
    public static long lrem_by_constant_64(long x) {return x % 65l;}
    public static long lrem_by_constant_65(long x) {return x % 66l;}
    public static long lrem_by_constant_66(long x) {return x % 67l;}
    public static long lrem_by_constant_67(long x) {return x % 68l;}
    public static long lrem_by_constant_68(long x) {return x % 69l;}
    public static long lrem_by_constant_69(long x) {return x % 70l;}
    public static long lrem_by_constant_70(long x) {return x % 71l;}
    public static long lrem_by_constant_71(long x) {return x % 72l;}
    public static long lrem_by_constant_72(long x) {return x % 73l;}
    public static long lrem_by_constant_73(long x) {return x % 74l;}
    public static long lrem_by_constant_74(long x) {return x % 75l;}
    public static long lrem_by_constant_75(long x) {return x % 76l;}
    public static long lrem_by_constant_76(long x) {return x % 77l;}
    public static long lrem_by_constant_77(long x) {return x % 78l;}
    public static long lrem_by_constant_78(long x) {return x % 79l;}
    public static long lrem_by_constant_79(long x) {return x % 80l;}
    public static long lrem_by_constant_80(long x) {return x % 81l;}
    public static long lrem_by_constant_81(long x) {return x % 82l;}
    public static long lrem_by_constant_82(long x) {return x % 83l;}
    public static long lrem_by_constant_83(long x) {return x % 84l;}
    public static long lrem_by_constant_84(long x) {return x % 85l;}
    public static long lrem_by_constant_85(long x) {return x % 86l;}
    public static long lrem_by_constant_86(long x) {return x % 87l;}
    public static long lrem_by_constant_87(long x) {return x % 88l;}
    public static long lrem_by_constant_88(long x) {return x % 89l;}
    public static long lrem_by_constant_89(long x) {return x % 90l;}
    public static long lrem_by_constant_90(long x) {return x % 91l;}
    public static long lrem_by_constant_91(long x) {return x % 92l;}
    public static long lrem_by_constant_92(long x) {return x % 93l;}
    public static long lrem_by_constant_93(long x) {return x % 94l;}
    public static long lrem_by_constant_94(long x) {return x % 95l;}
    public static long lrem_by_constant_95(long x) {return x % 96l;}
    public static long lrem_by_constant_96(long x) {return x % 97l;}
    public static long lrem_by_constant_97(long x) {return x % 98l;}
    public static long lrem_by_constant_98(long x) {return x % 99l;}
    public static long lrem_by_constant_neg_0(long x) {return x % -1l;}
    public static long lrem_by_constant_neg_1(long x) {return x % -2l;}
    public static long lrem_by_constant_neg_2(long x) {return x % -3l;}
    public static long lrem_by_constant_neg_3(long x) {return x % -4l;}
    public static long lrem_by_constant_neg_4(long x) {return x % -5l;}
    public static long lrem_by_constant_neg_5(long x) {return x % -6l;}
    public static long lrem_by_constant_neg_6(long x) {return x % -7l;}
    public static long lrem_by_constant_neg_7(long x) {return x % -8l;}
    public static long lrem_by_constant_neg_8(long x) {return x % -9l;}
    public static long lrem_by_constant_neg_9(long x) {return x % -10l;}
    public static long lrem_by_constant_neg_10(long x) {return x % -11l;}
    public static long lrem_by_constant_neg_11(long x) {return x % -12l;}
    public static long lrem_by_constant_neg_12(long x) {return x % -13l;}
    public static long lrem_by_constant_neg_13(long x) {return x % -14l;}
    public static long lrem_by_constant_neg_14(long x) {return x % -15l;}
    public static long lrem_by_constant_neg_15(long x) {return x % -16l;}
    public static long lrem_by_constant_neg_16(long x) {return x % -17l;}
    public static long lrem_by_constant_neg_17(long x) {return x % -18l;}
    public static long lrem_by_constant_neg_18(long x) {return x % -19l;}
    public static long lrem_by_constant_neg_19(long x) {return x % -20l;}
    public static long lrem_by_constant_neg_20(long x) {return x % -21l;}
    public static long lrem_by_constant_neg_21(long x) {return x % -22l;}
    public static long lrem_by_constant_neg_22(long x) {return x % -23l;}
    public static long lrem_by_constant_neg_23(long x) {return x % -24l;}
    public static long lrem_by_constant_neg_24(long x) {return x % -25l;}
    public static long lrem_by_constant_neg_25(long x) {return x % -26l;}
    public static long lrem_by_constant_neg_26(long x) {return x % -27l;}
    public static long lrem_by_constant_neg_27(long x) {return x % -28l;}
    public static long lrem_by_constant_neg_28(long x) {return x % -29l;}
    public static long lrem_by_constant_neg_29(long x) {return x % -30l;}
    public static long lrem_by_constant_neg_30(long x) {return x % -31l;}
    public static long lrem_by_constant_neg_31(long x) {return x % -32l;}
    public static long lrem_by_constant_neg_32(long x) {return x % -33l;}
    public static long lrem_by_constant_neg_33(long x) {return x % -34l;}
    public static long lrem_by_constant_neg_34(long x) {return x % -35l;}
    public static long lrem_by_constant_neg_35(long x) {return x % -36l;}
    public static long lrem_by_constant_neg_36(long x) {return x % -37l;}
    public static long lrem_by_constant_neg_37(long x) {return x % -38l;}
    public static long lrem_by_constant_neg_38(long x) {return x % -39l;}
    public static long lrem_by_constant_neg_39(long x) {return x % -40l;}
    public static long lrem_by_constant_neg_40(long x) {return x % -41l;}
    public static long lrem_by_constant_neg_41(long x) {return x % -42l;}
    public static long lrem_by_constant_neg_42(long x) {return x % -43l;}
    public static long lrem_by_constant_neg_43(long x) {return x % -44l;}
    public static long lrem_by_constant_neg_44(long x) {return x % -45l;}
    public static long lrem_by_constant_neg_45(long x) {return x % -46l;}
    public static long lrem_by_constant_neg_46(long x) {return x % -47l;}
    public static long lrem_by_constant_neg_47(long x) {return x % -48l;}
    public static long lrem_by_constant_neg_48(long x) {return x % -49l;}
    public static long lrem_by_constant_neg_49(long x) {return x % -50l;}
    public static long lrem_by_constant_neg_50(long x) {return x % -51l;}
    public static long lrem_by_constant_neg_51(long x) {return x % -52l;}
    public static long lrem_by_constant_neg_52(long x) {return x % -53l;}
    public static long lrem_by_constant_neg_53(long x) {return x % -54l;}
    public static long lrem_by_constant_neg_54(long x) {return x % -55l;}
    public static long lrem_by_constant_neg_55(long x) {return x % -56l;}
    public static long lrem_by_constant_neg_56(long x) {return x % -57l;}
    public static long lrem_by_constant_neg_57(long x) {return x % -58l;}
    public static long lrem_by_constant_neg_58(long x) {return x % -59l;}
    public static long lrem_by_constant_neg_59(long x) {return x % -60l;}
    public static long lrem_by_constant_neg_60(long x) {return x % -61l;}
    public static long lrem_by_constant_neg_61(long x) {return x % -62l;}
    public static long lrem_by_constant_neg_62(long x) {return x % -63l;}
    public static long lrem_by_constant_neg_63(long x) {return x % -64l;}
    public static long lrem_by_constant_neg_64(long x) {return x % -65l;}
    public static long lrem_by_constant_neg_65(long x) {return x % -66l;}
    public static long lrem_by_constant_neg_66(long x) {return x % -67l;}
    public static long lrem_by_constant_neg_67(long x) {return x % -68l;}
    public static long lrem_by_constant_neg_68(long x) {return x % -69l;}
    public static long lrem_by_constant_neg_69(long x) {return x % -70l;}
    public static long lrem_by_constant_neg_70(long x) {return x % -71l;}
    public static long lrem_by_constant_neg_71(long x) {return x % -72l;}
    public static long lrem_by_constant_neg_72(long x) {return x % -73l;}
    public static long lrem_by_constant_neg_73(long x) {return x % -74l;}
    public static long lrem_by_constant_neg_74(long x) {return x % -75l;}
    public static long lrem_by_constant_neg_75(long x) {return x % -76l;}
    public static long lrem_by_constant_neg_76(long x) {return x % -77l;}
    public static long lrem_by_constant_neg_77(long x) {return x % -78l;}
    public static long lrem_by_constant_neg_78(long x) {return x % -79l;}
    public static long lrem_by_constant_neg_79(long x) {return x % -80l;}
    public static long lrem_by_constant_neg_80(long x) {return x % -81l;}
    public static long lrem_by_constant_neg_81(long x) {return x % -82l;}
    public static long lrem_by_constant_neg_82(long x) {return x % -83l;}
    public static long lrem_by_constant_neg_83(long x) {return x % -84l;}
    public static long lrem_by_constant_neg_84(long x) {return x % -85l;}
    public static long lrem_by_constant_neg_85(long x) {return x % -86l;}
    public static long lrem_by_constant_neg_86(long x) {return x % -87l;}
    public static long lrem_by_constant_neg_87(long x) {return x % -88l;}
    public static long lrem_by_constant_neg_88(long x) {return x % -89l;}
    public static long lrem_by_constant_neg_89(long x) {return x % -90l;}
    public static long lrem_by_constant_neg_90(long x) {return x % -91l;}
    public static long lrem_by_constant_neg_91(long x) {return x % -92l;}
    public static long lrem_by_constant_neg_92(long x) {return x % -93l;}
    public static long lrem_by_constant_neg_93(long x) {return x % -94l;}
    public static long lrem_by_constant_neg_94(long x) {return x % -95l;}
    public static long lrem_by_constant_neg_95(long x) {return x % -96l;}
    public static long lrem_by_constant_neg_96(long x) {return x % -97l;}
    public static long lrem_by_constant_neg_97(long x) {return x % -98l;}
    public static long lrem_by_constant_neg_98(long x) {return x % -99l;}

    public static void intCheckAll(int x) {
        intCheckDiv("idiv_by_pow2_0", idiv_by_pow2_0(x), x, 1);
        intCheckDiv("idiv_by_pow2_1", idiv_by_pow2_1(x), x, 2);
        intCheckDiv("idiv_by_pow2_2", idiv_by_pow2_2(x), x, 4);
        intCheckDiv("idiv_by_pow2_3", idiv_by_pow2_3(x), x, 8);
        intCheckDiv("idiv_by_pow2_4", idiv_by_pow2_4(x), x, 16);
        intCheckDiv("idiv_by_pow2_5", idiv_by_pow2_5(x), x, 32);
        intCheckDiv("idiv_by_pow2_6", idiv_by_pow2_6(x), x, 64);
        intCheckDiv("idiv_by_pow2_7", idiv_by_pow2_7(x), x, 128);
        intCheckDiv("idiv_by_pow2_8", idiv_by_pow2_8(x), x, 256);
        intCheckDiv("idiv_by_pow2_9", idiv_by_pow2_9(x), x, 512);
        intCheckDiv("idiv_by_pow2_10", idiv_by_pow2_10(x), x, 1024);
        intCheckDiv("idiv_by_pow2_11", idiv_by_pow2_11(x), x, 2048);
        intCheckDiv("idiv_by_pow2_12", idiv_by_pow2_12(x), x, 4096);
        intCheckDiv("idiv_by_pow2_13", idiv_by_pow2_13(x), x, 8192);
        intCheckDiv("idiv_by_pow2_14", idiv_by_pow2_14(x), x, 16384);
        intCheckDiv("idiv_by_pow2_15", idiv_by_pow2_15(x), x, 32768);
        intCheckDiv("idiv_by_pow2_16", idiv_by_pow2_16(x), x, 65536);
        intCheckDiv("idiv_by_pow2_17", idiv_by_pow2_17(x), x, 131072);
        intCheckDiv("idiv_by_pow2_18", idiv_by_pow2_18(x), x, 262144);
        intCheckDiv("idiv_by_pow2_19", idiv_by_pow2_19(x), x, 524288);
        intCheckDiv("idiv_by_pow2_20", idiv_by_pow2_20(x), x, 1048576);
        intCheckDiv("idiv_by_pow2_21", idiv_by_pow2_21(x), x, 2097152);
        intCheckDiv("idiv_by_pow2_22", idiv_by_pow2_22(x), x, 4194304);
        intCheckDiv("idiv_by_pow2_23", idiv_by_pow2_23(x), x, 8388608);
        intCheckDiv("idiv_by_pow2_24", idiv_by_pow2_24(x), x, 16777216);
        intCheckDiv("idiv_by_pow2_25", idiv_by_pow2_25(x), x, 33554432);
        intCheckDiv("idiv_by_pow2_26", idiv_by_pow2_26(x), x, 67108864);
        intCheckDiv("idiv_by_pow2_27", idiv_by_pow2_27(x), x, 134217728);
        intCheckDiv("idiv_by_pow2_28", idiv_by_pow2_28(x), x, 268435456);
        intCheckDiv("idiv_by_pow2_29", idiv_by_pow2_29(x), x, 536870912);
        intCheckDiv("idiv_by_pow2_30", idiv_by_pow2_30(x), x, 1073741824);
        intCheckDiv("idiv_by_pow2_neg_0", idiv_by_pow2_neg_0(x), x, -1);
        intCheckDiv("idiv_by_pow2_neg_1", idiv_by_pow2_neg_1(x), x, -2);
        intCheckDiv("idiv_by_pow2_neg_2", idiv_by_pow2_neg_2(x), x, -4);
        intCheckDiv("idiv_by_pow2_neg_3", idiv_by_pow2_neg_3(x), x, -8);
        intCheckDiv("idiv_by_pow2_neg_4", idiv_by_pow2_neg_4(x), x, -16);
        intCheckDiv("idiv_by_pow2_neg_5", idiv_by_pow2_neg_5(x), x, -32);
        intCheckDiv("idiv_by_pow2_neg_6", idiv_by_pow2_neg_6(x), x, -64);
        intCheckDiv("idiv_by_pow2_neg_7", idiv_by_pow2_neg_7(x), x, -128);
        intCheckDiv("idiv_by_pow2_neg_8", idiv_by_pow2_neg_8(x), x, -256);
        intCheckDiv("idiv_by_pow2_neg_9", idiv_by_pow2_neg_9(x), x, -512);
        intCheckDiv("idiv_by_pow2_neg_10", idiv_by_pow2_neg_10(x), x, -1024);
        intCheckDiv("idiv_by_pow2_neg_11", idiv_by_pow2_neg_11(x), x, -2048);
        intCheckDiv("idiv_by_pow2_neg_12", idiv_by_pow2_neg_12(x), x, -4096);
        intCheckDiv("idiv_by_pow2_neg_13", idiv_by_pow2_neg_13(x), x, -8192);
        intCheckDiv("idiv_by_pow2_neg_14", idiv_by_pow2_neg_14(x), x, -16384);
        intCheckDiv("idiv_by_pow2_neg_15", idiv_by_pow2_neg_15(x), x, -32768);
        intCheckDiv("idiv_by_pow2_neg_16", idiv_by_pow2_neg_16(x), x, -65536);
        intCheckDiv("idiv_by_pow2_neg_17", idiv_by_pow2_neg_17(x), x, -131072);
        intCheckDiv("idiv_by_pow2_neg_18", idiv_by_pow2_neg_18(x), x, -262144);
        intCheckDiv("idiv_by_pow2_neg_19", idiv_by_pow2_neg_19(x), x, -524288);
        intCheckDiv("idiv_by_pow2_neg_20", idiv_by_pow2_neg_20(x), x, -1048576);
        intCheckDiv("idiv_by_pow2_neg_21", idiv_by_pow2_neg_21(x), x, -2097152);
        intCheckDiv("idiv_by_pow2_neg_22", idiv_by_pow2_neg_22(x), x, -4194304);
        intCheckDiv("idiv_by_pow2_neg_23", idiv_by_pow2_neg_23(x), x, -8388608);
        intCheckDiv("idiv_by_pow2_neg_24", idiv_by_pow2_neg_24(x), x, -16777216);
        intCheckDiv("idiv_by_pow2_neg_25", idiv_by_pow2_neg_25(x), x, -33554432);
        intCheckDiv("idiv_by_pow2_neg_26", idiv_by_pow2_neg_26(x), x, -67108864);
        intCheckDiv("idiv_by_pow2_neg_27", idiv_by_pow2_neg_27(x), x, -134217728);
        intCheckDiv("idiv_by_pow2_neg_28", idiv_by_pow2_neg_28(x), x, -268435456);
        intCheckDiv("idiv_by_pow2_neg_29", idiv_by_pow2_neg_29(x), x, -536870912);
        intCheckDiv("idiv_by_pow2_neg_30", idiv_by_pow2_neg_30(x), x, -1073741824);
        intCheckDiv("idiv_by_pow2_neg_31", idiv_by_pow2_neg_31(x), x, -2147483648);
        intCheckDiv("idiv_by_constant_0", idiv_by_constant_0(x), x, 1);
        intCheckDiv("idiv_by_constant_1", idiv_by_constant_1(x), x, 2);
        intCheckDiv("idiv_by_constant_2", idiv_by_constant_2(x), x, 3);
        intCheckDiv("idiv_by_constant_3", idiv_by_constant_3(x), x, 4);
        intCheckDiv("idiv_by_constant_4", idiv_by_constant_4(x), x, 5);
        intCheckDiv("idiv_by_constant_5", idiv_by_constant_5(x), x, 6);
        intCheckDiv("idiv_by_constant_6", idiv_by_constant_6(x), x, 7);
        intCheckDiv("idiv_by_constant_7", idiv_by_constant_7(x), x, 8);
        intCheckDiv("idiv_by_constant_8", idiv_by_constant_8(x), x, 9);
        intCheckDiv("idiv_by_constant_9", idiv_by_constant_9(x), x, 10);
        intCheckDiv("idiv_by_constant_10", idiv_by_constant_10(x), x, 11);
        intCheckDiv("idiv_by_constant_11", idiv_by_constant_11(x), x, 12);
        intCheckDiv("idiv_by_constant_12", idiv_by_constant_12(x), x, 13);
        intCheckDiv("idiv_by_constant_13", idiv_by_constant_13(x), x, 14);
        intCheckDiv("idiv_by_constant_14", idiv_by_constant_14(x), x, 15);
        intCheckDiv("idiv_by_constant_15", idiv_by_constant_15(x), x, 16);
        intCheckDiv("idiv_by_constant_16", idiv_by_constant_16(x), x, 17);
        intCheckDiv("idiv_by_constant_17", idiv_by_constant_17(x), x, 18);
        intCheckDiv("idiv_by_constant_18", idiv_by_constant_18(x), x, 19);
        intCheckDiv("idiv_by_constant_19", idiv_by_constant_19(x), x, 20);
        intCheckDiv("idiv_by_constant_20", idiv_by_constant_20(x), x, 21);
        intCheckDiv("idiv_by_constant_21", idiv_by_constant_21(x), x, 22);
        intCheckDiv("idiv_by_constant_22", idiv_by_constant_22(x), x, 23);
        intCheckDiv("idiv_by_constant_23", idiv_by_constant_23(x), x, 24);
        intCheckDiv("idiv_by_constant_24", idiv_by_constant_24(x), x, 25);
        intCheckDiv("idiv_by_constant_25", idiv_by_constant_25(x), x, 26);
        intCheckDiv("idiv_by_constant_26", idiv_by_constant_26(x), x, 27);
        intCheckDiv("idiv_by_constant_27", idiv_by_constant_27(x), x, 28);
        intCheckDiv("idiv_by_constant_28", idiv_by_constant_28(x), x, 29);
        intCheckDiv("idiv_by_constant_29", idiv_by_constant_29(x), x, 30);
        intCheckDiv("idiv_by_constant_30", idiv_by_constant_30(x), x, 31);
        intCheckDiv("idiv_by_constant_31", idiv_by_constant_31(x), x, 32);
        intCheckDiv("idiv_by_constant_32", idiv_by_constant_32(x), x, 33);
        intCheckDiv("idiv_by_constant_33", idiv_by_constant_33(x), x, 34);
        intCheckDiv("idiv_by_constant_34", idiv_by_constant_34(x), x, 35);
        intCheckDiv("idiv_by_constant_35", idiv_by_constant_35(x), x, 36);
        intCheckDiv("idiv_by_constant_36", idiv_by_constant_36(x), x, 37);
        intCheckDiv("idiv_by_constant_37", idiv_by_constant_37(x), x, 38);
        intCheckDiv("idiv_by_constant_38", idiv_by_constant_38(x), x, 39);
        intCheckDiv("idiv_by_constant_39", idiv_by_constant_39(x), x, 40);
        intCheckDiv("idiv_by_constant_40", idiv_by_constant_40(x), x, 41);
        intCheckDiv("idiv_by_constant_41", idiv_by_constant_41(x), x, 42);
        intCheckDiv("idiv_by_constant_42", idiv_by_constant_42(x), x, 43);
        intCheckDiv("idiv_by_constant_43", idiv_by_constant_43(x), x, 44);
        intCheckDiv("idiv_by_constant_44", idiv_by_constant_44(x), x, 45);
        intCheckDiv("idiv_by_constant_45", idiv_by_constant_45(x), x, 46);
        intCheckDiv("idiv_by_constant_46", idiv_by_constant_46(x), x, 47);
        intCheckDiv("idiv_by_constant_47", idiv_by_constant_47(x), x, 48);
        intCheckDiv("idiv_by_constant_48", idiv_by_constant_48(x), x, 49);
        intCheckDiv("idiv_by_constant_49", idiv_by_constant_49(x), x, 50);
        intCheckDiv("idiv_by_constant_50", idiv_by_constant_50(x), x, 51);
        intCheckDiv("idiv_by_constant_51", idiv_by_constant_51(x), x, 52);
        intCheckDiv("idiv_by_constant_52", idiv_by_constant_52(x), x, 53);
        intCheckDiv("idiv_by_constant_53", idiv_by_constant_53(x), x, 54);
        intCheckDiv("idiv_by_constant_54", idiv_by_constant_54(x), x, 55);
        intCheckDiv("idiv_by_constant_55", idiv_by_constant_55(x), x, 56);
        intCheckDiv("idiv_by_constant_56", idiv_by_constant_56(x), x, 57);
        intCheckDiv("idiv_by_constant_57", idiv_by_constant_57(x), x, 58);
        intCheckDiv("idiv_by_constant_58", idiv_by_constant_58(x), x, 59);
        intCheckDiv("idiv_by_constant_59", idiv_by_constant_59(x), x, 60);
        intCheckDiv("idiv_by_constant_60", idiv_by_constant_60(x), x, 61);
        intCheckDiv("idiv_by_constant_61", idiv_by_constant_61(x), x, 62);
        intCheckDiv("idiv_by_constant_62", idiv_by_constant_62(x), x, 63);
        intCheckDiv("idiv_by_constant_63", idiv_by_constant_63(x), x, 64);
        intCheckDiv("idiv_by_constant_64", idiv_by_constant_64(x), x, 65);
        intCheckDiv("idiv_by_constant_65", idiv_by_constant_65(x), x, 66);
        intCheckDiv("idiv_by_constant_66", idiv_by_constant_66(x), x, 67);
        intCheckDiv("idiv_by_constant_67", idiv_by_constant_67(x), x, 68);
        intCheckDiv("idiv_by_constant_68", idiv_by_constant_68(x), x, 69);
        intCheckDiv("idiv_by_constant_69", idiv_by_constant_69(x), x, 70);
        intCheckDiv("idiv_by_constant_70", idiv_by_constant_70(x), x, 71);
        intCheckDiv("idiv_by_constant_71", idiv_by_constant_71(x), x, 72);
        intCheckDiv("idiv_by_constant_72", idiv_by_constant_72(x), x, 73);
        intCheckDiv("idiv_by_constant_73", idiv_by_constant_73(x), x, 74);
        intCheckDiv("idiv_by_constant_74", idiv_by_constant_74(x), x, 75);
        intCheckDiv("idiv_by_constant_75", idiv_by_constant_75(x), x, 76);
        intCheckDiv("idiv_by_constant_76", idiv_by_constant_76(x), x, 77);
        intCheckDiv("idiv_by_constant_77", idiv_by_constant_77(x), x, 78);
        intCheckDiv("idiv_by_constant_78", idiv_by_constant_78(x), x, 79);
        intCheckDiv("idiv_by_constant_79", idiv_by_constant_79(x), x, 80);
        intCheckDiv("idiv_by_constant_80", idiv_by_constant_80(x), x, 81);
        intCheckDiv("idiv_by_constant_81", idiv_by_constant_81(x), x, 82);
        intCheckDiv("idiv_by_constant_82", idiv_by_constant_82(x), x, 83);
        intCheckDiv("idiv_by_constant_83", idiv_by_constant_83(x), x, 84);
        intCheckDiv("idiv_by_constant_84", idiv_by_constant_84(x), x, 85);
        intCheckDiv("idiv_by_constant_85", idiv_by_constant_85(x), x, 86);
        intCheckDiv("idiv_by_constant_86", idiv_by_constant_86(x), x, 87);
        intCheckDiv("idiv_by_constant_87", idiv_by_constant_87(x), x, 88);
        intCheckDiv("idiv_by_constant_88", idiv_by_constant_88(x), x, 89);
        intCheckDiv("idiv_by_constant_89", idiv_by_constant_89(x), x, 90);
        intCheckDiv("idiv_by_constant_90", idiv_by_constant_90(x), x, 91);
        intCheckDiv("idiv_by_constant_91", idiv_by_constant_91(x), x, 92);
        intCheckDiv("idiv_by_constant_92", idiv_by_constant_92(x), x, 93);
        intCheckDiv("idiv_by_constant_93", idiv_by_constant_93(x), x, 94);
        intCheckDiv("idiv_by_constant_94", idiv_by_constant_94(x), x, 95);
        intCheckDiv("idiv_by_constant_95", idiv_by_constant_95(x), x, 96);
        intCheckDiv("idiv_by_constant_96", idiv_by_constant_96(x), x, 97);
        intCheckDiv("idiv_by_constant_97", idiv_by_constant_97(x), x, 98);
        intCheckDiv("idiv_by_constant_98", idiv_by_constant_98(x), x, 99);
        intCheckDiv("idiv_by_constant_neg_0", idiv_by_constant_neg_0(x), x, -1);
        intCheckDiv("idiv_by_constant_neg_1", idiv_by_constant_neg_1(x), x, -2);
        intCheckDiv("idiv_by_constant_neg_2", idiv_by_constant_neg_2(x), x, -3);
        intCheckDiv("idiv_by_constant_neg_3", idiv_by_constant_neg_3(x), x, -4);
        intCheckDiv("idiv_by_constant_neg_4", idiv_by_constant_neg_4(x), x, -5);
        intCheckDiv("idiv_by_constant_neg_5", idiv_by_constant_neg_5(x), x, -6);
        intCheckDiv("idiv_by_constant_neg_6", idiv_by_constant_neg_6(x), x, -7);
        intCheckDiv("idiv_by_constant_neg_7", idiv_by_constant_neg_7(x), x, -8);
        intCheckDiv("idiv_by_constant_neg_8", idiv_by_constant_neg_8(x), x, -9);
        intCheckDiv("idiv_by_constant_neg_9", idiv_by_constant_neg_9(x), x, -10);
        intCheckDiv("idiv_by_constant_neg_10", idiv_by_constant_neg_10(x), x, -11);
        intCheckDiv("idiv_by_constant_neg_11", idiv_by_constant_neg_11(x), x, -12);
        intCheckDiv("idiv_by_constant_neg_12", idiv_by_constant_neg_12(x), x, -13);
        intCheckDiv("idiv_by_constant_neg_13", idiv_by_constant_neg_13(x), x, -14);
        intCheckDiv("idiv_by_constant_neg_14", idiv_by_constant_neg_14(x), x, -15);
        intCheckDiv("idiv_by_constant_neg_15", idiv_by_constant_neg_15(x), x, -16);
        intCheckDiv("idiv_by_constant_neg_16", idiv_by_constant_neg_16(x), x, -17);
        intCheckDiv("idiv_by_constant_neg_17", idiv_by_constant_neg_17(x), x, -18);
        intCheckDiv("idiv_by_constant_neg_18", idiv_by_constant_neg_18(x), x, -19);
        intCheckDiv("idiv_by_constant_neg_19", idiv_by_constant_neg_19(x), x, -20);
        intCheckDiv("idiv_by_constant_neg_20", idiv_by_constant_neg_20(x), x, -21);
        intCheckDiv("idiv_by_constant_neg_21", idiv_by_constant_neg_21(x), x, -22);
        intCheckDiv("idiv_by_constant_neg_22", idiv_by_constant_neg_22(x), x, -23);
        intCheckDiv("idiv_by_constant_neg_23", idiv_by_constant_neg_23(x), x, -24);
        intCheckDiv("idiv_by_constant_neg_24", idiv_by_constant_neg_24(x), x, -25);
        intCheckDiv("idiv_by_constant_neg_25", idiv_by_constant_neg_25(x), x, -26);
        intCheckDiv("idiv_by_constant_neg_26", idiv_by_constant_neg_26(x), x, -27);
        intCheckDiv("idiv_by_constant_neg_27", idiv_by_constant_neg_27(x), x, -28);
        intCheckDiv("idiv_by_constant_neg_28", idiv_by_constant_neg_28(x), x, -29);
        intCheckDiv("idiv_by_constant_neg_29", idiv_by_constant_neg_29(x), x, -30);
        intCheckDiv("idiv_by_constant_neg_30", idiv_by_constant_neg_30(x), x, -31);
        intCheckDiv("idiv_by_constant_neg_31", idiv_by_constant_neg_31(x), x, -32);
        intCheckDiv("idiv_by_constant_neg_32", idiv_by_constant_neg_32(x), x, -33);
        intCheckDiv("idiv_by_constant_neg_33", idiv_by_constant_neg_33(x), x, -34);
        intCheckDiv("idiv_by_constant_neg_34", idiv_by_constant_neg_34(x), x, -35);
        intCheckDiv("idiv_by_constant_neg_35", idiv_by_constant_neg_35(x), x, -36);
        intCheckDiv("idiv_by_constant_neg_36", idiv_by_constant_neg_36(x), x, -37);
        intCheckDiv("idiv_by_constant_neg_37", idiv_by_constant_neg_37(x), x, -38);
        intCheckDiv("idiv_by_constant_neg_38", idiv_by_constant_neg_38(x), x, -39);
        intCheckDiv("idiv_by_constant_neg_39", idiv_by_constant_neg_39(x), x, -40);
        intCheckDiv("idiv_by_constant_neg_40", idiv_by_constant_neg_40(x), x, -41);
        intCheckDiv("idiv_by_constant_neg_41", idiv_by_constant_neg_41(x), x, -42);
        intCheckDiv("idiv_by_constant_neg_42", idiv_by_constant_neg_42(x), x, -43);
        intCheckDiv("idiv_by_constant_neg_43", idiv_by_constant_neg_43(x), x, -44);
        intCheckDiv("idiv_by_constant_neg_44", idiv_by_constant_neg_44(x), x, -45);
        intCheckDiv("idiv_by_constant_neg_45", idiv_by_constant_neg_45(x), x, -46);
        intCheckDiv("idiv_by_constant_neg_46", idiv_by_constant_neg_46(x), x, -47);
        intCheckDiv("idiv_by_constant_neg_47", idiv_by_constant_neg_47(x), x, -48);
        intCheckDiv("idiv_by_constant_neg_48", idiv_by_constant_neg_48(x), x, -49);
        intCheckDiv("idiv_by_constant_neg_49", idiv_by_constant_neg_49(x), x, -50);
        intCheckDiv("idiv_by_constant_neg_50", idiv_by_constant_neg_50(x), x, -51);
        intCheckDiv("idiv_by_constant_neg_51", idiv_by_constant_neg_51(x), x, -52);
        intCheckDiv("idiv_by_constant_neg_52", idiv_by_constant_neg_52(x), x, -53);
        intCheckDiv("idiv_by_constant_neg_53", idiv_by_constant_neg_53(x), x, -54);
        intCheckDiv("idiv_by_constant_neg_54", idiv_by_constant_neg_54(x), x, -55);
        intCheckDiv("idiv_by_constant_neg_55", idiv_by_constant_neg_55(x), x, -56);
        intCheckDiv("idiv_by_constant_neg_56", idiv_by_constant_neg_56(x), x, -57);
        intCheckDiv("idiv_by_constant_neg_57", idiv_by_constant_neg_57(x), x, -58);
        intCheckDiv("idiv_by_constant_neg_58", idiv_by_constant_neg_58(x), x, -59);
        intCheckDiv("idiv_by_constant_neg_59", idiv_by_constant_neg_59(x), x, -60);
        intCheckDiv("idiv_by_constant_neg_60", idiv_by_constant_neg_60(x), x, -61);
        intCheckDiv("idiv_by_constant_neg_61", idiv_by_constant_neg_61(x), x, -62);
        intCheckDiv("idiv_by_constant_neg_62", idiv_by_constant_neg_62(x), x, -63);
        intCheckDiv("idiv_by_constant_neg_63", idiv_by_constant_neg_63(x), x, -64);
        intCheckDiv("idiv_by_constant_neg_64", idiv_by_constant_neg_64(x), x, -65);
        intCheckDiv("idiv_by_constant_neg_65", idiv_by_constant_neg_65(x), x, -66);
        intCheckDiv("idiv_by_constant_neg_66", idiv_by_constant_neg_66(x), x, -67);
        intCheckDiv("idiv_by_constant_neg_67", idiv_by_constant_neg_67(x), x, -68);
        intCheckDiv("idiv_by_constant_neg_68", idiv_by_constant_neg_68(x), x, -69);
        intCheckDiv("idiv_by_constant_neg_69", idiv_by_constant_neg_69(x), x, -70);
        intCheckDiv("idiv_by_constant_neg_70", idiv_by_constant_neg_70(x), x, -71);
        intCheckDiv("idiv_by_constant_neg_71", idiv_by_constant_neg_71(x), x, -72);
        intCheckDiv("idiv_by_constant_neg_72", idiv_by_constant_neg_72(x), x, -73);
        intCheckDiv("idiv_by_constant_neg_73", idiv_by_constant_neg_73(x), x, -74);
        intCheckDiv("idiv_by_constant_neg_74", idiv_by_constant_neg_74(x), x, -75);
        intCheckDiv("idiv_by_constant_neg_75", idiv_by_constant_neg_75(x), x, -76);
        intCheckDiv("idiv_by_constant_neg_76", idiv_by_constant_neg_76(x), x, -77);
        intCheckDiv("idiv_by_constant_neg_77", idiv_by_constant_neg_77(x), x, -78);
        intCheckDiv("idiv_by_constant_neg_78", idiv_by_constant_neg_78(x), x, -79);
        intCheckDiv("idiv_by_constant_neg_79", idiv_by_constant_neg_79(x), x, -80);
        intCheckDiv("idiv_by_constant_neg_80", idiv_by_constant_neg_80(x), x, -81);
        intCheckDiv("idiv_by_constant_neg_81", idiv_by_constant_neg_81(x), x, -82);
        intCheckDiv("idiv_by_constant_neg_82", idiv_by_constant_neg_82(x), x, -83);
        intCheckDiv("idiv_by_constant_neg_83", idiv_by_constant_neg_83(x), x, -84);
        intCheckDiv("idiv_by_constant_neg_84", idiv_by_constant_neg_84(x), x, -85);
        intCheckDiv("idiv_by_constant_neg_85", idiv_by_constant_neg_85(x), x, -86);
        intCheckDiv("idiv_by_constant_neg_86", idiv_by_constant_neg_86(x), x, -87);
        intCheckDiv("idiv_by_constant_neg_87", idiv_by_constant_neg_87(x), x, -88);
        intCheckDiv("idiv_by_constant_neg_88", idiv_by_constant_neg_88(x), x, -89);
        intCheckDiv("idiv_by_constant_neg_89", idiv_by_constant_neg_89(x), x, -90);
        intCheckDiv("idiv_by_constant_neg_90", idiv_by_constant_neg_90(x), x, -91);
        intCheckDiv("idiv_by_constant_neg_91", idiv_by_constant_neg_91(x), x, -92);
        intCheckDiv("idiv_by_constant_neg_92", idiv_by_constant_neg_92(x), x, -93);
        intCheckDiv("idiv_by_constant_neg_93", idiv_by_constant_neg_93(x), x, -94);
        intCheckDiv("idiv_by_constant_neg_94", idiv_by_constant_neg_94(x), x, -95);
        intCheckDiv("idiv_by_constant_neg_95", idiv_by_constant_neg_95(x), x, -96);
        intCheckDiv("idiv_by_constant_neg_96", idiv_by_constant_neg_96(x), x, -97);
        intCheckDiv("idiv_by_constant_neg_97", idiv_by_constant_neg_97(x), x, -98);
        intCheckDiv("idiv_by_constant_neg_98", idiv_by_constant_neg_98(x), x, -99);
        intCheckRem("irem_by_pow2_0", irem_by_pow2_0(x), x, 1);
        intCheckRem("irem_by_pow2_1", irem_by_pow2_1(x), x, 2);
        intCheckRem("irem_by_pow2_2", irem_by_pow2_2(x), x, 4);
        intCheckRem("irem_by_pow2_3", irem_by_pow2_3(x), x, 8);
        intCheckRem("irem_by_pow2_4", irem_by_pow2_4(x), x, 16);
        intCheckRem("irem_by_pow2_5", irem_by_pow2_5(x), x, 32);
        intCheckRem("irem_by_pow2_6", irem_by_pow2_6(x), x, 64);
        intCheckRem("irem_by_pow2_7", irem_by_pow2_7(x), x, 128);
        intCheckRem("irem_by_pow2_8", irem_by_pow2_8(x), x, 256);
        intCheckRem("irem_by_pow2_9", irem_by_pow2_9(x), x, 512);
        intCheckRem("irem_by_pow2_10", irem_by_pow2_10(x), x, 1024);
        intCheckRem("irem_by_pow2_11", irem_by_pow2_11(x), x, 2048);
        intCheckRem("irem_by_pow2_12", irem_by_pow2_12(x), x, 4096);
        intCheckRem("irem_by_pow2_13", irem_by_pow2_13(x), x, 8192);
        intCheckRem("irem_by_pow2_14", irem_by_pow2_14(x), x, 16384);
        intCheckRem("irem_by_pow2_15", irem_by_pow2_15(x), x, 32768);
        intCheckRem("irem_by_pow2_16", irem_by_pow2_16(x), x, 65536);
        intCheckRem("irem_by_pow2_17", irem_by_pow2_17(x), x, 131072);
        intCheckRem("irem_by_pow2_18", irem_by_pow2_18(x), x, 262144);
        intCheckRem("irem_by_pow2_19", irem_by_pow2_19(x), x, 524288);
        intCheckRem("irem_by_pow2_20", irem_by_pow2_20(x), x, 1048576);
        intCheckRem("irem_by_pow2_21", irem_by_pow2_21(x), x, 2097152);
        intCheckRem("irem_by_pow2_22", irem_by_pow2_22(x), x, 4194304);
        intCheckRem("irem_by_pow2_23", irem_by_pow2_23(x), x, 8388608);
        intCheckRem("irem_by_pow2_24", irem_by_pow2_24(x), x, 16777216);
        intCheckRem("irem_by_pow2_25", irem_by_pow2_25(x), x, 33554432);
        intCheckRem("irem_by_pow2_26", irem_by_pow2_26(x), x, 67108864);
        intCheckRem("irem_by_pow2_27", irem_by_pow2_27(x), x, 134217728);
        intCheckRem("irem_by_pow2_28", irem_by_pow2_28(x), x, 268435456);
        intCheckRem("irem_by_pow2_29", irem_by_pow2_29(x), x, 536870912);
        intCheckRem("irem_by_pow2_30", irem_by_pow2_30(x), x, 1073741824);
        intCheckRem("irem_by_pow2_neg_0", irem_by_pow2_neg_0(x), x, -1);
        intCheckRem("irem_by_pow2_neg_1", irem_by_pow2_neg_1(x), x, -2);
        intCheckRem("irem_by_pow2_neg_2", irem_by_pow2_neg_2(x), x, -4);
        intCheckRem("irem_by_pow2_neg_3", irem_by_pow2_neg_3(x), x, -8);
        intCheckRem("irem_by_pow2_neg_4", irem_by_pow2_neg_4(x), x, -16);
        intCheckRem("irem_by_pow2_neg_5", irem_by_pow2_neg_5(x), x, -32);
        intCheckRem("irem_by_pow2_neg_6", irem_by_pow2_neg_6(x), x, -64);
        intCheckRem("irem_by_pow2_neg_7", irem_by_pow2_neg_7(x), x, -128);
        intCheckRem("irem_by_pow2_neg_8", irem_by_pow2_neg_8(x), x, -256);
        intCheckRem("irem_by_pow2_neg_9", irem_by_pow2_neg_9(x), x, -512);
        intCheckRem("irem_by_pow2_neg_10", irem_by_pow2_neg_10(x), x, -1024);
        intCheckRem("irem_by_pow2_neg_11", irem_by_pow2_neg_11(x), x, -2048);
        intCheckRem("irem_by_pow2_neg_12", irem_by_pow2_neg_12(x), x, -4096);
        intCheckRem("irem_by_pow2_neg_13", irem_by_pow2_neg_13(x), x, -8192);
        intCheckRem("irem_by_pow2_neg_14", irem_by_pow2_neg_14(x), x, -16384);
        intCheckRem("irem_by_pow2_neg_15", irem_by_pow2_neg_15(x), x, -32768);
        intCheckRem("irem_by_pow2_neg_16", irem_by_pow2_neg_16(x), x, -65536);
        intCheckRem("irem_by_pow2_neg_17", irem_by_pow2_neg_17(x), x, -131072);
        intCheckRem("irem_by_pow2_neg_18", irem_by_pow2_neg_18(x), x, -262144);
        intCheckRem("irem_by_pow2_neg_19", irem_by_pow2_neg_19(x), x, -524288);
        intCheckRem("irem_by_pow2_neg_20", irem_by_pow2_neg_20(x), x, -1048576);
        intCheckRem("irem_by_pow2_neg_21", irem_by_pow2_neg_21(x), x, -2097152);
        intCheckRem("irem_by_pow2_neg_22", irem_by_pow2_neg_22(x), x, -4194304);
        intCheckRem("irem_by_pow2_neg_23", irem_by_pow2_neg_23(x), x, -8388608);
        intCheckRem("irem_by_pow2_neg_24", irem_by_pow2_neg_24(x), x, -16777216);
        intCheckRem("irem_by_pow2_neg_25", irem_by_pow2_neg_25(x), x, -33554432);
        intCheckRem("irem_by_pow2_neg_26", irem_by_pow2_neg_26(x), x, -67108864);
        intCheckRem("irem_by_pow2_neg_27", irem_by_pow2_neg_27(x), x, -134217728);
        intCheckRem("irem_by_pow2_neg_28", irem_by_pow2_neg_28(x), x, -268435456);
        intCheckRem("irem_by_pow2_neg_29", irem_by_pow2_neg_29(x), x, -536870912);
        intCheckRem("irem_by_pow2_neg_30", irem_by_pow2_neg_30(x), x, -1073741824);
        intCheckRem("irem_by_pow2_neg_31", irem_by_pow2_neg_31(x), x, -2147483648);
        intCheckRem("irem_by_constant_0", irem_by_constant_0(x), x, 1);
        intCheckRem("irem_by_constant_1", irem_by_constant_1(x), x, 2);
        intCheckRem("irem_by_constant_2", irem_by_constant_2(x), x, 3);
        intCheckRem("irem_by_constant_3", irem_by_constant_3(x), x, 4);
        intCheckRem("irem_by_constant_4", irem_by_constant_4(x), x, 5);
        intCheckRem("irem_by_constant_5", irem_by_constant_5(x), x, 6);
        intCheckRem("irem_by_constant_6", irem_by_constant_6(x), x, 7);
        intCheckRem("irem_by_constant_7", irem_by_constant_7(x), x, 8);
        intCheckRem("irem_by_constant_8", irem_by_constant_8(x), x, 9);
        intCheckRem("irem_by_constant_9", irem_by_constant_9(x), x, 10);
        intCheckRem("irem_by_constant_10", irem_by_constant_10(x), x, 11);
        intCheckRem("irem_by_constant_11", irem_by_constant_11(x), x, 12);
        intCheckRem("irem_by_constant_12", irem_by_constant_12(x), x, 13);
        intCheckRem("irem_by_constant_13", irem_by_constant_13(x), x, 14);
        intCheckRem("irem_by_constant_14", irem_by_constant_14(x), x, 15);
        intCheckRem("irem_by_constant_15", irem_by_constant_15(x), x, 16);
        intCheckRem("irem_by_constant_16", irem_by_constant_16(x), x, 17);
        intCheckRem("irem_by_constant_17", irem_by_constant_17(x), x, 18);
        intCheckRem("irem_by_constant_18", irem_by_constant_18(x), x, 19);
        intCheckRem("irem_by_constant_19", irem_by_constant_19(x), x, 20);
        intCheckRem("irem_by_constant_20", irem_by_constant_20(x), x, 21);
        intCheckRem("irem_by_constant_21", irem_by_constant_21(x), x, 22);
        intCheckRem("irem_by_constant_22", irem_by_constant_22(x), x, 23);
        intCheckRem("irem_by_constant_23", irem_by_constant_23(x), x, 24);
        intCheckRem("irem_by_constant_24", irem_by_constant_24(x), x, 25);
        intCheckRem("irem_by_constant_25", irem_by_constant_25(x), x, 26);
        intCheckRem("irem_by_constant_26", irem_by_constant_26(x), x, 27);
        intCheckRem("irem_by_constant_27", irem_by_constant_27(x), x, 28);
        intCheckRem("irem_by_constant_28", irem_by_constant_28(x), x, 29);
        intCheckRem("irem_by_constant_29", irem_by_constant_29(x), x, 30);
        intCheckRem("irem_by_constant_30", irem_by_constant_30(x), x, 31);
        intCheckRem("irem_by_constant_31", irem_by_constant_31(x), x, 32);
        intCheckRem("irem_by_constant_32", irem_by_constant_32(x), x, 33);
        intCheckRem("irem_by_constant_33", irem_by_constant_33(x), x, 34);
        intCheckRem("irem_by_constant_34", irem_by_constant_34(x), x, 35);
        intCheckRem("irem_by_constant_35", irem_by_constant_35(x), x, 36);
        intCheckRem("irem_by_constant_36", irem_by_constant_36(x), x, 37);
        intCheckRem("irem_by_constant_37", irem_by_constant_37(x), x, 38);
        intCheckRem("irem_by_constant_38", irem_by_constant_38(x), x, 39);
        intCheckRem("irem_by_constant_39", irem_by_constant_39(x), x, 40);
        intCheckRem("irem_by_constant_40", irem_by_constant_40(x), x, 41);
        intCheckRem("irem_by_constant_41", irem_by_constant_41(x), x, 42);
        intCheckRem("irem_by_constant_42", irem_by_constant_42(x), x, 43);
        intCheckRem("irem_by_constant_43", irem_by_constant_43(x), x, 44);
        intCheckRem("irem_by_constant_44", irem_by_constant_44(x), x, 45);
        intCheckRem("irem_by_constant_45", irem_by_constant_45(x), x, 46);
        intCheckRem("irem_by_constant_46", irem_by_constant_46(x), x, 47);
        intCheckRem("irem_by_constant_47", irem_by_constant_47(x), x, 48);
        intCheckRem("irem_by_constant_48", irem_by_constant_48(x), x, 49);
        intCheckRem("irem_by_constant_49", irem_by_constant_49(x), x, 50);
        intCheckRem("irem_by_constant_50", irem_by_constant_50(x), x, 51);
        intCheckRem("irem_by_constant_51", irem_by_constant_51(x), x, 52);
        intCheckRem("irem_by_constant_52", irem_by_constant_52(x), x, 53);
        intCheckRem("irem_by_constant_53", irem_by_constant_53(x), x, 54);
        intCheckRem("irem_by_constant_54", irem_by_constant_54(x), x, 55);
        intCheckRem("irem_by_constant_55", irem_by_constant_55(x), x, 56);
        intCheckRem("irem_by_constant_56", irem_by_constant_56(x), x, 57);
        intCheckRem("irem_by_constant_57", irem_by_constant_57(x), x, 58);
        intCheckRem("irem_by_constant_58", irem_by_constant_58(x), x, 59);
        intCheckRem("irem_by_constant_59", irem_by_constant_59(x), x, 60);
        intCheckRem("irem_by_constant_60", irem_by_constant_60(x), x, 61);
        intCheckRem("irem_by_constant_61", irem_by_constant_61(x), x, 62);
        intCheckRem("irem_by_constant_62", irem_by_constant_62(x), x, 63);
        intCheckRem("irem_by_constant_63", irem_by_constant_63(x), x, 64);
        intCheckRem("irem_by_constant_64", irem_by_constant_64(x), x, 65);
        intCheckRem("irem_by_constant_65", irem_by_constant_65(x), x, 66);
        intCheckRem("irem_by_constant_66", irem_by_constant_66(x), x, 67);
        intCheckRem("irem_by_constant_67", irem_by_constant_67(x), x, 68);
        intCheckRem("irem_by_constant_68", irem_by_constant_68(x), x, 69);
        intCheckRem("irem_by_constant_69", irem_by_constant_69(x), x, 70);
        intCheckRem("irem_by_constant_70", irem_by_constant_70(x), x, 71);
        intCheckRem("irem_by_constant_71", irem_by_constant_71(x), x, 72);
        intCheckRem("irem_by_constant_72", irem_by_constant_72(x), x, 73);
        intCheckRem("irem_by_constant_73", irem_by_constant_73(x), x, 74);
        intCheckRem("irem_by_constant_74", irem_by_constant_74(x), x, 75);
        intCheckRem("irem_by_constant_75", irem_by_constant_75(x), x, 76);
        intCheckRem("irem_by_constant_76", irem_by_constant_76(x), x, 77);
        intCheckRem("irem_by_constant_77", irem_by_constant_77(x), x, 78);
        intCheckRem("irem_by_constant_78", irem_by_constant_78(x), x, 79);
        intCheckRem("irem_by_constant_79", irem_by_constant_79(x), x, 80);
        intCheckRem("irem_by_constant_80", irem_by_constant_80(x), x, 81);
        intCheckRem("irem_by_constant_81", irem_by_constant_81(x), x, 82);
        intCheckRem("irem_by_constant_82", irem_by_constant_82(x), x, 83);
        intCheckRem("irem_by_constant_83", irem_by_constant_83(x), x, 84);
        intCheckRem("irem_by_constant_84", irem_by_constant_84(x), x, 85);
        intCheckRem("irem_by_constant_85", irem_by_constant_85(x), x, 86);
        intCheckRem("irem_by_constant_86", irem_by_constant_86(x), x, 87);
        intCheckRem("irem_by_constant_87", irem_by_constant_87(x), x, 88);
        intCheckRem("irem_by_constant_88", irem_by_constant_88(x), x, 89);
        intCheckRem("irem_by_constant_89", irem_by_constant_89(x), x, 90);
        intCheckRem("irem_by_constant_90", irem_by_constant_90(x), x, 91);
        intCheckRem("irem_by_constant_91", irem_by_constant_91(x), x, 92);
        intCheckRem("irem_by_constant_92", irem_by_constant_92(x), x, 93);
        intCheckRem("irem_by_constant_93", irem_by_constant_93(x), x, 94);
        intCheckRem("irem_by_constant_94", irem_by_constant_94(x), x, 95);
        intCheckRem("irem_by_constant_95", irem_by_constant_95(x), x, 96);
        intCheckRem("irem_by_constant_96", irem_by_constant_96(x), x, 97);
        intCheckRem("irem_by_constant_97", irem_by_constant_97(x), x, 98);
        intCheckRem("irem_by_constant_98", irem_by_constant_98(x), x, 99);
        intCheckRem("irem_by_constant_neg_0", irem_by_constant_neg_0(x), x, -1);
        intCheckRem("irem_by_constant_neg_1", irem_by_constant_neg_1(x), x, -2);
        intCheckRem("irem_by_constant_neg_2", irem_by_constant_neg_2(x), x, -3);
        intCheckRem("irem_by_constant_neg_3", irem_by_constant_neg_3(x), x, -4);
        intCheckRem("irem_by_constant_neg_4", irem_by_constant_neg_4(x), x, -5);
        intCheckRem("irem_by_constant_neg_5", irem_by_constant_neg_5(x), x, -6);
        intCheckRem("irem_by_constant_neg_6", irem_by_constant_neg_6(x), x, -7);
        intCheckRem("irem_by_constant_neg_7", irem_by_constant_neg_7(x), x, -8);
        intCheckRem("irem_by_constant_neg_8", irem_by_constant_neg_8(x), x, -9);
        intCheckRem("irem_by_constant_neg_9", irem_by_constant_neg_9(x), x, -10);
        intCheckRem("irem_by_constant_neg_10", irem_by_constant_neg_10(x), x, -11);
        intCheckRem("irem_by_constant_neg_11", irem_by_constant_neg_11(x), x, -12);
        intCheckRem("irem_by_constant_neg_12", irem_by_constant_neg_12(x), x, -13);
        intCheckRem("irem_by_constant_neg_13", irem_by_constant_neg_13(x), x, -14);
        intCheckRem("irem_by_constant_neg_14", irem_by_constant_neg_14(x), x, -15);
        intCheckRem("irem_by_constant_neg_15", irem_by_constant_neg_15(x), x, -16);
        intCheckRem("irem_by_constant_neg_16", irem_by_constant_neg_16(x), x, -17);
        intCheckRem("irem_by_constant_neg_17", irem_by_constant_neg_17(x), x, -18);
        intCheckRem("irem_by_constant_neg_18", irem_by_constant_neg_18(x), x, -19);
        intCheckRem("irem_by_constant_neg_19", irem_by_constant_neg_19(x), x, -20);
        intCheckRem("irem_by_constant_neg_20", irem_by_constant_neg_20(x), x, -21);
        intCheckRem("irem_by_constant_neg_21", irem_by_constant_neg_21(x), x, -22);
        intCheckRem("irem_by_constant_neg_22", irem_by_constant_neg_22(x), x, -23);
        intCheckRem("irem_by_constant_neg_23", irem_by_constant_neg_23(x), x, -24);
        intCheckRem("irem_by_constant_neg_24", irem_by_constant_neg_24(x), x, -25);
        intCheckRem("irem_by_constant_neg_25", irem_by_constant_neg_25(x), x, -26);
        intCheckRem("irem_by_constant_neg_26", irem_by_constant_neg_26(x), x, -27);
        intCheckRem("irem_by_constant_neg_27", irem_by_constant_neg_27(x), x, -28);
        intCheckRem("irem_by_constant_neg_28", irem_by_constant_neg_28(x), x, -29);
        intCheckRem("irem_by_constant_neg_29", irem_by_constant_neg_29(x), x, -30);
        intCheckRem("irem_by_constant_neg_30", irem_by_constant_neg_30(x), x, -31);
        intCheckRem("irem_by_constant_neg_31", irem_by_constant_neg_31(x), x, -32);
        intCheckRem("irem_by_constant_neg_32", irem_by_constant_neg_32(x), x, -33);
        intCheckRem("irem_by_constant_neg_33", irem_by_constant_neg_33(x), x, -34);
        intCheckRem("irem_by_constant_neg_34", irem_by_constant_neg_34(x), x, -35);
        intCheckRem("irem_by_constant_neg_35", irem_by_constant_neg_35(x), x, -36);
        intCheckRem("irem_by_constant_neg_36", irem_by_constant_neg_36(x), x, -37);
        intCheckRem("irem_by_constant_neg_37", irem_by_constant_neg_37(x), x, -38);
        intCheckRem("irem_by_constant_neg_38", irem_by_constant_neg_38(x), x, -39);
        intCheckRem("irem_by_constant_neg_39", irem_by_constant_neg_39(x), x, -40);
        intCheckRem("irem_by_constant_neg_40", irem_by_constant_neg_40(x), x, -41);
        intCheckRem("irem_by_constant_neg_41", irem_by_constant_neg_41(x), x, -42);
        intCheckRem("irem_by_constant_neg_42", irem_by_constant_neg_42(x), x, -43);
        intCheckRem("irem_by_constant_neg_43", irem_by_constant_neg_43(x), x, -44);
        intCheckRem("irem_by_constant_neg_44", irem_by_constant_neg_44(x), x, -45);
        intCheckRem("irem_by_constant_neg_45", irem_by_constant_neg_45(x), x, -46);
        intCheckRem("irem_by_constant_neg_46", irem_by_constant_neg_46(x), x, -47);
        intCheckRem("irem_by_constant_neg_47", irem_by_constant_neg_47(x), x, -48);
        intCheckRem("irem_by_constant_neg_48", irem_by_constant_neg_48(x), x, -49);
        intCheckRem("irem_by_constant_neg_49", irem_by_constant_neg_49(x), x, -50);
        intCheckRem("irem_by_constant_neg_50", irem_by_constant_neg_50(x), x, -51);
        intCheckRem("irem_by_constant_neg_51", irem_by_constant_neg_51(x), x, -52);
        intCheckRem("irem_by_constant_neg_52", irem_by_constant_neg_52(x), x, -53);
        intCheckRem("irem_by_constant_neg_53", irem_by_constant_neg_53(x), x, -54);
        intCheckRem("irem_by_constant_neg_54", irem_by_constant_neg_54(x), x, -55);
        intCheckRem("irem_by_constant_neg_55", irem_by_constant_neg_55(x), x, -56);
        intCheckRem("irem_by_constant_neg_56", irem_by_constant_neg_56(x), x, -57);
        intCheckRem("irem_by_constant_neg_57", irem_by_constant_neg_57(x), x, -58);
        intCheckRem("irem_by_constant_neg_58", irem_by_constant_neg_58(x), x, -59);
        intCheckRem("irem_by_constant_neg_59", irem_by_constant_neg_59(x), x, -60);
        intCheckRem("irem_by_constant_neg_60", irem_by_constant_neg_60(x), x, -61);
        intCheckRem("irem_by_constant_neg_61", irem_by_constant_neg_61(x), x, -62);
        intCheckRem("irem_by_constant_neg_62", irem_by_constant_neg_62(x), x, -63);
        intCheckRem("irem_by_constant_neg_63", irem_by_constant_neg_63(x), x, -64);
        intCheckRem("irem_by_constant_neg_64", irem_by_constant_neg_64(x), x, -65);
        intCheckRem("irem_by_constant_neg_65", irem_by_constant_neg_65(x), x, -66);
        intCheckRem("irem_by_constant_neg_66", irem_by_constant_neg_66(x), x, -67);
        intCheckRem("irem_by_constant_neg_67", irem_by_constant_neg_67(x), x, -68);
        intCheckRem("irem_by_constant_neg_68", irem_by_constant_neg_68(x), x, -69);
        intCheckRem("irem_by_constant_neg_69", irem_by_constant_neg_69(x), x, -70);
        intCheckRem("irem_by_constant_neg_70", irem_by_constant_neg_70(x), x, -71);
        intCheckRem("irem_by_constant_neg_71", irem_by_constant_neg_71(x), x, -72);
        intCheckRem("irem_by_constant_neg_72", irem_by_constant_neg_72(x), x, -73);
        intCheckRem("irem_by_constant_neg_73", irem_by_constant_neg_73(x), x, -74);
        intCheckRem("irem_by_constant_neg_74", irem_by_constant_neg_74(x), x, -75);
        intCheckRem("irem_by_constant_neg_75", irem_by_constant_neg_75(x), x, -76);
        intCheckRem("irem_by_constant_neg_76", irem_by_constant_neg_76(x), x, -77);
        intCheckRem("irem_by_constant_neg_77", irem_by_constant_neg_77(x), x, -78);
        intCheckRem("irem_by_constant_neg_78", irem_by_constant_neg_78(x), x, -79);
        intCheckRem("irem_by_constant_neg_79", irem_by_constant_neg_79(x), x, -80);
        intCheckRem("irem_by_constant_neg_80", irem_by_constant_neg_80(x), x, -81);
        intCheckRem("irem_by_constant_neg_81", irem_by_constant_neg_81(x), x, -82);
        intCheckRem("irem_by_constant_neg_82", irem_by_constant_neg_82(x), x, -83);
        intCheckRem("irem_by_constant_neg_83", irem_by_constant_neg_83(x), x, -84);
        intCheckRem("irem_by_constant_neg_84", irem_by_constant_neg_84(x), x, -85);
        intCheckRem("irem_by_constant_neg_85", irem_by_constant_neg_85(x), x, -86);
        intCheckRem("irem_by_constant_neg_86", irem_by_constant_neg_86(x), x, -87);
        intCheckRem("irem_by_constant_neg_87", irem_by_constant_neg_87(x), x, -88);
        intCheckRem("irem_by_constant_neg_88", irem_by_constant_neg_88(x), x, -89);
        intCheckRem("irem_by_constant_neg_89", irem_by_constant_neg_89(x), x, -90);
        intCheckRem("irem_by_constant_neg_90", irem_by_constant_neg_90(x), x, -91);
        intCheckRem("irem_by_constant_neg_91", irem_by_constant_neg_91(x), x, -92);
        intCheckRem("irem_by_constant_neg_92", irem_by_constant_neg_92(x), x, -93);
        intCheckRem("irem_by_constant_neg_93", irem_by_constant_neg_93(x), x, -94);
        intCheckRem("irem_by_constant_neg_94", irem_by_constant_neg_94(x), x, -95);
        intCheckRem("irem_by_constant_neg_95", irem_by_constant_neg_95(x), x, -96);
        intCheckRem("irem_by_constant_neg_96", irem_by_constant_neg_96(x), x, -97);
        intCheckRem("irem_by_constant_neg_97", irem_by_constant_neg_97(x), x, -98);
        intCheckRem("irem_by_constant_neg_98", irem_by_constant_neg_98(x), x, -99);
    }

    public static void longCheckAll(long x) {
        longCheckDiv("ldiv_by_pow2_0", ldiv_by_pow2_0(x), x, 1l);
        longCheckDiv("ldiv_by_pow2_1", ldiv_by_pow2_1(x), x, 2l);
        longCheckDiv("ldiv_by_pow2_2", ldiv_by_pow2_2(x), x, 4l);
        longCheckDiv("ldiv_by_pow2_3", ldiv_by_pow2_3(x), x, 8l);
        longCheckDiv("ldiv_by_pow2_4", ldiv_by_pow2_4(x), x, 16l);
        longCheckDiv("ldiv_by_pow2_5", ldiv_by_pow2_5(x), x, 32l);
        longCheckDiv("ldiv_by_pow2_6", ldiv_by_pow2_6(x), x, 64l);
        longCheckDiv("ldiv_by_pow2_7", ldiv_by_pow2_7(x), x, 128l);
        longCheckDiv("ldiv_by_pow2_8", ldiv_by_pow2_8(x), x, 256l);
        longCheckDiv("ldiv_by_pow2_9", ldiv_by_pow2_9(x), x, 512l);
        longCheckDiv("ldiv_by_pow2_10", ldiv_by_pow2_10(x), x, 1024l);
        longCheckDiv("ldiv_by_pow2_11", ldiv_by_pow2_11(x), x, 2048l);
        longCheckDiv("ldiv_by_pow2_12", ldiv_by_pow2_12(x), x, 4096l);
        longCheckDiv("ldiv_by_pow2_13", ldiv_by_pow2_13(x), x, 8192l);
        longCheckDiv("ldiv_by_pow2_14", ldiv_by_pow2_14(x), x, 16384l);
        longCheckDiv("ldiv_by_pow2_15", ldiv_by_pow2_15(x), x, 32768l);
        longCheckDiv("ldiv_by_pow2_16", ldiv_by_pow2_16(x), x, 65536l);
        longCheckDiv("ldiv_by_pow2_17", ldiv_by_pow2_17(x), x, 131072l);
        longCheckDiv("ldiv_by_pow2_18", ldiv_by_pow2_18(x), x, 262144l);
        longCheckDiv("ldiv_by_pow2_19", ldiv_by_pow2_19(x), x, 524288l);
        longCheckDiv("ldiv_by_pow2_20", ldiv_by_pow2_20(x), x, 1048576l);
        longCheckDiv("ldiv_by_pow2_21", ldiv_by_pow2_21(x), x, 2097152l);
        longCheckDiv("ldiv_by_pow2_22", ldiv_by_pow2_22(x), x, 4194304l);
        longCheckDiv("ldiv_by_pow2_23", ldiv_by_pow2_23(x), x, 8388608l);
        longCheckDiv("ldiv_by_pow2_24", ldiv_by_pow2_24(x), x, 16777216l);
        longCheckDiv("ldiv_by_pow2_25", ldiv_by_pow2_25(x), x, 33554432l);
        longCheckDiv("ldiv_by_pow2_26", ldiv_by_pow2_26(x), x, 67108864l);
        longCheckDiv("ldiv_by_pow2_27", ldiv_by_pow2_27(x), x, 134217728l);
        longCheckDiv("ldiv_by_pow2_28", ldiv_by_pow2_28(x), x, 268435456l);
        longCheckDiv("ldiv_by_pow2_29", ldiv_by_pow2_29(x), x, 536870912l);
        longCheckDiv("ldiv_by_pow2_30", ldiv_by_pow2_30(x), x, 1073741824l);
        longCheckDiv("ldiv_by_pow2_31", ldiv_by_pow2_31(x), x, 2147483648l);
        longCheckDiv("ldiv_by_pow2_32", ldiv_by_pow2_32(x), x, 4294967296l);
        longCheckDiv("ldiv_by_pow2_33", ldiv_by_pow2_33(x), x, 8589934592l);
        longCheckDiv("ldiv_by_pow2_34", ldiv_by_pow2_34(x), x, 17179869184l);
        longCheckDiv("ldiv_by_pow2_35", ldiv_by_pow2_35(x), x, 34359738368l);
        longCheckDiv("ldiv_by_pow2_36", ldiv_by_pow2_36(x), x, 68719476736l);
        longCheckDiv("ldiv_by_pow2_37", ldiv_by_pow2_37(x), x, 137438953472l);
        longCheckDiv("ldiv_by_pow2_38", ldiv_by_pow2_38(x), x, 274877906944l);
        longCheckDiv("ldiv_by_pow2_39", ldiv_by_pow2_39(x), x, 549755813888l);
        longCheckDiv("ldiv_by_pow2_40", ldiv_by_pow2_40(x), x, 1099511627776l);
        longCheckDiv("ldiv_by_pow2_41", ldiv_by_pow2_41(x), x, 2199023255552l);
        longCheckDiv("ldiv_by_pow2_42", ldiv_by_pow2_42(x), x, 4398046511104l);
        longCheckDiv("ldiv_by_pow2_43", ldiv_by_pow2_43(x), x, 8796093022208l);
        longCheckDiv("ldiv_by_pow2_44", ldiv_by_pow2_44(x), x, 17592186044416l);
        longCheckDiv("ldiv_by_pow2_45", ldiv_by_pow2_45(x), x, 35184372088832l);
        longCheckDiv("ldiv_by_pow2_46", ldiv_by_pow2_46(x), x, 70368744177664l);
        longCheckDiv("ldiv_by_pow2_47", ldiv_by_pow2_47(x), x, 140737488355328l);
        longCheckDiv("ldiv_by_pow2_48", ldiv_by_pow2_48(x), x, 281474976710656l);
        longCheckDiv("ldiv_by_pow2_49", ldiv_by_pow2_49(x), x, 562949953421312l);
        longCheckDiv("ldiv_by_pow2_50", ldiv_by_pow2_50(x), x, 1125899906842624l);
        longCheckDiv("ldiv_by_pow2_51", ldiv_by_pow2_51(x), x, 2251799813685248l);
        longCheckDiv("ldiv_by_pow2_52", ldiv_by_pow2_52(x), x, 4503599627370496l);
        longCheckDiv("ldiv_by_pow2_53", ldiv_by_pow2_53(x), x, 9007199254740992l);
        longCheckDiv("ldiv_by_pow2_54", ldiv_by_pow2_54(x), x, 18014398509481984l);
        longCheckDiv("ldiv_by_pow2_55", ldiv_by_pow2_55(x), x, 36028797018963968l);
        longCheckDiv("ldiv_by_pow2_56", ldiv_by_pow2_56(x), x, 72057594037927936l);
        longCheckDiv("ldiv_by_pow2_57", ldiv_by_pow2_57(x), x, 144115188075855872l);
        longCheckDiv("ldiv_by_pow2_58", ldiv_by_pow2_58(x), x, 288230376151711744l);
        longCheckDiv("ldiv_by_pow2_59", ldiv_by_pow2_59(x), x, 576460752303423488l);
        longCheckDiv("ldiv_by_pow2_60", ldiv_by_pow2_60(x), x, 1152921504606846976l);
        longCheckDiv("ldiv_by_pow2_61", ldiv_by_pow2_61(x), x, 2305843009213693952l);
        longCheckDiv("ldiv_by_pow2_62", ldiv_by_pow2_62(x), x, 4611686018427387904l);
        longCheckDiv("ldiv_by_pow2_neg_0", ldiv_by_pow2_neg_0(x), x, -1l);
        longCheckDiv("ldiv_by_pow2_neg_1", ldiv_by_pow2_neg_1(x), x, -2l);
        longCheckDiv("ldiv_by_pow2_neg_2", ldiv_by_pow2_neg_2(x), x, -4l);
        longCheckDiv("ldiv_by_pow2_neg_3", ldiv_by_pow2_neg_3(x), x, -8l);
        longCheckDiv("ldiv_by_pow2_neg_4", ldiv_by_pow2_neg_4(x), x, -16l);
        longCheckDiv("ldiv_by_pow2_neg_5", ldiv_by_pow2_neg_5(x), x, -32l);
        longCheckDiv("ldiv_by_pow2_neg_6", ldiv_by_pow2_neg_6(x), x, -64l);
        longCheckDiv("ldiv_by_pow2_neg_7", ldiv_by_pow2_neg_7(x), x, -128l);
        longCheckDiv("ldiv_by_pow2_neg_8", ldiv_by_pow2_neg_8(x), x, -256l);
        longCheckDiv("ldiv_by_pow2_neg_9", ldiv_by_pow2_neg_9(x), x, -512l);
        longCheckDiv("ldiv_by_pow2_neg_10", ldiv_by_pow2_neg_10(x), x, -1024l);
        longCheckDiv("ldiv_by_pow2_neg_11", ldiv_by_pow2_neg_11(x), x, -2048l);
        longCheckDiv("ldiv_by_pow2_neg_12", ldiv_by_pow2_neg_12(x), x, -4096l);
        longCheckDiv("ldiv_by_pow2_neg_13", ldiv_by_pow2_neg_13(x), x, -8192l);
        longCheckDiv("ldiv_by_pow2_neg_14", ldiv_by_pow2_neg_14(x), x, -16384l);
        longCheckDiv("ldiv_by_pow2_neg_15", ldiv_by_pow2_neg_15(x), x, -32768l);
        longCheckDiv("ldiv_by_pow2_neg_16", ldiv_by_pow2_neg_16(x), x, -65536l);
        longCheckDiv("ldiv_by_pow2_neg_17", ldiv_by_pow2_neg_17(x), x, -131072l);
        longCheckDiv("ldiv_by_pow2_neg_18", ldiv_by_pow2_neg_18(x), x, -262144l);
        longCheckDiv("ldiv_by_pow2_neg_19", ldiv_by_pow2_neg_19(x), x, -524288l);
        longCheckDiv("ldiv_by_pow2_neg_20", ldiv_by_pow2_neg_20(x), x, -1048576l);
        longCheckDiv("ldiv_by_pow2_neg_21", ldiv_by_pow2_neg_21(x), x, -2097152l);
        longCheckDiv("ldiv_by_pow2_neg_22", ldiv_by_pow2_neg_22(x), x, -4194304l);
        longCheckDiv("ldiv_by_pow2_neg_23", ldiv_by_pow2_neg_23(x), x, -8388608l);
        longCheckDiv("ldiv_by_pow2_neg_24", ldiv_by_pow2_neg_24(x), x, -16777216l);
        longCheckDiv("ldiv_by_pow2_neg_25", ldiv_by_pow2_neg_25(x), x, -33554432l);
        longCheckDiv("ldiv_by_pow2_neg_26", ldiv_by_pow2_neg_26(x), x, -67108864l);
        longCheckDiv("ldiv_by_pow2_neg_27", ldiv_by_pow2_neg_27(x), x, -134217728l);
        longCheckDiv("ldiv_by_pow2_neg_28", ldiv_by_pow2_neg_28(x), x, -268435456l);
        longCheckDiv("ldiv_by_pow2_neg_29", ldiv_by_pow2_neg_29(x), x, -536870912l);
        longCheckDiv("ldiv_by_pow2_neg_30", ldiv_by_pow2_neg_30(x), x, -1073741824l);
        longCheckDiv("ldiv_by_pow2_neg_31", ldiv_by_pow2_neg_31(x), x, -2147483648l);
        longCheckDiv("ldiv_by_pow2_neg_32", ldiv_by_pow2_neg_32(x), x, -4294967296l);
        longCheckDiv("ldiv_by_pow2_neg_33", ldiv_by_pow2_neg_33(x), x, -8589934592l);
        longCheckDiv("ldiv_by_pow2_neg_34", ldiv_by_pow2_neg_34(x), x, -17179869184l);
        longCheckDiv("ldiv_by_pow2_neg_35", ldiv_by_pow2_neg_35(x), x, -34359738368l);
        longCheckDiv("ldiv_by_pow2_neg_36", ldiv_by_pow2_neg_36(x), x, -68719476736l);
        longCheckDiv("ldiv_by_pow2_neg_37", ldiv_by_pow2_neg_37(x), x, -137438953472l);
        longCheckDiv("ldiv_by_pow2_neg_38", ldiv_by_pow2_neg_38(x), x, -274877906944l);
        longCheckDiv("ldiv_by_pow2_neg_39", ldiv_by_pow2_neg_39(x), x, -549755813888l);
        longCheckDiv("ldiv_by_pow2_neg_40", ldiv_by_pow2_neg_40(x), x, -1099511627776l);
        longCheckDiv("ldiv_by_pow2_neg_41", ldiv_by_pow2_neg_41(x), x, -2199023255552l);
        longCheckDiv("ldiv_by_pow2_neg_42", ldiv_by_pow2_neg_42(x), x, -4398046511104l);
        longCheckDiv("ldiv_by_pow2_neg_43", ldiv_by_pow2_neg_43(x), x, -8796093022208l);
        longCheckDiv("ldiv_by_pow2_neg_44", ldiv_by_pow2_neg_44(x), x, -17592186044416l);
        longCheckDiv("ldiv_by_pow2_neg_45", ldiv_by_pow2_neg_45(x), x, -35184372088832l);
        longCheckDiv("ldiv_by_pow2_neg_46", ldiv_by_pow2_neg_46(x), x, -70368744177664l);
        longCheckDiv("ldiv_by_pow2_neg_47", ldiv_by_pow2_neg_47(x), x, -140737488355328l);
        longCheckDiv("ldiv_by_pow2_neg_48", ldiv_by_pow2_neg_48(x), x, -281474976710656l);
        longCheckDiv("ldiv_by_pow2_neg_49", ldiv_by_pow2_neg_49(x), x, -562949953421312l);
        longCheckDiv("ldiv_by_pow2_neg_50", ldiv_by_pow2_neg_50(x), x, -1125899906842624l);
        longCheckDiv("ldiv_by_pow2_neg_51", ldiv_by_pow2_neg_51(x), x, -2251799813685248l);
        longCheckDiv("ldiv_by_pow2_neg_52", ldiv_by_pow2_neg_52(x), x, -4503599627370496l);
        longCheckDiv("ldiv_by_pow2_neg_53", ldiv_by_pow2_neg_53(x), x, -9007199254740992l);
        longCheckDiv("ldiv_by_pow2_neg_54", ldiv_by_pow2_neg_54(x), x, -18014398509481984l);
        longCheckDiv("ldiv_by_pow2_neg_55", ldiv_by_pow2_neg_55(x), x, -36028797018963968l);
        longCheckDiv("ldiv_by_pow2_neg_56", ldiv_by_pow2_neg_56(x), x, -72057594037927936l);
        longCheckDiv("ldiv_by_pow2_neg_57", ldiv_by_pow2_neg_57(x), x, -144115188075855872l);
        longCheckDiv("ldiv_by_pow2_neg_58", ldiv_by_pow2_neg_58(x), x, -288230376151711744l);
        longCheckDiv("ldiv_by_pow2_neg_59", ldiv_by_pow2_neg_59(x), x, -576460752303423488l);
        longCheckDiv("ldiv_by_pow2_neg_60", ldiv_by_pow2_neg_60(x), x, -1152921504606846976l);
        longCheckDiv("ldiv_by_pow2_neg_61", ldiv_by_pow2_neg_61(x), x, -2305843009213693952l);
        longCheckDiv("ldiv_by_pow2_neg_62", ldiv_by_pow2_neg_62(x), x, -4611686018427387904l);
        longCheckDiv("ldiv_by_pow2_neg_63", ldiv_by_pow2_neg_63(x), x, -9223372036854775808l);
        longCheckDiv("ldiv_by_constant_0", ldiv_by_constant_0(x), x, 1l);
        longCheckDiv("ldiv_by_constant_1", ldiv_by_constant_1(x), x, 2l);
        longCheckDiv("ldiv_by_constant_2", ldiv_by_constant_2(x), x, 3l);
        longCheckDiv("ldiv_by_constant_3", ldiv_by_constant_3(x), x, 4l);
        longCheckDiv("ldiv_by_constant_4", ldiv_by_constant_4(x), x, 5l);
        longCheckDiv("ldiv_by_constant_5", ldiv_by_constant_5(x), x, 6l);
        longCheckDiv("ldiv_by_constant_6", ldiv_by_constant_6(x), x, 7l);
        longCheckDiv("ldiv_by_constant_7", ldiv_by_constant_7(x), x, 8l);
        longCheckDiv("ldiv_by_constant_8", ldiv_by_constant_8(x), x, 9l);
        longCheckDiv("ldiv_by_constant_9", ldiv_by_constant_9(x), x, 10l);
        longCheckDiv("ldiv_by_constant_10", ldiv_by_constant_10(x), x, 11l);
        longCheckDiv("ldiv_by_constant_11", ldiv_by_constant_11(x), x, 12l);
        longCheckDiv("ldiv_by_constant_12", ldiv_by_constant_12(x), x, 13l);
        longCheckDiv("ldiv_by_constant_13", ldiv_by_constant_13(x), x, 14l);
        longCheckDiv("ldiv_by_constant_14", ldiv_by_constant_14(x), x, 15l);
        longCheckDiv("ldiv_by_constant_15", ldiv_by_constant_15(x), x, 16l);
        longCheckDiv("ldiv_by_constant_16", ldiv_by_constant_16(x), x, 17l);
        longCheckDiv("ldiv_by_constant_17", ldiv_by_constant_17(x), x, 18l);
        longCheckDiv("ldiv_by_constant_18", ldiv_by_constant_18(x), x, 19l);
        longCheckDiv("ldiv_by_constant_19", ldiv_by_constant_19(x), x, 20l);
        longCheckDiv("ldiv_by_constant_20", ldiv_by_constant_20(x), x, 21l);
        longCheckDiv("ldiv_by_constant_21", ldiv_by_constant_21(x), x, 22l);
        longCheckDiv("ldiv_by_constant_22", ldiv_by_constant_22(x), x, 23l);
        longCheckDiv("ldiv_by_constant_23", ldiv_by_constant_23(x), x, 24l);
        longCheckDiv("ldiv_by_constant_24", ldiv_by_constant_24(x), x, 25l);
        longCheckDiv("ldiv_by_constant_25", ldiv_by_constant_25(x), x, 26l);
        longCheckDiv("ldiv_by_constant_26", ldiv_by_constant_26(x), x, 27l);
        longCheckDiv("ldiv_by_constant_27", ldiv_by_constant_27(x), x, 28l);
        longCheckDiv("ldiv_by_constant_28", ldiv_by_constant_28(x), x, 29l);
        longCheckDiv("ldiv_by_constant_29", ldiv_by_constant_29(x), x, 30l);
        longCheckDiv("ldiv_by_constant_30", ldiv_by_constant_30(x), x, 31l);
        longCheckDiv("ldiv_by_constant_31", ldiv_by_constant_31(x), x, 32l);
        longCheckDiv("ldiv_by_constant_32", ldiv_by_constant_32(x), x, 33l);
        longCheckDiv("ldiv_by_constant_33", ldiv_by_constant_33(x), x, 34l);
        longCheckDiv("ldiv_by_constant_34", ldiv_by_constant_34(x), x, 35l);
        longCheckDiv("ldiv_by_constant_35", ldiv_by_constant_35(x), x, 36l);
        longCheckDiv("ldiv_by_constant_36", ldiv_by_constant_36(x), x, 37l);
        longCheckDiv("ldiv_by_constant_37", ldiv_by_constant_37(x), x, 38l);
        longCheckDiv("ldiv_by_constant_38", ldiv_by_constant_38(x), x, 39l);
        longCheckDiv("ldiv_by_constant_39", ldiv_by_constant_39(x), x, 40l);
        longCheckDiv("ldiv_by_constant_40", ldiv_by_constant_40(x), x, 41l);
        longCheckDiv("ldiv_by_constant_41", ldiv_by_constant_41(x), x, 42l);
        longCheckDiv("ldiv_by_constant_42", ldiv_by_constant_42(x), x, 43l);
        longCheckDiv("ldiv_by_constant_43", ldiv_by_constant_43(x), x, 44l);
        longCheckDiv("ldiv_by_constant_44", ldiv_by_constant_44(x), x, 45l);
        longCheckDiv("ldiv_by_constant_45", ldiv_by_constant_45(x), x, 46l);
        longCheckDiv("ldiv_by_constant_46", ldiv_by_constant_46(x), x, 47l);
        longCheckDiv("ldiv_by_constant_47", ldiv_by_constant_47(x), x, 48l);
        longCheckDiv("ldiv_by_constant_48", ldiv_by_constant_48(x), x, 49l);
        longCheckDiv("ldiv_by_constant_49", ldiv_by_constant_49(x), x, 50l);
        longCheckDiv("ldiv_by_constant_50", ldiv_by_constant_50(x), x, 51l);
        longCheckDiv("ldiv_by_constant_51", ldiv_by_constant_51(x), x, 52l);
        longCheckDiv("ldiv_by_constant_52", ldiv_by_constant_52(x), x, 53l);
        longCheckDiv("ldiv_by_constant_53", ldiv_by_constant_53(x), x, 54l);
        longCheckDiv("ldiv_by_constant_54", ldiv_by_constant_54(x), x, 55l);
        longCheckDiv("ldiv_by_constant_55", ldiv_by_constant_55(x), x, 56l);
        longCheckDiv("ldiv_by_constant_56", ldiv_by_constant_56(x), x, 57l);
        longCheckDiv("ldiv_by_constant_57", ldiv_by_constant_57(x), x, 58l);
        longCheckDiv("ldiv_by_constant_58", ldiv_by_constant_58(x), x, 59l);
        longCheckDiv("ldiv_by_constant_59", ldiv_by_constant_59(x), x, 60l);
        longCheckDiv("ldiv_by_constant_60", ldiv_by_constant_60(x), x, 61l);
        longCheckDiv("ldiv_by_constant_61", ldiv_by_constant_61(x), x, 62l);
        longCheckDiv("ldiv_by_constant_62", ldiv_by_constant_62(x), x, 63l);
        longCheckDiv("ldiv_by_constant_63", ldiv_by_constant_63(x), x, 64l);
        longCheckDiv("ldiv_by_constant_64", ldiv_by_constant_64(x), x, 65l);
        longCheckDiv("ldiv_by_constant_65", ldiv_by_constant_65(x), x, 66l);
        longCheckDiv("ldiv_by_constant_66", ldiv_by_constant_66(x), x, 67l);
        longCheckDiv("ldiv_by_constant_67", ldiv_by_constant_67(x), x, 68l);
        longCheckDiv("ldiv_by_constant_68", ldiv_by_constant_68(x), x, 69l);
        longCheckDiv("ldiv_by_constant_69", ldiv_by_constant_69(x), x, 70l);
        longCheckDiv("ldiv_by_constant_70", ldiv_by_constant_70(x), x, 71l);
        longCheckDiv("ldiv_by_constant_71", ldiv_by_constant_71(x), x, 72l);
        longCheckDiv("ldiv_by_constant_72", ldiv_by_constant_72(x), x, 73l);
        longCheckDiv("ldiv_by_constant_73", ldiv_by_constant_73(x), x, 74l);
        longCheckDiv("ldiv_by_constant_74", ldiv_by_constant_74(x), x, 75l);
        longCheckDiv("ldiv_by_constant_75", ldiv_by_constant_75(x), x, 76l);
        longCheckDiv("ldiv_by_constant_76", ldiv_by_constant_76(x), x, 77l);
        longCheckDiv("ldiv_by_constant_77", ldiv_by_constant_77(x), x, 78l);
        longCheckDiv("ldiv_by_constant_78", ldiv_by_constant_78(x), x, 79l);
        longCheckDiv("ldiv_by_constant_79", ldiv_by_constant_79(x), x, 80l);
        longCheckDiv("ldiv_by_constant_80", ldiv_by_constant_80(x), x, 81l);
        longCheckDiv("ldiv_by_constant_81", ldiv_by_constant_81(x), x, 82l);
        longCheckDiv("ldiv_by_constant_82", ldiv_by_constant_82(x), x, 83l);
        longCheckDiv("ldiv_by_constant_83", ldiv_by_constant_83(x), x, 84l);
        longCheckDiv("ldiv_by_constant_84", ldiv_by_constant_84(x), x, 85l);
        longCheckDiv("ldiv_by_constant_85", ldiv_by_constant_85(x), x, 86l);
        longCheckDiv("ldiv_by_constant_86", ldiv_by_constant_86(x), x, 87l);
        longCheckDiv("ldiv_by_constant_87", ldiv_by_constant_87(x), x, 88l);
        longCheckDiv("ldiv_by_constant_88", ldiv_by_constant_88(x), x, 89l);
        longCheckDiv("ldiv_by_constant_89", ldiv_by_constant_89(x), x, 90l);
        longCheckDiv("ldiv_by_constant_90", ldiv_by_constant_90(x), x, 91l);
        longCheckDiv("ldiv_by_constant_91", ldiv_by_constant_91(x), x, 92l);
        longCheckDiv("ldiv_by_constant_92", ldiv_by_constant_92(x), x, 93l);
        longCheckDiv("ldiv_by_constant_93", ldiv_by_constant_93(x), x, 94l);
        longCheckDiv("ldiv_by_constant_94", ldiv_by_constant_94(x), x, 95l);
        longCheckDiv("ldiv_by_constant_95", ldiv_by_constant_95(x), x, 96l);
        longCheckDiv("ldiv_by_constant_96", ldiv_by_constant_96(x), x, 97l);
        longCheckDiv("ldiv_by_constant_97", ldiv_by_constant_97(x), x, 98l);
        longCheckDiv("ldiv_by_constant_98", ldiv_by_constant_98(x), x, 99l);
        longCheckDiv("ldiv_by_constant_neg_0", ldiv_by_constant_neg_0(x), x, -1l);
        longCheckDiv("ldiv_by_constant_neg_1", ldiv_by_constant_neg_1(x), x, -2l);
        longCheckDiv("ldiv_by_constant_neg_2", ldiv_by_constant_neg_2(x), x, -3l);
        longCheckDiv("ldiv_by_constant_neg_3", ldiv_by_constant_neg_3(x), x, -4l);
        longCheckDiv("ldiv_by_constant_neg_4", ldiv_by_constant_neg_4(x), x, -5l);
        longCheckDiv("ldiv_by_constant_neg_5", ldiv_by_constant_neg_5(x), x, -6l);
        longCheckDiv("ldiv_by_constant_neg_6", ldiv_by_constant_neg_6(x), x, -7l);
        longCheckDiv("ldiv_by_constant_neg_7", ldiv_by_constant_neg_7(x), x, -8l);
        longCheckDiv("ldiv_by_constant_neg_8", ldiv_by_constant_neg_8(x), x, -9l);
        longCheckDiv("ldiv_by_constant_neg_9", ldiv_by_constant_neg_9(x), x, -10l);
        longCheckDiv("ldiv_by_constant_neg_10", ldiv_by_constant_neg_10(x), x, -11l);
        longCheckDiv("ldiv_by_constant_neg_11", ldiv_by_constant_neg_11(x), x, -12l);
        longCheckDiv("ldiv_by_constant_neg_12", ldiv_by_constant_neg_12(x), x, -13l);
        longCheckDiv("ldiv_by_constant_neg_13", ldiv_by_constant_neg_13(x), x, -14l);
        longCheckDiv("ldiv_by_constant_neg_14", ldiv_by_constant_neg_14(x), x, -15l);
        longCheckDiv("ldiv_by_constant_neg_15", ldiv_by_constant_neg_15(x), x, -16l);
        longCheckDiv("ldiv_by_constant_neg_16", ldiv_by_constant_neg_16(x), x, -17l);
        longCheckDiv("ldiv_by_constant_neg_17", ldiv_by_constant_neg_17(x), x, -18l);
        longCheckDiv("ldiv_by_constant_neg_18", ldiv_by_constant_neg_18(x), x, -19l);
        longCheckDiv("ldiv_by_constant_neg_19", ldiv_by_constant_neg_19(x), x, -20l);
        longCheckDiv("ldiv_by_constant_neg_20", ldiv_by_constant_neg_20(x), x, -21l);
        longCheckDiv("ldiv_by_constant_neg_21", ldiv_by_constant_neg_21(x), x, -22l);
        longCheckDiv("ldiv_by_constant_neg_22", ldiv_by_constant_neg_22(x), x, -23l);
        longCheckDiv("ldiv_by_constant_neg_23", ldiv_by_constant_neg_23(x), x, -24l);
        longCheckDiv("ldiv_by_constant_neg_24", ldiv_by_constant_neg_24(x), x, -25l);
        longCheckDiv("ldiv_by_constant_neg_25", ldiv_by_constant_neg_25(x), x, -26l);
        longCheckDiv("ldiv_by_constant_neg_26", ldiv_by_constant_neg_26(x), x, -27l);
        longCheckDiv("ldiv_by_constant_neg_27", ldiv_by_constant_neg_27(x), x, -28l);
        longCheckDiv("ldiv_by_constant_neg_28", ldiv_by_constant_neg_28(x), x, -29l);
        longCheckDiv("ldiv_by_constant_neg_29", ldiv_by_constant_neg_29(x), x, -30l);
        longCheckDiv("ldiv_by_constant_neg_30", ldiv_by_constant_neg_30(x), x, -31l);
        longCheckDiv("ldiv_by_constant_neg_31", ldiv_by_constant_neg_31(x), x, -32l);
        longCheckDiv("ldiv_by_constant_neg_32", ldiv_by_constant_neg_32(x), x, -33l);
        longCheckDiv("ldiv_by_constant_neg_33", ldiv_by_constant_neg_33(x), x, -34l);
        longCheckDiv("ldiv_by_constant_neg_34", ldiv_by_constant_neg_34(x), x, -35l);
        longCheckDiv("ldiv_by_constant_neg_35", ldiv_by_constant_neg_35(x), x, -36l);
        longCheckDiv("ldiv_by_constant_neg_36", ldiv_by_constant_neg_36(x), x, -37l);
        longCheckDiv("ldiv_by_constant_neg_37", ldiv_by_constant_neg_37(x), x, -38l);
        longCheckDiv("ldiv_by_constant_neg_38", ldiv_by_constant_neg_38(x), x, -39l);
        longCheckDiv("ldiv_by_constant_neg_39", ldiv_by_constant_neg_39(x), x, -40l);
        longCheckDiv("ldiv_by_constant_neg_40", ldiv_by_constant_neg_40(x), x, -41l);
        longCheckDiv("ldiv_by_constant_neg_41", ldiv_by_constant_neg_41(x), x, -42l);
        longCheckDiv("ldiv_by_constant_neg_42", ldiv_by_constant_neg_42(x), x, -43l);
        longCheckDiv("ldiv_by_constant_neg_43", ldiv_by_constant_neg_43(x), x, -44l);
        longCheckDiv("ldiv_by_constant_neg_44", ldiv_by_constant_neg_44(x), x, -45l);
        longCheckDiv("ldiv_by_constant_neg_45", ldiv_by_constant_neg_45(x), x, -46l);
        longCheckDiv("ldiv_by_constant_neg_46", ldiv_by_constant_neg_46(x), x, -47l);
        longCheckDiv("ldiv_by_constant_neg_47", ldiv_by_constant_neg_47(x), x, -48l);
        longCheckDiv("ldiv_by_constant_neg_48", ldiv_by_constant_neg_48(x), x, -49l);
        longCheckDiv("ldiv_by_constant_neg_49", ldiv_by_constant_neg_49(x), x, -50l);
        longCheckDiv("ldiv_by_constant_neg_50", ldiv_by_constant_neg_50(x), x, -51l);
        longCheckDiv("ldiv_by_constant_neg_51", ldiv_by_constant_neg_51(x), x, -52l);
        longCheckDiv("ldiv_by_constant_neg_52", ldiv_by_constant_neg_52(x), x, -53l);
        longCheckDiv("ldiv_by_constant_neg_53", ldiv_by_constant_neg_53(x), x, -54l);
        longCheckDiv("ldiv_by_constant_neg_54", ldiv_by_constant_neg_54(x), x, -55l);
        longCheckDiv("ldiv_by_constant_neg_55", ldiv_by_constant_neg_55(x), x, -56l);
        longCheckDiv("ldiv_by_constant_neg_56", ldiv_by_constant_neg_56(x), x, -57l);
        longCheckDiv("ldiv_by_constant_neg_57", ldiv_by_constant_neg_57(x), x, -58l);
        longCheckDiv("ldiv_by_constant_neg_58", ldiv_by_constant_neg_58(x), x, -59l);
        longCheckDiv("ldiv_by_constant_neg_59", ldiv_by_constant_neg_59(x), x, -60l);
        longCheckDiv("ldiv_by_constant_neg_60", ldiv_by_constant_neg_60(x), x, -61l);
        longCheckDiv("ldiv_by_constant_neg_61", ldiv_by_constant_neg_61(x), x, -62l);
        longCheckDiv("ldiv_by_constant_neg_62", ldiv_by_constant_neg_62(x), x, -63l);
        longCheckDiv("ldiv_by_constant_neg_63", ldiv_by_constant_neg_63(x), x, -64l);
        longCheckDiv("ldiv_by_constant_neg_64", ldiv_by_constant_neg_64(x), x, -65l);
        longCheckDiv("ldiv_by_constant_neg_65", ldiv_by_constant_neg_65(x), x, -66l);
        longCheckDiv("ldiv_by_constant_neg_66", ldiv_by_constant_neg_66(x), x, -67l);
        longCheckDiv("ldiv_by_constant_neg_67", ldiv_by_constant_neg_67(x), x, -68l);
        longCheckDiv("ldiv_by_constant_neg_68", ldiv_by_constant_neg_68(x), x, -69l);
        longCheckDiv("ldiv_by_constant_neg_69", ldiv_by_constant_neg_69(x), x, -70l);
        longCheckDiv("ldiv_by_constant_neg_70", ldiv_by_constant_neg_70(x), x, -71l);
        longCheckDiv("ldiv_by_constant_neg_71", ldiv_by_constant_neg_71(x), x, -72l);
        longCheckDiv("ldiv_by_constant_neg_72", ldiv_by_constant_neg_72(x), x, -73l);
        longCheckDiv("ldiv_by_constant_neg_73", ldiv_by_constant_neg_73(x), x, -74l);
        longCheckDiv("ldiv_by_constant_neg_74", ldiv_by_constant_neg_74(x), x, -75l);
        longCheckDiv("ldiv_by_constant_neg_75", ldiv_by_constant_neg_75(x), x, -76l);
        longCheckDiv("ldiv_by_constant_neg_76", ldiv_by_constant_neg_76(x), x, -77l);
        longCheckDiv("ldiv_by_constant_neg_77", ldiv_by_constant_neg_77(x), x, -78l);
        longCheckDiv("ldiv_by_constant_neg_78", ldiv_by_constant_neg_78(x), x, -79l);
        longCheckDiv("ldiv_by_constant_neg_79", ldiv_by_constant_neg_79(x), x, -80l);
        longCheckDiv("ldiv_by_constant_neg_80", ldiv_by_constant_neg_80(x), x, -81l);
        longCheckDiv("ldiv_by_constant_neg_81", ldiv_by_constant_neg_81(x), x, -82l);
        longCheckDiv("ldiv_by_constant_neg_82", ldiv_by_constant_neg_82(x), x, -83l);
        longCheckDiv("ldiv_by_constant_neg_83", ldiv_by_constant_neg_83(x), x, -84l);
        longCheckDiv("ldiv_by_constant_neg_84", ldiv_by_constant_neg_84(x), x, -85l);
        longCheckDiv("ldiv_by_constant_neg_85", ldiv_by_constant_neg_85(x), x, -86l);
        longCheckDiv("ldiv_by_constant_neg_86", ldiv_by_constant_neg_86(x), x, -87l);
        longCheckDiv("ldiv_by_constant_neg_87", ldiv_by_constant_neg_87(x), x, -88l);
        longCheckDiv("ldiv_by_constant_neg_88", ldiv_by_constant_neg_88(x), x, -89l);
        longCheckDiv("ldiv_by_constant_neg_89", ldiv_by_constant_neg_89(x), x, -90l);
        longCheckDiv("ldiv_by_constant_neg_90", ldiv_by_constant_neg_90(x), x, -91l);
        longCheckDiv("ldiv_by_constant_neg_91", ldiv_by_constant_neg_91(x), x, -92l);
        longCheckDiv("ldiv_by_constant_neg_92", ldiv_by_constant_neg_92(x), x, -93l);
        longCheckDiv("ldiv_by_constant_neg_93", ldiv_by_constant_neg_93(x), x, -94l);
        longCheckDiv("ldiv_by_constant_neg_94", ldiv_by_constant_neg_94(x), x, -95l);
        longCheckDiv("ldiv_by_constant_neg_95", ldiv_by_constant_neg_95(x), x, -96l);
        longCheckDiv("ldiv_by_constant_neg_96", ldiv_by_constant_neg_96(x), x, -97l);
        longCheckDiv("ldiv_by_constant_neg_97", ldiv_by_constant_neg_97(x), x, -98l);
        longCheckDiv("ldiv_by_constant_neg_98", ldiv_by_constant_neg_98(x), x, -99l);
        longCheckRem("lrem_by_pow2_0", lrem_by_pow2_0(x), x, 1l);
        longCheckRem("lrem_by_pow2_1", lrem_by_pow2_1(x), x, 2l);
        longCheckRem("lrem_by_pow2_2", lrem_by_pow2_2(x), x, 4l);
        longCheckRem("lrem_by_pow2_3", lrem_by_pow2_3(x), x, 8l);
        longCheckRem("lrem_by_pow2_4", lrem_by_pow2_4(x), x, 16l);
        longCheckRem("lrem_by_pow2_5", lrem_by_pow2_5(x), x, 32l);
        longCheckRem("lrem_by_pow2_6", lrem_by_pow2_6(x), x, 64l);
        longCheckRem("lrem_by_pow2_7", lrem_by_pow2_7(x), x, 128l);
        longCheckRem("lrem_by_pow2_8", lrem_by_pow2_8(x), x, 256l);
        longCheckRem("lrem_by_pow2_9", lrem_by_pow2_9(x), x, 512l);
        longCheckRem("lrem_by_pow2_10", lrem_by_pow2_10(x), x, 1024l);
        longCheckRem("lrem_by_pow2_11", lrem_by_pow2_11(x), x, 2048l);
        longCheckRem("lrem_by_pow2_12", lrem_by_pow2_12(x), x, 4096l);
        longCheckRem("lrem_by_pow2_13", lrem_by_pow2_13(x), x, 8192l);
        longCheckRem("lrem_by_pow2_14", lrem_by_pow2_14(x), x, 16384l);
        longCheckRem("lrem_by_pow2_15", lrem_by_pow2_15(x), x, 32768l);
        longCheckRem("lrem_by_pow2_16", lrem_by_pow2_16(x), x, 65536l);
        longCheckRem("lrem_by_pow2_17", lrem_by_pow2_17(x), x, 131072l);
        longCheckRem("lrem_by_pow2_18", lrem_by_pow2_18(x), x, 262144l);
        longCheckRem("lrem_by_pow2_19", lrem_by_pow2_19(x), x, 524288l);
        longCheckRem("lrem_by_pow2_20", lrem_by_pow2_20(x), x, 1048576l);
        longCheckRem("lrem_by_pow2_21", lrem_by_pow2_21(x), x, 2097152l);
        longCheckRem("lrem_by_pow2_22", lrem_by_pow2_22(x), x, 4194304l);
        longCheckRem("lrem_by_pow2_23", lrem_by_pow2_23(x), x, 8388608l);
        longCheckRem("lrem_by_pow2_24", lrem_by_pow2_24(x), x, 16777216l);
        longCheckRem("lrem_by_pow2_25", lrem_by_pow2_25(x), x, 33554432l);
        longCheckRem("lrem_by_pow2_26", lrem_by_pow2_26(x), x, 67108864l);
        longCheckRem("lrem_by_pow2_27", lrem_by_pow2_27(x), x, 134217728l);
        longCheckRem("lrem_by_pow2_28", lrem_by_pow2_28(x), x, 268435456l);
        longCheckRem("lrem_by_pow2_29", lrem_by_pow2_29(x), x, 536870912l);
        longCheckRem("lrem_by_pow2_30", lrem_by_pow2_30(x), x, 1073741824l);
        longCheckRem("lrem_by_pow2_31", lrem_by_pow2_31(x), x, 2147483648l);
        longCheckRem("lrem_by_pow2_32", lrem_by_pow2_32(x), x, 4294967296l);
        longCheckRem("lrem_by_pow2_33", lrem_by_pow2_33(x), x, 8589934592l);
        longCheckRem("lrem_by_pow2_34", lrem_by_pow2_34(x), x, 17179869184l);
        longCheckRem("lrem_by_pow2_35", lrem_by_pow2_35(x), x, 34359738368l);
        longCheckRem("lrem_by_pow2_36", lrem_by_pow2_36(x), x, 68719476736l);
        longCheckRem("lrem_by_pow2_37", lrem_by_pow2_37(x), x, 137438953472l);
        longCheckRem("lrem_by_pow2_38", lrem_by_pow2_38(x), x, 274877906944l);
        longCheckRem("lrem_by_pow2_39", lrem_by_pow2_39(x), x, 549755813888l);
        longCheckRem("lrem_by_pow2_40", lrem_by_pow2_40(x), x, 1099511627776l);
        longCheckRem("lrem_by_pow2_41", lrem_by_pow2_41(x), x, 2199023255552l);
        longCheckRem("lrem_by_pow2_42", lrem_by_pow2_42(x), x, 4398046511104l);
        longCheckRem("lrem_by_pow2_43", lrem_by_pow2_43(x), x, 8796093022208l);
        longCheckRem("lrem_by_pow2_44", lrem_by_pow2_44(x), x, 17592186044416l);
        longCheckRem("lrem_by_pow2_45", lrem_by_pow2_45(x), x, 35184372088832l);
        longCheckRem("lrem_by_pow2_46", lrem_by_pow2_46(x), x, 70368744177664l);
        longCheckRem("lrem_by_pow2_47", lrem_by_pow2_47(x), x, 140737488355328l);
        longCheckRem("lrem_by_pow2_48", lrem_by_pow2_48(x), x, 281474976710656l);
        longCheckRem("lrem_by_pow2_49", lrem_by_pow2_49(x), x, 562949953421312l);
        longCheckRem("lrem_by_pow2_50", lrem_by_pow2_50(x), x, 1125899906842624l);
        longCheckRem("lrem_by_pow2_51", lrem_by_pow2_51(x), x, 2251799813685248l);
        longCheckRem("lrem_by_pow2_52", lrem_by_pow2_52(x), x, 4503599627370496l);
        longCheckRem("lrem_by_pow2_53", lrem_by_pow2_53(x), x, 9007199254740992l);
        longCheckRem("lrem_by_pow2_54", lrem_by_pow2_54(x), x, 18014398509481984l);
        longCheckRem("lrem_by_pow2_55", lrem_by_pow2_55(x), x, 36028797018963968l);
        longCheckRem("lrem_by_pow2_56", lrem_by_pow2_56(x), x, 72057594037927936l);
        longCheckRem("lrem_by_pow2_57", lrem_by_pow2_57(x), x, 144115188075855872l);
        longCheckRem("lrem_by_pow2_58", lrem_by_pow2_58(x), x, 288230376151711744l);
        longCheckRem("lrem_by_pow2_59", lrem_by_pow2_59(x), x, 576460752303423488l);
        longCheckRem("lrem_by_pow2_60", lrem_by_pow2_60(x), x, 1152921504606846976l);
        longCheckRem("lrem_by_pow2_61", lrem_by_pow2_61(x), x, 2305843009213693952l);
        longCheckRem("lrem_by_pow2_62", lrem_by_pow2_62(x), x, 4611686018427387904l);
        longCheckRem("lrem_by_pow2_neg_0", lrem_by_pow2_neg_0(x), x, -1l);
        longCheckRem("lrem_by_pow2_neg_1", lrem_by_pow2_neg_1(x), x, -2l);
        longCheckRem("lrem_by_pow2_neg_2", lrem_by_pow2_neg_2(x), x, -4l);
        longCheckRem("lrem_by_pow2_neg_3", lrem_by_pow2_neg_3(x), x, -8l);
        longCheckRem("lrem_by_pow2_neg_4", lrem_by_pow2_neg_4(x), x, -16l);
        longCheckRem("lrem_by_pow2_neg_5", lrem_by_pow2_neg_5(x), x, -32l);
        longCheckRem("lrem_by_pow2_neg_6", lrem_by_pow2_neg_6(x), x, -64l);
        longCheckRem("lrem_by_pow2_neg_7", lrem_by_pow2_neg_7(x), x, -128l);
        longCheckRem("lrem_by_pow2_neg_8", lrem_by_pow2_neg_8(x), x, -256l);
        longCheckRem("lrem_by_pow2_neg_9", lrem_by_pow2_neg_9(x), x, -512l);
        longCheckRem("lrem_by_pow2_neg_10", lrem_by_pow2_neg_10(x), x, -1024l);
        longCheckRem("lrem_by_pow2_neg_11", lrem_by_pow2_neg_11(x), x, -2048l);
        longCheckRem("lrem_by_pow2_neg_12", lrem_by_pow2_neg_12(x), x, -4096l);
        longCheckRem("lrem_by_pow2_neg_13", lrem_by_pow2_neg_13(x), x, -8192l);
        longCheckRem("lrem_by_pow2_neg_14", lrem_by_pow2_neg_14(x), x, -16384l);
        longCheckRem("lrem_by_pow2_neg_15", lrem_by_pow2_neg_15(x), x, -32768l);
        longCheckRem("lrem_by_pow2_neg_16", lrem_by_pow2_neg_16(x), x, -65536l);
        longCheckRem("lrem_by_pow2_neg_17", lrem_by_pow2_neg_17(x), x, -131072l);
        longCheckRem("lrem_by_pow2_neg_18", lrem_by_pow2_neg_18(x), x, -262144l);
        longCheckRem("lrem_by_pow2_neg_19", lrem_by_pow2_neg_19(x), x, -524288l);
        longCheckRem("lrem_by_pow2_neg_20", lrem_by_pow2_neg_20(x), x, -1048576l);
        longCheckRem("lrem_by_pow2_neg_21", lrem_by_pow2_neg_21(x), x, -2097152l);
        longCheckRem("lrem_by_pow2_neg_22", lrem_by_pow2_neg_22(x), x, -4194304l);
        longCheckRem("lrem_by_pow2_neg_23", lrem_by_pow2_neg_23(x), x, -8388608l);
        longCheckRem("lrem_by_pow2_neg_24", lrem_by_pow2_neg_24(x), x, -16777216l);
        longCheckRem("lrem_by_pow2_neg_25", lrem_by_pow2_neg_25(x), x, -33554432l);
        longCheckRem("lrem_by_pow2_neg_26", lrem_by_pow2_neg_26(x), x, -67108864l);
        longCheckRem("lrem_by_pow2_neg_27", lrem_by_pow2_neg_27(x), x, -134217728l);
        longCheckRem("lrem_by_pow2_neg_28", lrem_by_pow2_neg_28(x), x, -268435456l);
        longCheckRem("lrem_by_pow2_neg_29", lrem_by_pow2_neg_29(x), x, -536870912l);
        longCheckRem("lrem_by_pow2_neg_30", lrem_by_pow2_neg_30(x), x, -1073741824l);
        longCheckRem("lrem_by_pow2_neg_31", lrem_by_pow2_neg_31(x), x, -2147483648l);
        longCheckRem("lrem_by_pow2_neg_32", lrem_by_pow2_neg_32(x), x, -4294967296l);
        longCheckRem("lrem_by_pow2_neg_33", lrem_by_pow2_neg_33(x), x, -8589934592l);
        longCheckRem("lrem_by_pow2_neg_34", lrem_by_pow2_neg_34(x), x, -17179869184l);
        longCheckRem("lrem_by_pow2_neg_35", lrem_by_pow2_neg_35(x), x, -34359738368l);
        longCheckRem("lrem_by_pow2_neg_36", lrem_by_pow2_neg_36(x), x, -68719476736l);
        longCheckRem("lrem_by_pow2_neg_37", lrem_by_pow2_neg_37(x), x, -137438953472l);
        longCheckRem("lrem_by_pow2_neg_38", lrem_by_pow2_neg_38(x), x, -274877906944l);
        longCheckRem("lrem_by_pow2_neg_39", lrem_by_pow2_neg_39(x), x, -549755813888l);
        longCheckRem("lrem_by_pow2_neg_40", lrem_by_pow2_neg_40(x), x, -1099511627776l);
        longCheckRem("lrem_by_pow2_neg_41", lrem_by_pow2_neg_41(x), x, -2199023255552l);
        longCheckRem("lrem_by_pow2_neg_42", lrem_by_pow2_neg_42(x), x, -4398046511104l);
        longCheckRem("lrem_by_pow2_neg_43", lrem_by_pow2_neg_43(x), x, -8796093022208l);
        longCheckRem("lrem_by_pow2_neg_44", lrem_by_pow2_neg_44(x), x, -17592186044416l);
        longCheckRem("lrem_by_pow2_neg_45", lrem_by_pow2_neg_45(x), x, -35184372088832l);
        longCheckRem("lrem_by_pow2_neg_46", lrem_by_pow2_neg_46(x), x, -70368744177664l);
        longCheckRem("lrem_by_pow2_neg_47", lrem_by_pow2_neg_47(x), x, -140737488355328l);
        longCheckRem("lrem_by_pow2_neg_48", lrem_by_pow2_neg_48(x), x, -281474976710656l);
        longCheckRem("lrem_by_pow2_neg_49", lrem_by_pow2_neg_49(x), x, -562949953421312l);
        longCheckRem("lrem_by_pow2_neg_50", lrem_by_pow2_neg_50(x), x, -1125899906842624l);
        longCheckRem("lrem_by_pow2_neg_51", lrem_by_pow2_neg_51(x), x, -2251799813685248l);
        longCheckRem("lrem_by_pow2_neg_52", lrem_by_pow2_neg_52(x), x, -4503599627370496l);
        longCheckRem("lrem_by_pow2_neg_53", lrem_by_pow2_neg_53(x), x, -9007199254740992l);
        longCheckRem("lrem_by_pow2_neg_54", lrem_by_pow2_neg_54(x), x, -18014398509481984l);
        longCheckRem("lrem_by_pow2_neg_55", lrem_by_pow2_neg_55(x), x, -36028797018963968l);
        longCheckRem("lrem_by_pow2_neg_56", lrem_by_pow2_neg_56(x), x, -72057594037927936l);
        longCheckRem("lrem_by_pow2_neg_57", lrem_by_pow2_neg_57(x), x, -144115188075855872l);
        longCheckRem("lrem_by_pow2_neg_58", lrem_by_pow2_neg_58(x), x, -288230376151711744l);
        longCheckRem("lrem_by_pow2_neg_59", lrem_by_pow2_neg_59(x), x, -576460752303423488l);
        longCheckRem("lrem_by_pow2_neg_60", lrem_by_pow2_neg_60(x), x, -1152921504606846976l);
        longCheckRem("lrem_by_pow2_neg_61", lrem_by_pow2_neg_61(x), x, -2305843009213693952l);
        longCheckRem("lrem_by_pow2_neg_62", lrem_by_pow2_neg_62(x), x, -4611686018427387904l);
        longCheckRem("lrem_by_pow2_neg_63", lrem_by_pow2_neg_63(x), x, -9223372036854775808l);
        longCheckRem("lrem_by_constant_0", lrem_by_constant_0(x), x, 1l);
        longCheckRem("lrem_by_constant_1", lrem_by_constant_1(x), x, 2l);
        longCheckRem("lrem_by_constant_2", lrem_by_constant_2(x), x, 3l);
        longCheckRem("lrem_by_constant_3", lrem_by_constant_3(x), x, 4l);
        longCheckRem("lrem_by_constant_4", lrem_by_constant_4(x), x, 5l);
        longCheckRem("lrem_by_constant_5", lrem_by_constant_5(x), x, 6l);
        longCheckRem("lrem_by_constant_6", lrem_by_constant_6(x), x, 7l);
        longCheckRem("lrem_by_constant_7", lrem_by_constant_7(x), x, 8l);
        longCheckRem("lrem_by_constant_8", lrem_by_constant_8(x), x, 9l);
        longCheckRem("lrem_by_constant_9", lrem_by_constant_9(x), x, 10l);
        longCheckRem("lrem_by_constant_10", lrem_by_constant_10(x), x, 11l);
        longCheckRem("lrem_by_constant_11", lrem_by_constant_11(x), x, 12l);
        longCheckRem("lrem_by_constant_12", lrem_by_constant_12(x), x, 13l);
        longCheckRem("lrem_by_constant_13", lrem_by_constant_13(x), x, 14l);
        longCheckRem("lrem_by_constant_14", lrem_by_constant_14(x), x, 15l);
        longCheckRem("lrem_by_constant_15", lrem_by_constant_15(x), x, 16l);
        longCheckRem("lrem_by_constant_16", lrem_by_constant_16(x), x, 17l);
        longCheckRem("lrem_by_constant_17", lrem_by_constant_17(x), x, 18l);
        longCheckRem("lrem_by_constant_18", lrem_by_constant_18(x), x, 19l);
        longCheckRem("lrem_by_constant_19", lrem_by_constant_19(x), x, 20l);
        longCheckRem("lrem_by_constant_20", lrem_by_constant_20(x), x, 21l);
        longCheckRem("lrem_by_constant_21", lrem_by_constant_21(x), x, 22l);
        longCheckRem("lrem_by_constant_22", lrem_by_constant_22(x), x, 23l);
        longCheckRem("lrem_by_constant_23", lrem_by_constant_23(x), x, 24l);
        longCheckRem("lrem_by_constant_24", lrem_by_constant_24(x), x, 25l);
        longCheckRem("lrem_by_constant_25", lrem_by_constant_25(x), x, 26l);
        longCheckRem("lrem_by_constant_26", lrem_by_constant_26(x), x, 27l);
        longCheckRem("lrem_by_constant_27", lrem_by_constant_27(x), x, 28l);
        longCheckRem("lrem_by_constant_28", lrem_by_constant_28(x), x, 29l);
        longCheckRem("lrem_by_constant_29", lrem_by_constant_29(x), x, 30l);
        longCheckRem("lrem_by_constant_30", lrem_by_constant_30(x), x, 31l);
        longCheckRem("lrem_by_constant_31", lrem_by_constant_31(x), x, 32l);
        longCheckRem("lrem_by_constant_32", lrem_by_constant_32(x), x, 33l);
        longCheckRem("lrem_by_constant_33", lrem_by_constant_33(x), x, 34l);
        longCheckRem("lrem_by_constant_34", lrem_by_constant_34(x), x, 35l);
        longCheckRem("lrem_by_constant_35", lrem_by_constant_35(x), x, 36l);
        longCheckRem("lrem_by_constant_36", lrem_by_constant_36(x), x, 37l);
        longCheckRem("lrem_by_constant_37", lrem_by_constant_37(x), x, 38l);
        longCheckRem("lrem_by_constant_38", lrem_by_constant_38(x), x, 39l);
        longCheckRem("lrem_by_constant_39", lrem_by_constant_39(x), x, 40l);
        longCheckRem("lrem_by_constant_40", lrem_by_constant_40(x), x, 41l);
        longCheckRem("lrem_by_constant_41", lrem_by_constant_41(x), x, 42l);
        longCheckRem("lrem_by_constant_42", lrem_by_constant_42(x), x, 43l);
        longCheckRem("lrem_by_constant_43", lrem_by_constant_43(x), x, 44l);
        longCheckRem("lrem_by_constant_44", lrem_by_constant_44(x), x, 45l);
        longCheckRem("lrem_by_constant_45", lrem_by_constant_45(x), x, 46l);
        longCheckRem("lrem_by_constant_46", lrem_by_constant_46(x), x, 47l);
        longCheckRem("lrem_by_constant_47", lrem_by_constant_47(x), x, 48l);
        longCheckRem("lrem_by_constant_48", lrem_by_constant_48(x), x, 49l);
        longCheckRem("lrem_by_constant_49", lrem_by_constant_49(x), x, 50l);
        longCheckRem("lrem_by_constant_50", lrem_by_constant_50(x), x, 51l);
        longCheckRem("lrem_by_constant_51", lrem_by_constant_51(x), x, 52l);
        longCheckRem("lrem_by_constant_52", lrem_by_constant_52(x), x, 53l);
        longCheckRem("lrem_by_constant_53", lrem_by_constant_53(x), x, 54l);
        longCheckRem("lrem_by_constant_54", lrem_by_constant_54(x), x, 55l);
        longCheckRem("lrem_by_constant_55", lrem_by_constant_55(x), x, 56l);
        longCheckRem("lrem_by_constant_56", lrem_by_constant_56(x), x, 57l);
        longCheckRem("lrem_by_constant_57", lrem_by_constant_57(x), x, 58l);
        longCheckRem("lrem_by_constant_58", lrem_by_constant_58(x), x, 59l);
        longCheckRem("lrem_by_constant_59", lrem_by_constant_59(x), x, 60l);
        longCheckRem("lrem_by_constant_60", lrem_by_constant_60(x), x, 61l);
        longCheckRem("lrem_by_constant_61", lrem_by_constant_61(x), x, 62l);
        longCheckRem("lrem_by_constant_62", lrem_by_constant_62(x), x, 63l);
        longCheckRem("lrem_by_constant_63", lrem_by_constant_63(x), x, 64l);
        longCheckRem("lrem_by_constant_64", lrem_by_constant_64(x), x, 65l);
        longCheckRem("lrem_by_constant_65", lrem_by_constant_65(x), x, 66l);
        longCheckRem("lrem_by_constant_66", lrem_by_constant_66(x), x, 67l);
        longCheckRem("lrem_by_constant_67", lrem_by_constant_67(x), x, 68l);
        longCheckRem("lrem_by_constant_68", lrem_by_constant_68(x), x, 69l);
        longCheckRem("lrem_by_constant_69", lrem_by_constant_69(x), x, 70l);
        longCheckRem("lrem_by_constant_70", lrem_by_constant_70(x), x, 71l);
        longCheckRem("lrem_by_constant_71", lrem_by_constant_71(x), x, 72l);
        longCheckRem("lrem_by_constant_72", lrem_by_constant_72(x), x, 73l);
        longCheckRem("lrem_by_constant_73", lrem_by_constant_73(x), x, 74l);
        longCheckRem("lrem_by_constant_74", lrem_by_constant_74(x), x, 75l);
        longCheckRem("lrem_by_constant_75", lrem_by_constant_75(x), x, 76l);
        longCheckRem("lrem_by_constant_76", lrem_by_constant_76(x), x, 77l);
        longCheckRem("lrem_by_constant_77", lrem_by_constant_77(x), x, 78l);
        longCheckRem("lrem_by_constant_78", lrem_by_constant_78(x), x, 79l);
        longCheckRem("lrem_by_constant_79", lrem_by_constant_79(x), x, 80l);
        longCheckRem("lrem_by_constant_80", lrem_by_constant_80(x), x, 81l);
        longCheckRem("lrem_by_constant_81", lrem_by_constant_81(x), x, 82l);
        longCheckRem("lrem_by_constant_82", lrem_by_constant_82(x), x, 83l);
        longCheckRem("lrem_by_constant_83", lrem_by_constant_83(x), x, 84l);
        longCheckRem("lrem_by_constant_84", lrem_by_constant_84(x), x, 85l);
        longCheckRem("lrem_by_constant_85", lrem_by_constant_85(x), x, 86l);
        longCheckRem("lrem_by_constant_86", lrem_by_constant_86(x), x, 87l);
        longCheckRem("lrem_by_constant_87", lrem_by_constant_87(x), x, 88l);
        longCheckRem("lrem_by_constant_88", lrem_by_constant_88(x), x, 89l);
        longCheckRem("lrem_by_constant_89", lrem_by_constant_89(x), x, 90l);
        longCheckRem("lrem_by_constant_90", lrem_by_constant_90(x), x, 91l);
        longCheckRem("lrem_by_constant_91", lrem_by_constant_91(x), x, 92l);
        longCheckRem("lrem_by_constant_92", lrem_by_constant_92(x), x, 93l);
        longCheckRem("lrem_by_constant_93", lrem_by_constant_93(x), x, 94l);
        longCheckRem("lrem_by_constant_94", lrem_by_constant_94(x), x, 95l);
        longCheckRem("lrem_by_constant_95", lrem_by_constant_95(x), x, 96l);
        longCheckRem("lrem_by_constant_96", lrem_by_constant_96(x), x, 97l);
        longCheckRem("lrem_by_constant_97", lrem_by_constant_97(x), x, 98l);
        longCheckRem("lrem_by_constant_98", lrem_by_constant_98(x), x, 99l);
        longCheckRem("lrem_by_constant_neg_0", lrem_by_constant_neg_0(x), x, -1l);
        longCheckRem("lrem_by_constant_neg_1", lrem_by_constant_neg_1(x), x, -2l);
        longCheckRem("lrem_by_constant_neg_2", lrem_by_constant_neg_2(x), x, -3l);
        longCheckRem("lrem_by_constant_neg_3", lrem_by_constant_neg_3(x), x, -4l);
        longCheckRem("lrem_by_constant_neg_4", lrem_by_constant_neg_4(x), x, -5l);
        longCheckRem("lrem_by_constant_neg_5", lrem_by_constant_neg_5(x), x, -6l);
        longCheckRem("lrem_by_constant_neg_6", lrem_by_constant_neg_6(x), x, -7l);
        longCheckRem("lrem_by_constant_neg_7", lrem_by_constant_neg_7(x), x, -8l);
        longCheckRem("lrem_by_constant_neg_8", lrem_by_constant_neg_8(x), x, -9l);
        longCheckRem("lrem_by_constant_neg_9", lrem_by_constant_neg_9(x), x, -10l);
        longCheckRem("lrem_by_constant_neg_10", lrem_by_constant_neg_10(x), x, -11l);
        longCheckRem("lrem_by_constant_neg_11", lrem_by_constant_neg_11(x), x, -12l);
        longCheckRem("lrem_by_constant_neg_12", lrem_by_constant_neg_12(x), x, -13l);
        longCheckRem("lrem_by_constant_neg_13", lrem_by_constant_neg_13(x), x, -14l);
        longCheckRem("lrem_by_constant_neg_14", lrem_by_constant_neg_14(x), x, -15l);
        longCheckRem("lrem_by_constant_neg_15", lrem_by_constant_neg_15(x), x, -16l);
        longCheckRem("lrem_by_constant_neg_16", lrem_by_constant_neg_16(x), x, -17l);
        longCheckRem("lrem_by_constant_neg_17", lrem_by_constant_neg_17(x), x, -18l);
        longCheckRem("lrem_by_constant_neg_18", lrem_by_constant_neg_18(x), x, -19l);
        longCheckRem("lrem_by_constant_neg_19", lrem_by_constant_neg_19(x), x, -20l);
        longCheckRem("lrem_by_constant_neg_20", lrem_by_constant_neg_20(x), x, -21l);
        longCheckRem("lrem_by_constant_neg_21", lrem_by_constant_neg_21(x), x, -22l);
        longCheckRem("lrem_by_constant_neg_22", lrem_by_constant_neg_22(x), x, -23l);
        longCheckRem("lrem_by_constant_neg_23", lrem_by_constant_neg_23(x), x, -24l);
        longCheckRem("lrem_by_constant_neg_24", lrem_by_constant_neg_24(x), x, -25l);
        longCheckRem("lrem_by_constant_neg_25", lrem_by_constant_neg_25(x), x, -26l);
        longCheckRem("lrem_by_constant_neg_26", lrem_by_constant_neg_26(x), x, -27l);
        longCheckRem("lrem_by_constant_neg_27", lrem_by_constant_neg_27(x), x, -28l);
        longCheckRem("lrem_by_constant_neg_28", lrem_by_constant_neg_28(x), x, -29l);
        longCheckRem("lrem_by_constant_neg_29", lrem_by_constant_neg_29(x), x, -30l);
        longCheckRem("lrem_by_constant_neg_30", lrem_by_constant_neg_30(x), x, -31l);
        longCheckRem("lrem_by_constant_neg_31", lrem_by_constant_neg_31(x), x, -32l);
        longCheckRem("lrem_by_constant_neg_32", lrem_by_constant_neg_32(x), x, -33l);
        longCheckRem("lrem_by_constant_neg_33", lrem_by_constant_neg_33(x), x, -34l);
        longCheckRem("lrem_by_constant_neg_34", lrem_by_constant_neg_34(x), x, -35l);
        longCheckRem("lrem_by_constant_neg_35", lrem_by_constant_neg_35(x), x, -36l);
        longCheckRem("lrem_by_constant_neg_36", lrem_by_constant_neg_36(x), x, -37l);
        longCheckRem("lrem_by_constant_neg_37", lrem_by_constant_neg_37(x), x, -38l);
        longCheckRem("lrem_by_constant_neg_38", lrem_by_constant_neg_38(x), x, -39l);
        longCheckRem("lrem_by_constant_neg_39", lrem_by_constant_neg_39(x), x, -40l);
        longCheckRem("lrem_by_constant_neg_40", lrem_by_constant_neg_40(x), x, -41l);
        longCheckRem("lrem_by_constant_neg_41", lrem_by_constant_neg_41(x), x, -42l);
        longCheckRem("lrem_by_constant_neg_42", lrem_by_constant_neg_42(x), x, -43l);
        longCheckRem("lrem_by_constant_neg_43", lrem_by_constant_neg_43(x), x, -44l);
        longCheckRem("lrem_by_constant_neg_44", lrem_by_constant_neg_44(x), x, -45l);
        longCheckRem("lrem_by_constant_neg_45", lrem_by_constant_neg_45(x), x, -46l);
        longCheckRem("lrem_by_constant_neg_46", lrem_by_constant_neg_46(x), x, -47l);
        longCheckRem("lrem_by_constant_neg_47", lrem_by_constant_neg_47(x), x, -48l);
        longCheckRem("lrem_by_constant_neg_48", lrem_by_constant_neg_48(x), x, -49l);
        longCheckRem("lrem_by_constant_neg_49", lrem_by_constant_neg_49(x), x, -50l);
        longCheckRem("lrem_by_constant_neg_50", lrem_by_constant_neg_50(x), x, -51l);
        longCheckRem("lrem_by_constant_neg_51", lrem_by_constant_neg_51(x), x, -52l);
        longCheckRem("lrem_by_constant_neg_52", lrem_by_constant_neg_52(x), x, -53l);
        longCheckRem("lrem_by_constant_neg_53", lrem_by_constant_neg_53(x), x, -54l);
        longCheckRem("lrem_by_constant_neg_54", lrem_by_constant_neg_54(x), x, -55l);
        longCheckRem("lrem_by_constant_neg_55", lrem_by_constant_neg_55(x), x, -56l);
        longCheckRem("lrem_by_constant_neg_56", lrem_by_constant_neg_56(x), x, -57l);
        longCheckRem("lrem_by_constant_neg_57", lrem_by_constant_neg_57(x), x, -58l);
        longCheckRem("lrem_by_constant_neg_58", lrem_by_constant_neg_58(x), x, -59l);
        longCheckRem("lrem_by_constant_neg_59", lrem_by_constant_neg_59(x), x, -60l);
        longCheckRem("lrem_by_constant_neg_60", lrem_by_constant_neg_60(x), x, -61l);
        longCheckRem("lrem_by_constant_neg_61", lrem_by_constant_neg_61(x), x, -62l);
        longCheckRem("lrem_by_constant_neg_62", lrem_by_constant_neg_62(x), x, -63l);
        longCheckRem("lrem_by_constant_neg_63", lrem_by_constant_neg_63(x), x, -64l);
        longCheckRem("lrem_by_constant_neg_64", lrem_by_constant_neg_64(x), x, -65l);
        longCheckRem("lrem_by_constant_neg_65", lrem_by_constant_neg_65(x), x, -66l);
        longCheckRem("lrem_by_constant_neg_66", lrem_by_constant_neg_66(x), x, -67l);
        longCheckRem("lrem_by_constant_neg_67", lrem_by_constant_neg_67(x), x, -68l);
        longCheckRem("lrem_by_constant_neg_68", lrem_by_constant_neg_68(x), x, -69l);
        longCheckRem("lrem_by_constant_neg_69", lrem_by_constant_neg_69(x), x, -70l);
        longCheckRem("lrem_by_constant_neg_70", lrem_by_constant_neg_70(x), x, -71l);
        longCheckRem("lrem_by_constant_neg_71", lrem_by_constant_neg_71(x), x, -72l);
        longCheckRem("lrem_by_constant_neg_72", lrem_by_constant_neg_72(x), x, -73l);
        longCheckRem("lrem_by_constant_neg_73", lrem_by_constant_neg_73(x), x, -74l);
        longCheckRem("lrem_by_constant_neg_74", lrem_by_constant_neg_74(x), x, -75l);
        longCheckRem("lrem_by_constant_neg_75", lrem_by_constant_neg_75(x), x, -76l);
        longCheckRem("lrem_by_constant_neg_76", lrem_by_constant_neg_76(x), x, -77l);
        longCheckRem("lrem_by_constant_neg_77", lrem_by_constant_neg_77(x), x, -78l);
        longCheckRem("lrem_by_constant_neg_78", lrem_by_constant_neg_78(x), x, -79l);
        longCheckRem("lrem_by_constant_neg_79", lrem_by_constant_neg_79(x), x, -80l);
        longCheckRem("lrem_by_constant_neg_80", lrem_by_constant_neg_80(x), x, -81l);
        longCheckRem("lrem_by_constant_neg_81", lrem_by_constant_neg_81(x), x, -82l);
        longCheckRem("lrem_by_constant_neg_82", lrem_by_constant_neg_82(x), x, -83l);
        longCheckRem("lrem_by_constant_neg_83", lrem_by_constant_neg_83(x), x, -84l);
        longCheckRem("lrem_by_constant_neg_84", lrem_by_constant_neg_84(x), x, -85l);
        longCheckRem("lrem_by_constant_neg_85", lrem_by_constant_neg_85(x), x, -86l);
        longCheckRem("lrem_by_constant_neg_86", lrem_by_constant_neg_86(x), x, -87l);
        longCheckRem("lrem_by_constant_neg_87", lrem_by_constant_neg_87(x), x, -88l);
        longCheckRem("lrem_by_constant_neg_88", lrem_by_constant_neg_88(x), x, -89l);
        longCheckRem("lrem_by_constant_neg_89", lrem_by_constant_neg_89(x), x, -90l);
        longCheckRem("lrem_by_constant_neg_90", lrem_by_constant_neg_90(x), x, -91l);
        longCheckRem("lrem_by_constant_neg_91", lrem_by_constant_neg_91(x), x, -92l);
        longCheckRem("lrem_by_constant_neg_92", lrem_by_constant_neg_92(x), x, -93l);
        longCheckRem("lrem_by_constant_neg_93", lrem_by_constant_neg_93(x), x, -94l);
        longCheckRem("lrem_by_constant_neg_94", lrem_by_constant_neg_94(x), x, -95l);
        longCheckRem("lrem_by_constant_neg_95", lrem_by_constant_neg_95(x), x, -96l);
        longCheckRem("lrem_by_constant_neg_96", lrem_by_constant_neg_96(x), x, -97l);
        longCheckRem("lrem_by_constant_neg_97", lrem_by_constant_neg_97(x), x, -98l);
        longCheckRem("lrem_by_constant_neg_98", lrem_by_constant_neg_98(x), x, -99l);
    }

    public static void main(String[] args) {
      int i;
      long l;

      System.out.println("Begin");

      System.out.println("Int: checking some equally spaced dividends...");
      for (i = -1000; i < 1000; i += 300) {
          intCheckAll(i);
          intCheckAll(-i);
      }

      System.out.println("Int: checking small dividends...");
      for (i = 1; i < 100; i += 1) {
          intCheckAll(i);
          intCheckAll(-i);
      }

      System.out.println("Int: checking big dividends...");
      for (i = 0; i < 100; i += 1) {
          intCheckAll(Integer.MAX_VALUE - i);
          intCheckAll(Integer.MIN_VALUE + i);
      }

      System.out.println("Long: checking some equally spaced dividends...");
      for (l = 0l; l < 1000000000000l; l += 300000000000l) {
          longCheckAll(l);
          longCheckAll(-l);
      }

      System.out.println("Long: checking small dividends...");
      for (l = 1l; l < 100l; l += 1l) {
          longCheckAll(l);
          longCheckAll(-l);
      }

      System.out.println("Long: checking big dividends...");
      for (l = 0l; l < 100l; l += 1l) {
          longCheckAll(Long.MAX_VALUE - l);
          longCheckAll(Long.MIN_VALUE + l);
      }

      System.out.println("End");
    }
}
